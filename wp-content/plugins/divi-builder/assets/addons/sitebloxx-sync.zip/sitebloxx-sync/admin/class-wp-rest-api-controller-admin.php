<?php

class WP_REST_API_Controller_Admin {	
	private $plugin_name;	
	private $version;
	
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		//add_action('admin_menu', array($this, 'siteblox_menu'));

		add_action("wp_ajax_siteblox_key_saved", array($this, "siteblox_key_saved"));
		add_action("wp_ajax_nopriv_siteblox_key_saved", array($this, "siteblox_key_saved"));
	}	
	

	public function siteblox_key_saved(){
		extract($_REQUEST);
		$current_user = wp_get_current_user();
		$current_user_id= $current_user->ID;
		update_option( 'siteblox_key', $siteblox_key);
		$connect_data=array(
			'website_url' => $website_url,
			'server_userid' => $current_user_id,
			'siteblox_key' => $siteblox_key
		);

		$siteblox_json= json_encode($connect_data);


		if($siteblox_status=="siteblox_connect"){
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://app.sitebloxx.com/wp-json/siteblox-api/connect",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => $siteblox_json,
			  CURLOPT_HTTPHEADER => array(
			    "cache-control: no-cache",
			    "content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);

			if ($err) {
			  	$result=array(
					'code' => 202,
					'message' => $err
				);
			} else {
				$siteblox_resp=json_decode($response, true);
				if($siteblox_resp['code']==200){
					update_option( 'siteblox_connect', 'yes');
				} 
			  	echo $response;
			}
		} else {

			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://app.sitebloxx.com/wp-json/siteblox-api/disconnect",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => $siteblox_json,
			  CURLOPT_HTTPHEADER => array(
			    "cache-control: no-cache",
			    "content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);

			if ($err) {
			  	$result=array(
					'code' => 202,
					'message' => $err
				);
			} else {
				$siteblox_resp=json_decode($response, true);
				if($siteblox_resp['code']==200){
					update_option( 'siteblox_connect', 'no');
				} 
			  	echo $response;
			}
		}
		die();
	}
}
