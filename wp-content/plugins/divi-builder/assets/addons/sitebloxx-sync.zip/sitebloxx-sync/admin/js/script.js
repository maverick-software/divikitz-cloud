jQuery(function($){

    $("#siteblox_connectivity").submit(function(event){
        event.preventDefault();
        var button_action= $("#siteblox_status").val();
        var button_text= $("#siteblox_connectivity #save_connectivity").html();
        $("#siteblox_connectivity #save_connectivity").html('Please Wait <i class="fa fa-spinner fa-spin" style="font-size:20px"></i>');
        $.ajax({
            type : "POST",
            dataType : "json",
            url : siteblox_admin.ajax_url,
            data : $('#siteblox_connectivity').serialize(),
            success: function(resp) {
                $("#siteblox_connectivity #save_connectivity").html(button_text);
                if(resp.code==200){                       
                    Swal.fire({
                        title: "Success!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "success"
                    });

                    if(button_action=="siteblox_connect"){
                        $("#siteblox_status").val('siteblox_disconnect');
                        $("#siteblox_connectivity #save_connectivity").removeClass('button-pro').addClass('button-danger');
                        $("#siteblox_connectivity #save_connectivity").html('Disconnect');
                    } else {
                        $("#siteblox_status").val('siteblox_connect');
                        $("#siteblox_connectivity #save_connectivity").removeClass('button-danger').addClass('button-pro');
                        $("#siteblox_connectivity #save_connectivity").html('Connect');
                    }
                } else {
                    Swal.fire({
                        title: "Error!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "error"
                    });                    
                }
            }, error:function(){
               $("#siteblox_connectivity #save_connectivity").html(button_text);
               Swal.fire({
                title: "Error!", 
                text: "Please try again later",
                confirmButtonColor: '#000', 
                icon: "error"
            });
           }
       });
    });

});