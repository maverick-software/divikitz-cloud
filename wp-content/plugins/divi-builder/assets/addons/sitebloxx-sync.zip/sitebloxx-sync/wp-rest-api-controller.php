<?php
/*
  Plugin Name:       Bloxx Sync
  Plugin URI:        https://app.sitebloxx.com/
  Description:       This Plugin allow you to direct import from Bulder Project
  Version: 		   		 5.10.15
 */


if (!defined('WPINC')) {
    die;
}

if (!defined('WP_REST_API_CONTROLLER_PATH')) {
    define('WP_REST_API_CONTROLLER_PATH', plugin_dir_path(__FILE__));
}

if (!defined('siteblox_version')) {
    define('siteblox_version', '5.10.15');
}

if (!defined('WP_REST_API_CONTROLLER_URL')) {
    define('WP_REST_API_CONTROLLER_URL', plugin_dir_url(__FILE__));
}

function wp_rest_api_controller_text_domain_init() {
    load_plugin_textdomain('wp-rest-api-controller', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

add_action('init', 'wp_rest_api_controller_text_domain_init');



register_activation_hook(__FILE__, 'activate_wp_rest_api_controller');

function activate_wp_rest_api_controller() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wp-rest-api-controller-activator.php';
    wp_rest_api_controller_Activator::activate();
}

register_deactivation_hook(__FILE__, 'deactivate_wp_rest_api_controller');

function deactivate_wp_rest_api_controller() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wp-rest-api-controller-deactivator.php';
    wp_rest_api_controller_Deactivator::deactivate();
}

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://app.sitebloxx.com/wp-json/siteblox-update/notification",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache",
        "postman-token: 3217ca20-6792-7c25-91e1-b19dbcdb0fe6"
    ),
));

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
$site_update_data = json_decode($response, true);




if (function_exists('reload_cssjs')) {

    function reload_cssjs() {
        global $wpdb;
        global $wp_query;
        $page_id = $wp_query->post->ID;


        if ($page_id != "" && is_user_logged_in()) {
            @$page_refresh = get_post_meta($page_id, 'page_referesh', true);

            if (@$page_refresh == "yes" && is_user_logged_in()) {
                $posts = $wpdb->prefix . 'posts';
                $page_query = "SELECT * FROM $posts where ID='$page_id' limit 1";
                $page_data = $wpdb->get_row($page_query);
                $page_content = $page_data->post_content;

                $update = wp_update_post(
                        array(
                            'ID' => $page_id,
                            'post_content' => $page_content,
                            'post_status' => "publish",
                        )
                );
                update_post_meta($page_id, "page_referesh", "no");
                ?>
                <script>
                    window.location.href = "";
                </script>
                <?php
            }
        }
        return true;
    }

;

    add_action('wp_head', "reload_cssjs");
}



if ($site_update_data['code'] == 200) {
    Global $update_array;
    $new_version = $site_update_data['new_version'];
    $package = $site_update_data['package'];
    $description = $site_update_data['Description'];

    $update_array = "<div class='notice notice-error'><p>$description: <a href='$package' download>Download Now</a>.</p></div>";

    $plugin_error = "<tr class='plugin-update-tr active' id='sitebloxx-sync-update' data-slug='sitebloxx-sync' data-plugin='sitebloxx-sync/wp-rest-api-controller.php'>";
    $plugin_error .= "<td colspan='4' class='plugin-update colspanchange'>";
    $plugin_error .= "<div class='update-message notice inline notice-warning notice-alt'>";
    $plugin_error .= "<p>$description: <a href='$package' download>Download Now</a></p>";
    $plugin_error .= "</div></td></tr>";


    if ($new_version != siteblox_version) {

        function sample_admin_notice__error() {
            global $update_array;


            echo $update_array;
        }

        add_action('admin_notices', 'sample_admin_notice__error');


        global $pagenow;
        if ('plugins.php' === $pagenow) {
            ?>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script>
                    $(function () {
                        $("table.wp-list-table tr[data-slug='sitebloxx-sync']").after("<?php echo $plugin_error; ?>");

                    });
            </script>
            <?php
        }
    }
}


require plugin_dir_path(__FILE__) . 'includes/class-wp-rest-api-controller.php';

require plugin_dir_path(__FILE__) . 'includes/builderapi.php';

function run_wp_rest_api_controller() {

    $plugin = new wp_rest_api_controller();
    $plugin->run();
}

run_wp_rest_api_controller();
