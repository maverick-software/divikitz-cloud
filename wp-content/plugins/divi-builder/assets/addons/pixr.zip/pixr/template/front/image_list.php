<div class="list-pixbay">
	<div class="row-free-stock">
	  <input type="text" id="search-free-stock" class="field-free-stock" placeholder="Search"/>
	</div>
	<?php if(isset($images) && !empty($images)){ ?>
	<div class="image-list">
		Hi this is test message.
		<div class="row-free-stock" id="free-stock-image-list">

		  	<?php
			    foreach ($images->hits as $key => $image) { 
			      require 'image_element_search.php';
			    } 			
		  	?>
		</div>
		<div class="row-free-stock">
		  <button class="load-button" onClick="next_page(this);" id="free-stock-load-more">Load More</button>
		</div>
	</div>

	<div class="detail">
		
	</div>

	<?php } ?>	
</div>
