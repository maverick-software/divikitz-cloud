
var selection ;
var free_stock_query="";
var free_stock_page = 1;
var is_append = false;
var ajax_url =  pixabay_media_tab_ajax_object.ajax_url;
var free_stock_xhttp = new XMLHttpRequest();
jQuery(document).ready(function($){
    if ( wp.media ) {
      var l10n = wp.media.view.l10n;
      if(wp.media.view.MediaFrame.Select){
        var select = wp.media.view.MediaFrame.Select;
      }else{
        var select = wp.media.view.MediaFrame.ETSelect;
      }
      select.prototype.browseRouter = function( routerView ) {
          routerView.set({
              upload: {
                  text:     l10n.uploadFilesTitle,
                  priority: 20
              },
              browse: {
                  text:     l10n.mediaLibraryTitle,
                  priority: 40
              },
              Pixabay: {
                  text:     "Pixabay",
                  priority: 60
              }
          });
      };
        wp.media.view.Modal.prototype.on( "open", function() {
          if(wp.media.frame){
            selection = wp.media.frame.state().get( "selection" );
          }else{
            selection = wp.media.frames.file_frame.state().get( "selection" );

          }
                        
            if(jQuery('body').find('#menu-item-Pixabay').hasClass('active')){                
                doMyTabContent();
            }
        });
        jQuery(document).on('click', '.media-menu-item', function(e){
          
          if(jQuery(this).attr('id')=="menu-item-Pixabay"){
               doMyTabContent();
          }
        });
    }



    function key_connect(ajax_url, website_url, siteblox_key, siteblox_status, action){
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                'action': action,
                'website_url': website_url,
                'siteblox_key': siteblox_key,
                'siteblox_status': siteblox_status
            },
            beforeSend: function () {               
                swal.fire({
                    customClass: {
                        container: 'swal2_spinner',
                    },
                    html: '<div class="builder_spinner" id="loadingSpinner"></div>',
                    showConfirmButton: false,
                    onRender: function () {
                        $('.swal2-content').prepend(sweet_loader);
                    }
                });
            },
            success: function (resp) {
                if(resp.code==200){
                    Swal.fire({
                        title: "Success!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "success"
                    });
                    setTimeout(function(){
                        window.location.href="";
                    }, 1500);
                } else {
                    Swal.fire({
                        title: "Error!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "error"
                    });
                }
                
            }, error:function(){
                Swal.fire({
                    title: "Error!", 
                    text: "Please try again later",
                    confirmButtonColor: '#000', 
                    icon: "error"
                });
            }
        });
    }



function doMyTabContent() {
    var html = '<div class="pixaby_lists">  </div>';

    html += '<style>.column-free-stock{float:left;width:23%;margin:5px;height:150px}.column-free-stock img{opacity:.8;cursor:pointer;margin-left:auto;margin-right:auto;vertical-align:middle;max-height:150px;max-width:100%}.column-free-stock img:hover{opacity:1}.row-free-stock:after{content:"";display:table;clear:both}.row-free-stock{margin-top:20px;padding-left:10px;padding-right:10px}.field-free-stock{width:100%}.load-button{margin-left:40%}.list-pixbay{width:100%}.list-pixbay .image-list{width:75%;float:left}.list-pixbay .detail{width:23%;float:right;padding-top:20px;padding-left:10px}.active img{opacity:1;border:3px solid #4f94d4}#free-stock-image-list{max-height:500px;overflow:auto}</style>';
    
    jQuery('body .media-modal-content .media-frame-content:visible')[0].innerHTML = html;
    free_stock_list_add_media();
}

  

  function free_stock_list_add_media() {

    free_stock_xhttp.abort();
    
   free_stock_xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var list = JSON.parse(this.responseText);      

        document.getElementById("free-stock-load-more").innerHTML = "Load More"; 
        document.getElementById("search-free-stock").style.display = "Block"; 
        if(is_append){
          jQuery('body .media-modal-content .media-frame-content:visible').find("#free-stock-image-list")[0].innerHTML = jQuery('body .media-modal-content .media-frame-content:visible').find("#free-stock-image-list")[0].innerHTML+list.list; 
        }else{
          jQuery('body .media-modal-content .media-frame-content:visible').find("#free-stock-image-list")[0].innerHTML = list.list; 
        }
       }
     };

    free_stock_xhttp.open("POST", ajax_url, true);
    free_stock_xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    free_stock_xhttp.setRequestHeader("Accept", "application/json");

    var ajax_url = pixlapi.ajax_url;
    var imageurl = pixlapi.imageurl;
    var website_url = pixlapi.siteurl;
    var builder_key = pixlapi.builder_key;
    var api_token = pixlapi.api_token;
    var account_image = imageurl + "/images/account-icon.png";
    if (ajax_url == "activate") {
        var error_image = imageurl + "/images/error-frame.png";
        Swal.fire({
            title: "<img src='" + error_image + "'/> Error!",
            text: "Please activate Divi theme or Divi Builder plugin for continue",
            confirmButtonColor: '#000'
        });
    } 

    else if (ajax_url == "disconnect") {
        Swal.fire({
            title: "<img src='" + account_image + "'/>Account Verification",
            text: "Please enter your API key to gain access to the bloxx builder and library.",
            input: 'text',
            showCancelButton: false,
            confirmButtonColor: '#9F05C5',
            //cancelButtonColor: '#000',
            confirmButtonText: 'Submit',
            showCloseButton: true,
            customClass: {
                container: 'pixl_swal',
            },
            footer: '<a target="_blank" href="https://app.gobloxx.io/bloxx-account/" id="some-action">Get your API key here <i class="fas fa-angle-double-right"></i></a>',
            inputValidator: (value) => {
                if (!value) {
                    return 'Enter Your Bloxx API Key'
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                siteblox_key = result.value;
                var action = "siteblox_keysaved";
                var ajax_url = pixaby.ajax_url;
                var siteblox_status = "siteblox_connect";
                key_connect(ajax_url, website_url, siteblox_key, siteblox_status, action);
            }
        });
    } else {
        //free_stock_xhttp.send("action=pixaby_load_onload&builder_key="+api_token+"&searchKey="+free_stock_query+"&pageing="+free_stock_page);
        $.ajax({
          type: "POST",
          url: pixlapi.ajax_url,
          crossDomain: true,
          data: {
              'action': 'pixaby_load_onload',
              'builder_key': builder_key,
              'api_token': api_token,                
              'searchKey': free_stock_query,
              'pageing': free_stock_page
          },
          beforeSend: function () {
              //$this.html(cat_text + ' <i class="fa fa-spinner fa-spin"></i>');
              $(".sections_lists section").removeClass("active_slide");
              $(".sections_lists .builder_posts").hide();
          },
          success: function (resp) {
              if ($.trim(resp) == "Data_not_found") {
                  var imageurl = pixlapi.imageurl;
                  var error_image=imageurl+"/images/error-frame.png";
                  Swal.fire({
                      title: "<img src='"+error_image+"'/> Error!",
                      text: "Oops! Looks like your current API key isn’t working! Generate a new API key or check your Bloxx plan",
                      confirmButtonColor: '#000'                                
                  });                   
              } else {  
                  Swal.close();                                      
                  $(".pixaby_lists").html('<div id="myModal" class="custom_modal"><div class="modal-content"><span class="close">&times;</span><div class="body_content"><img src=""/><a class="button button-primary" id="pixel_importimg" href="javascript:void(0)">Import Cropped Image</a></div></div></div>'+$.trim(resp));   
              }

          },
          error: function () {
              var imageurl = pixlapi.imageurl;
              var error_image=imageurl+"/images/error-frame.png";
              Swal.fire({
                  title: "<img src='"+error_image+"'/> Error!",
                  text: "Please try again latter",
                  confirmButtonColor: '#000'                                
              }); 
          }
      });
    }
  }

  

   function free_stock_image_click(ele){
    var image_data = jQuery(ele).data('image');
    jQuery(".column-free-stock").removeClass('active');
    jQuery(ele).parent().addClass('active');
    delete image_data.id;
    delete image_data.user_id;
    delete image_data.user;
    delete image_data.userImageURL;
    delete image_data.comments;
    delete image_data.collections;
    delete image_data.downloads;
    delete image_data.views;
    delete image_data.imageSize;
    //var html = "<button class='button button-primary button-large free_stock_import_button' onClick='add_url(\""+image_data['largeImageURL']+"\")' > Import Image</button><hr>";
    var html = "<button class='button button-primary' id='import_pixr_croppe' data-id='"+image_data['largeImageURL']+"'>Import Image</button><hr>";
   
    for (var key in image_data) {
       var obj = image_data[key];
        
      html +="<b>"+key+":</b><br/> "+obj+"<hr>";
    }
    jQuery(".list-pixbay").find(".detail").html(html);
    
  }


});