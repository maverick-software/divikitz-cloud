<?php

 /*
 * Plugin name: Pixr
 * Description: Image API integration for pixabay.com Use shortcode [free_stock_image] to display image
 * Version: 1.0.2
 * Author: Bloxx
 * Author URI: https://app.gobloxx.io/
 * License: GPL v2
 */

define('pixl_url', plugin_dir_url(__FILE__));
define('pixl_path', plugin_dir_path(__FILE__));
define('pixl_plugin', plugin_basename(__FILE__));
define('pixl_apiurl', "https://app.divibloxx.com/");



require 'include/API_call.php';
class Free_Stock_Image{
	
	public function __construct(){
		add_action("wp_ajax_free_stock_list", array($this, "free_stock_list"));
		add_action("wp_ajax_nopriv_free_stock_list", array($this, "free_stock_list"));

		add_action("wp_ajax_free_stock_list_media_element", array($this, "free_stock_list_media_element"));
		add_action("wp_ajax_nopriv_free_stock_list_media_element", array($this, "free_stock_list_media_element"));

		add_action("wp_ajax_free_stock_add_media", array($this, "free_stock_add_media"));
		add_action("wp_ajax_nopriv_free_stock_add_media", array($this, "free_stock_add_media"));
		
		add_action('admin_menu', array($this, 'setting_menu'));	
		add_shortcode('free_stock_image', array($this, 'free_stock_image_list'));


		//Admin check API
        add_action("wp_ajax_siteblox_keysaved", array($this, "siteblox_keysaved"));
        add_action("wp_ajax_nopriv_siteblox_keysaved", array($this, "siteblox_keysaved"));


        //Get Admin JS and CSS
        add_action('admin_enqueue_scripts', array($this, 'admin_css_jsscripts'));
        add_action('wp_enqueue_scripts', array($this, 'admin_css_jsscripts'));
	}   


    function admin_css_jsscripts() { 
       wp_enqueue_script('pixl_swal', plugin_dir_url(__FILE__) . 'assets/js/sweetalert.min.js?v=' . time());

        wp_enqueue_style('croppiecss', plugin_dir_url(__FILE__) . 'assets/css/croppie.css');
        wp_enqueue_script('croppiejs', plugin_dir_url(__FILE__) . 'assets/js/croppie.js?v=' . time());

        wp_enqueue_style('pixabycss', plugin_dir_url(__FILE__) . 'assets/css/style.css', array(), time());


        $ajax_url = admin_url( 'admin-ajax.php' );
        wp_enqueue_script( 'pixabay-media-tab', plugin_dir_url( __FILE__ ) . 'assets/js/media_element.js', array( 'jquery' ), '1.0.2', true );
    
        $ajax_url = admin_url( 'admin-ajax.php' );
        wp_localize_script( 'pixabay-media-tab', 'pixabay_media_tab_ajax_object', 
            array( 
                'ajax_url' => $ajax_url,
                
            ) 
        );


        //script.js
        $blox_api=$this->basicApiextension();
        wp_enqueue_script('pixabyjs', plugin_dir_url(__FILE__) . 'assets/js/script.js?v=' . time());
        wp_localize_script('pixabyjs', 'pixaby', array('ajax_url' => admin_url('admin-ajax.php')));
        wp_localize_script('pixabyjs', 'pixlapi', $blox_api);
    }


	//Check API Connection
    public function siteblox_keysaved() {
        
        extract($_REQUEST);
        $current_user = wp_get_current_user();
        $current_user_id = $current_user->ID;
        update_option('siteblox_key', $siteblox_key);
        $website_nm=get_option('blogname', true);
        $connect_data = array(
            'website_url' => $website_url,
            'server_userid' => $current_user_id,
            'siteblox_key' => $siteblox_key,
            'website_nm' => $website_nm
        );

        $siteblox_json = json_encode($connect_data);

        

        if ($siteblox_status == "siteblox_connect") {
            $conn_apiurl=pixl_apiurl."wp-json/siteblox-api/connect";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $conn_apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $siteblox_json,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                $result = array(
                    'code' => 202,
                    'message' => $err
                );
            } else {
                $siteblox_resp = json_decode($response, true);
                if ($siteblox_resp['code'] == 200) {
                    update_option('bloxx_api_url', $siteblox_resp['section_api']);
                    update_option('bloxx_api_token', $siteblox_resp['api_token']);
                    update_option('builder_key', $siteblox_key);
                    update_option('bloxx_user_id', $siteblox_resp['user_id']);
                    update_option('bloxx_term_id', @$siteblox_resp['term_id']);
                    update_option('bloxxbuilder_connect', 'yes');
                }
                echo $response;
            }
        } else {
            $disconn_apiurl=pixl_apiurl."wp-json/siteblox-api/disconnect";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $disconn_apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $siteblox_json,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                $result = array(
                    'code' => 202,
                    'message' => $err
                );
            } else {
                $siteblox_resp = json_decode($response, true);
                if ($siteblox_resp['code'] == 200) {
                    update_option('bloxxbuilder_connect', 'no');
                    update_option('bloxx_api_url', "disconnect");
                    update_option('bloxx_api_token', "disconnect");
                    update_option('builder_key', '');
                }
                echo $response;
            }
        }
        die();
    }


	

	function free_stock_add_media(){
        extract($_REQUEST);
        $image_url = $_REQUEST['url'];
        if($_REQUEST['image_type']=="enable_base_encode"){
            $this->free_stock_add_media_base64($image_url);
        } else {        
    		$upload_dir = wp_upload_dir();
    		$image_data = file_get_contents($image_url);
    		$filename = basename($image_url);
    		if(wp_mkdir_p($upload_dir['path']))
    		    $file = $upload_dir['path'] . '/' . $filename;
    		else
    		    $file = $upload_dir['basedir'] . '/' . $filename;
    		file_put_contents($file, $image_data);

    		$wp_filetype = wp_check_filetype($filename, null );
    		$attachment = array(
    		    'post_mime_type' => $wp_filetype['type'],
    		    'post_title' => sanitize_file_name($filename),
    		    'post_content' => '',
    		    'post_status' => 'inherit'
    		);
    		$attach_id = wp_insert_attachment( $attachment, $file );
    		require_once(ABSPATH . 'wp-admin/includes/image.php');
    		$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
    		wp_update_attachment_metadata( $attach_id, $attach_data );
    		echo json_encode(array("post_id"=>$attach_id)); die;
        }
	}


    function free_stock_add_media_base64($encoded_image){
        $base64DataString  = $encoded_image;
        $upload_dir = wp_upload_dir();

        $img = str_replace('data:image/png;base64,', '', $base64DataString);
        $img = str_replace(' ', '+', $img);
        $data = base64_decode($img);

        $filename="pixr_".uniqid().".png";
        if(wp_mkdir_p($upload_dir['path'])){
            $file = $upload_dir['path'] . '/' . $filename;
        } else {
            $file = $upload_dir['basedir'] . '/' . $filename;
        }       

        file_put_contents($file, $data);

        $wp_filetype = wp_check_filetype($file, null );
        

        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment( $attachment, $file );
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
        wp_update_attachment_metadata( $attach_id, $attach_data );
        echo json_encode(array("post_id"=>$attach_id)); die;
    }


	
	function setting_menu(){
	    add_submenu_page( 'upload.php', 'Pixabay', 'Pixabay', 'manage_options','Pixabay_image',array($this,  'free_stock_image_list_page'), 1 );
	}

	



	function basicApiextension(){
        include_once(ABSPATH.'wp-admin/includes/plugin.php');
        $builderapi_url = get_option('bloxx_api_url', true);
        $theme = wp_get_theme();
        $er = 0;
        $divi_type="activate";
        if ('Divi' == $theme->name) {               
            $er = 1;
            $divi_type="theme_activated";
        } else if ('Divi Child Theme' == $theme->name) {
            $divi_type="theme_activated";
            $er = 1;        
        } else if (is_plugin_active( 'divi-builder/divi-builder.php' ) ) {
            $divi_type="plugin_activated";
            $er = 1;        
        }

        $ajax_data=array();
        
        if($er==0){
            $ajax_data= array(
                'builder_key' => "activate",
                'api_token' => "activate",
                'ajax_url' => "activate",
                'key_url'=> $builderapi_url,
                'imageurl'=> pixl_url,
                'enable'=> $divi_type,
                'siteurl'=>site_url()
            );
        } else {
            $builder_connect="no";
            if(get_option('bloxxbuilder_connect')!=""){
                $builder_connect = get_option('bloxxbuilder_connect', true);
            }

            if ($builder_connect == "yes") {
                $builder_key=get_option('builder_key', true);
                $api_token=get_option('bloxx_api_token', true);
                $ajax_data= array(
                    'ajax_url' => $builderapi_url,
                    'builder_key' => $builder_key,
                    'api_token' => $api_token,
                    'key_url'=> $builderapi_url,
                    'imageurl'=> pixl_url,
                    'enable'=> $divi_type,
                    'siteurl'=>site_url()
                );
            } else {
                $ajax_data= array(
                    'builder_key' => "disconnect",
                    'api_token' => "disconnect",
                    'ajax_url' => "disconnect",
                    'key_url'=> $builderapi_url,
                    'imageurl'=> pixl_url,
                    'enable'=> $divi_type,
                    'siteurl'=>site_url()
                );
            }
        }
        return $ajax_data;
    }

	

	function free_stock_image_list_page(){
		$API = new API_call();
		$images = $API->call();
		
        ?>
        <div class="pixaby_lists">
            <!-- Ajax List -->
        </div>

        <?php
	}




    function resp_images(){


        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://app.gobloxx.io/retrieve-section-sidebar-api/",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $siteblox_json,
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);


    }




	function free_stock_image_list(){
		$API = new API_call();

		$images = $API->call();
		echo "<style>".file_get_contents(plugin_dir_path(__FILE__).'/assets/css/style.css')."</style>";

		require 'template/front/image_list.php';

	 	echo "<script> var ajax_url= '".admin_url( 'admin-ajax.php' )."';var plugin_url= '".plugin_dir_url(__FILE__)."';".file_get_contents(plugin_dir_path(__FILE__).'/assets/js/script.js')."</script>";
		$output .= ob_get_contents();
		ob_end_clean();
		return $output;
	}


	
	function free_stock_list(){
		$query = $_REQUEST['q'];
		$page = $_REQUEST['p'];
		$API = new API_call();
		$API->set_query($query);
		$API->set_page($page);
		$images = $API->call();

		ob_start();

	    foreach ($images->hits as $key => $image) { 

	      require 'template/front/image_element_search.php';

	    } 

		$output = ob_get_contents();
		ob_end_clean();
		
		echo json_encode(array('list'=>$output));
		die;
	}
    
	function free_stock_list_media_element(){
		$query = $_REQUEST['q'];
		$page = $_REQUEST['p'];
		$API = new API_call();
		$API->set_query($query);
		$API->set_page($page);
		$images = $API->call();

		ob_start();

	    foreach ($images->hits as $key => $image) { 

	      require 'template/front/image_element.php';

	    } 

		$output = ob_get_contents();
		ob_end_clean();
		
		echo json_encode(array('list'=>$output));
		die;
	}
}
$Free_Stock_Image = new Free_Stock_Image();

?>