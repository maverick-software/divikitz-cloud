<?php
$builder_connect="no";
if(get_option('bloxxbuilder_connect')!=""){
    $builder_connect = get_option('bloxxbuilder_connect');
}

$builder_key = get_option('builder_key');
?>

<h2>Bloxx Builder Connectivity</h2>

<form method="POST" id="siteblox_connectivity">
    <section class="object-meta-data taxonomy-meta-data">
        <table class="widefat fixed siteblox-table" cellspacing="0">
            <tbody>
                <tr>
                    <th>Enter API KEY</th>
                </tr>
                <tr class="alternate">
                    <td>
                        <input name="website_url" type="hidden" value="<?php echo site_url(); ?>">
                        <input name="siteblox_key" id="siteblox_key" type="text" value="<?php
                        if (isset($builder_key)) {
                            echo $builder_key;
                        }
                        ?>" placeholder="Please enter your API Key" required>
                        <input type="hidden" name="action" value="siteblox_key_saved">
                    </td>
                </tr>
            </tbody>
        </table>
    </section>

    <div class="submit-buttons">

        <?php if ($builder_connect == "yes") { ?>
            <input type="hidden"  id="siteblox_status" name="siteblox_status" value="siteblox_disconnect">
            <button type="submit" id="save_connectivity" class="button button-danger">Disconnect</button>
        <?php } else { ?>
            <input type="hidden" id="siteblox_status" name="siteblox_status" value="siteblox_connect">
            <button type="submit" id="save_connectivity" class="button button-pro">Connect</button>
<?php } ?>
    </div>
</form>
