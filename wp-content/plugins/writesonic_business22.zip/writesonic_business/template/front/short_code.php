<?php 
	$user_credit = get_user_meta(get_current_user_id(),'writesonic_credit',true);//print_r($user_credit);
	if(empty($user_credit)){
		$user_credit = 0;
	}
	
?>

<div class="form_div">
	<?php if(!isset($_GET['type'])){?>
	<div class="writesonic_form field">
		<!-- <label for="select_type">Select type of AI</label> -->
		<div class="sonicGrid">
			<p class="credit-score">Total credits: <?= $user_credit;?></p>
			<h2 class="text-center">CREATE A COPY</h2>
			<p class="text-center">What kind of copy you would you like Writesonic to generate? Please select from one of the copy types below.</p>
			<p class="text-center"><a href="javascript:void(0)" data-href="<?php echo site_url();?>?add-to-cart=<?php echo get_option( 'writesonic_bussiness_credit_product' ); ?>" class="buy-credit">Buy Credits</a></p>
			<div class="bgWhite">
				<div class="rowWrap">
					<!-- <select name="select_type" id="select_type" onchange="show_form();"> -->
					<?php 
						$integration = $this->integration;
						$writesonic_credit = json_decode(get_option( 'writesonic_credit' ),true);
						
						foreach ($integration as $key => $api) { ?>
							<div class="flex-12 cat-title">
								<h3><?= ucfirst(str_replace('-',' ',$key)) ;?></h3>
							</div>
							<?php foreach ($api as $key1 => $value) {
								
							
					?>
			
					<div class="flex-3 mBottom" <?php if($user_credit >= $writesonic_credit[$value['slug']]):?>onclick="show_form('<?php echo $value['slug']; ?>','<?php echo $key;?>');" <?php else :?> onclick="gotobuycredit()" <?php endif;?>>
					<!-- <div class="flex-3 mBottom" onclick="show_form('<?php echo $value['slug']; ?>','<?php echo $key;?>');" > -->
						<div class="sonicColumn">
							<div class="sonicIcon">
								<img src="<?php echo $value['thumb']; ?>">
								<span class="credits"><i class="fas fa-dollar-sign"></i> Credits: <?= $writesonic_credit[$value['slug']];?></span></div>
							<h3><?php echo $value['name']; ?></h3>
							<p><?php echo $value['desc']; ?></p>
						</div>
					</div>
					<?php
							}?>
						
						<?php
						}
					?>
				</div>
			</div>
		</div>
	
	</div>
	<?php } ?>
			

<?php 
	if(isset($_GET['type']) && !empty($_GET['type']) && isset($_GET['category']) && !empty($_GET['category'])){
				
		$writesonic_credit = json_decode(get_option( 'writesonic_credit' ),true); //echo "<pre>";print_r($writesonic_credit);
		$credit_required = $writesonic_credit[$_GET['type']];
		 ?>

		
			<input type="hidden" id="select_type" name="select_type" value="<?= $_GET['type'];?>">
			<input type="hidden" id="select_cat" name="select_cat" value="<?= $_GET['category'];?>">
			
			
			<div class="sonicTitle">	
				<h2><?= str_replace('-',' ',$_GET['type']);?> Descriptions</h2>	
				<p><span class="credits"><i class="fas fa-dollar-sign"></i> Credits: <?= $writesonic_credit[$_GET['type']];?></span></p>
				<p>Describe your product/service below and get personalized <?= ucwords(str_replace('-',' ',$_GET['type']));?> Descriptions in a click.</p>
				<form>
				<table class="form-table" role="presentation">
					<tbody>
						<tr class="select_type-wrap">
							
							<th><label for="engine">Engine</label></th>
							<td>
								<select id="engine" class="field">
									
										<option value="economy">Economy</option>
										<option value="business">Business</option>
									
								</select>
							</td>
							<th>Language</th>
							<td>
								<select id="language" class="field">
									<option value="en">en</option>
									<option value="nl">nl</option>
									<option value="fr">fr</option>
									<option value="de">de</option>
									<option value="it">it</option>
									<option value="pl">pl</option>
									<option value="es">es</option>
									<option value="pt-pt">pt-pt</option>
									<option value="pt-br">pt-br</option>
									<option value="ru">ru</option>
									<option value="ja">ja</option>
									<option value="zh">zh</option>
									<option value="bg">bg</option>
									<option value="cs">cs</option>
									<option value="da">da</option>
									<option value="el">el</option>
									<option value="hu">hu</option>
									<option value="lt">lt</option>
									<option value="lv">lv</option>
									<option value="ro">ro</option>
									<option value="sk">sk</option>
									<option value="sl">sl</option>
									<option value="sv">sv</option>
									<option value="fi">fi</option>
									<option value="et">et</option>
									
								</select>
							</td>
						</tr>
					</tbody>
				</table>
				</form>
				<?php
				require dirname(dirname(__FILE__))."/forms/".$_GET['type'].".php";
				?>
				<p class="submit"><input type="button" name="submit" id="submit" class="button button-primary" value="Generate <?= ucwords(str_replace('-',' ',$_GET['type']));?>" onclick="searchData();"></p>
			</div>
				
		<?php 
	}
?>

</div>
<div class="result_div" style="display:none;">
	<h2 class="wp-heading-inline">Result <a href="#" id="back_button">Back</a></h2>	
	<ol id="result_list">
		
	</ol>
</div>