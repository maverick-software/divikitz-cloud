<form id="summary" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Article Url <span class="require">*</span></th>
					<td><input type="text" id="article_url" name="article_url" placeholder="Article Url" class="summary field" required/></td>
				</tr>
				<tr>
					<th>Article Text</th>
					<td><textarea id="article_text" name="article_text" class="summary field" placeholder="Article Text" required></textarea></td>
				</tr>
				
			</tbody>
		</table>
	</form>