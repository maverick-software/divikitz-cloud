<form id="growth-ideas" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Product Name <span class="require">*</span></th>
					<td><input type="text" id="product_name" name="product_name" class="growth-ideas field" placeholder="Product Name" required/></td>
				</tr>
				<tr>
			
					<th>Product Description <span class="require">*</span></th>
					<td><textarea id="product_description" name="product_description" class="growth-ideas field" placeholder="Product Description" required></textarea></td>
				</tr>
				<tr>
					<th>Target Keywords <span class="require">*</span></th>
					<td><input type="text" id="target_keywords" name="target_keywords" class="growth-ideas field" placeholder="Target Keywords" required/></td>
				</tr>
				<tr>
					<th>Target Audience <span class="require">*</span></th>
					<td><input type="text" id="target_audience" name="target_audience" class="growth-ideas field" placeholder="Target Audience" required/></td>
				</tr>
			</tbody>
		</table>
	</form>