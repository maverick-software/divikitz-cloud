<form id="content-rephrase-model-two" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Content To Rephrase <span class="require">*</span></th>
					<td><textarea id="content_to_rephrase" name="content_to_rephrase" class="content-rephrase-model-two field" required></textarea></td>
				</tr>
				<tr>
					<th>Tone Of Voice <span class="require">*</span></th>
					<td>
						<select name="tone_of_voice" id="tone_of_voice" class="content-rephrase-model-two field">
							<option value="excited">Excited</option>
							<option value="professional">Professional</option>
							<option value="funny">Funny</option>
							<option value="encouraging">Encouraging</option>
							<option value="dramatic">Dramatic</option>
							<option value="witty">Witty</option>
							<option value="sarcastic">Sarcastic</option>
							<option value="engaging">Engaging</option>
							<option value="creative">Creative</option>
						</select>
					</td>
				</tr>
				
				
			</tbody>
		</table>
	</form>