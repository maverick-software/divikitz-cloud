<form id="facebook-ads" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Product Name <span class="require">*</span></th>
					<td><input type="text" id="product_name" name="product_name" class="facebook-ads field" placeholder="Product Name" required/></td>
				</tr>
				<tr>
					<th>Product Description <span class="require">*</span></th>
					<td><textarea id="product_description" name="product_description" class="facebook-ads field" placeholder="Product Description" required></textarea></td>
				</tr>
				<tr>
					<th>Occasion <span class="require">*</span></th>
					<td><input type="text" id="occasion" name="occasion" class="facebook-ads field" placeholder="Occasion" required/></td>
				</tr>
				<tr>
					<th>Promotion <span class="require">*</span></th>
					<td><input type="text" id="promotion" name="promotion" class="facebook-ads field" placeholder="Promotion" required/></td>
				</tr>
			</tbody>
		</table>
	</form>