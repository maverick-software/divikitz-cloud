<form id="startup-ideas" style="display: none;">
	<table class="form-table" role="presentation">
		<tbody>
			
			<tr>
				<th>Idea</th>
				<td><textarea id="idea" name="idea" class="google-ads field"  required></textarea></td>
			</tr>
			
		</tbody>
	</table>
</form>