var bloxx = {"ajax_url":window.location.origin+"/wp-admin/admin-ajax.php"};
var intervl = '';
jQuery(document).ready( function ($) {
    //  $('#template_table').DataTable();
    if(jQuery("#bloxxapp_table").length > 0){
        var dataTable = $('#bloxxapp_table').DataTable({"language": {
            'paginate': {
                'previous': '<i class="fa fa-angle-left"></i>',
                'next': '<i class="fa fa-angle-right"></i>'
            },
            "emptyTable": "You do not currently have any applications saved in your account. <a href='javascript:void(0)' class='add_app'>Create a new application</a> to get started"
        }});

        if(document.getElementById("pending_process_count").value == '1'){
            document.getElementById("operation_status").innerHTML = 'Please wait while your application is creating....';
            document.getElementById("operation_status").style.display = 'inline-block';
            document.getElementById("pending_process_count").value = 1;
        }
    }
});

jQuery(document).on('click','.add_app',function(){
    jQuery("#add_app-main").show();
});

jQuery(document).on('submit','#bloxx_app',function(e){
    e.preventDefault();
    jQuery("#createapp-btn").prop('disabled',true);
    jQuery("#createapp-btn").html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        async: false,
        data : jQuery("#bloxx_app").serialize(),            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery("#createapp-btn").prop('disabled',false);
            jQuery("#createapp-btn").html('Create');
            if(resp.code ==200){
                document.getElementById("operation_status").innerHTML = 'Please wait while your application is creating....';
                document.getElementById("operation_status").style.display = 'inline-block';
                document.getElementById("pending_process_count").value = 1;
                // setTimeout(function(){
                //     location.reload();
                // },2000);
                jQuery("#add_app-main").hide();
            }
        }
    });
    intervl = setInterval(checkforappstatus, 10000);
});

function checkforappstatus() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            if(xhr.responseText.replace(/\s+/g, '') == 'completed'){
                clearInterval(intervl);
                document.getElementById("pending_process_count").value = 0;
                document.getElementById("operation_status").innerHTML = 'Application Created Successfully.';
                setTimeout(function(){document.getElementById("operation_status").style.display = 'none';location.reload();},2000);   
            }
        }
    }
    xhr.open('GET', bloxx.ajax_url+'?action=application_status', true);
    xhr.send(null);
}
jQuery(document).on('submit','#bloxx_app_crendentials',function(e){
    e.preventDefault();

    if(!isUpper(jQuery("input[name=password]").val()) || !hasLowerCase(jQuery("input[name=password]").val()) || !hasNumbers(jQuery("input[name=password]").val())){
        //jQuery("#res-msg").html('Password should contain at least one lowercase character, at least one uppercase character and at least one number');
        swal.fire('Password should contain at least one lowercase character, at least one uppercase character and at least one number');
        return false;
    }
    jQuery("#add_cred-btn").prop('disabled',true);
    jQuery("#add_cred-btn").html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : jQuery("#bloxx_app_crendentials").serialize(), 
        beforeSend: function() {
            swal.fire({
                html: '<h5>Loading...</h5>',
                showConfirmButton: false,
                onRender: function() {
                    $('.swal2-content').prepend(sweet_loader);
                }
            });
        },           
        success: function(resp) {
            swal.close();
            swal.fire(resp.message);
            jQuery("#add_cred-btn").prop('disabled',false);
            jQuery("#add_cred-btn").html('Submit');
            if(resp.code ==200){
                setTimeout(function(){
                    location.reload();
                },2000);
            }
        }
    });
});

jQuery(document).on('click',"#savedomain-btn",function(){
    var alldomains = jQuery("input.subdomains").serializeArray();
    jQuery("#savedomain-btn").prop('disabled',true);
    jQuery("#savedomain-btn").html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : {server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'action':'app_domain_save','domain':alldomains},            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery("#savedomain-btn").prop('disabled',false);
            jQuery("#savedomain-btn").html('Add Domain');
            if(resp.code ==200){
                // setTimeout(function(){
                //     window.location.href = window.location.origin + '/bloxx-applications/';
                // },2000);
                
            }
        }
    });
});


function ajaxpostsend(datatosend,element,el_text,isreload = true){
    jQuery(element).prop('disabled',true);
    jQuery(element).html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : datatosend,            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery(element).prop('disabled',false);
            jQuery(element).html(el_text);
            if(resp.code ==200){
                if(isreload === true){
                    setTimeout(function(){
                        window.location.href = window.location.origin + '/bloxx-applications/';
                    },2000);
                }
            }
        }
    });
}

jQuery(document).on('click',"#primry_domain-btn",function(){
    ajaxpostsend({server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'app_name':jQuery("input[name=current_app_name]").val(),'action':'primary_domain','domain':jQuery("input[name=primary_domain]").val()},"#primry_domain-btn",'Add Domain',false);
});

function savedb(el){
    if(!isUpper(jQuery("input[name=db_new_password]").val()) || !hasLowerCase(jQuery("input[name=db_new_password]").val()) || !hasNumbers(jQuery("input[name=db_new_password]").val())){
        swal.fire('Password should contain at least one lowercase character, at least one uppercase character and at least one number');
        return false;
    }
    jQuery(el).prop('disabled',true);
    jQuery(el).html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : {server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'action':'save_db_credentials','password':jQuery("input[name=db_new_password]").val()},            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery(el).prop('disabled',false);
            jQuery(el).html('Submit');
            if(resp.code ==200){
                setTimeout(function(){
                    window.location.href = '';
                },2000);
                
            }
        }
    });
}


function saveapp_password(el){
    if(!isUpper(jQuery("input[name=admin_new_password]").val()) || !hasLowerCase(jQuery("input[name=admin_new_password]").val()) || !hasNumbers(jQuery("input[name=admin_new_password]").val())){
        swal.fire('Password should contain at least one lowercase character, at least one uppercase character and at least one number');
        return false;
    }
    jQuery(el).prop('disabled',true);
    jQuery(el).html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : {server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'action':'save_admin_credentials','password':jQuery("input[name=admin_new_password]").val()},            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery(el).prop('disabled',false);
            jQuery(el).html('Submit');
            if(resp.code ==200){
                setTimeout(function(){
                    window.location.href = '';
                },2000);
                
            }
        }
    });
}


jQuery(document).on('click','.create_cred',function(e){
    jQuery("input[name=server_id]").val(jQuery(this).data('server-id'));
    jQuery("input[name=app_id]").val(jQuery(this).data('app-id'));
    jQuery("input[name=type]").val('add');
    jQuery("#add_credentials-main").show();
});

function isUpper(str) {
    return /[A-Z]/.test(str);
}

function hasLowerCase(str) {
    return (/[a-z]/.test(str));
}

function hasNumbers(t)
{
var regex = /\d/g;
return regex.test(t);
}  

function showpass(el){
    if(jQuery(el).hasClass('hide-pass')){
        jQuery(el).addClass('show-pass').removeClass('hide-pass');
        jQuery(el).parent().children('label').children('span').html(jQuery(el).parent().data('pass')+'<span class="hovertiptext">Click to copy.</span>');
    }else{
        jQuery(el).addClass('hide-pass').removeClass('show-pass');
        jQuery(el).parent().children('label').children('span').html('.....<span class="hovertiptext">Click to copy.</span>');
    }
}

function changeCredentials(el){
    jQuery("input[name=server_id]").val(jQuery("input[name=current_server_id]").val());
    jQuery("input[name=app_id]").val(jQuery("input[name=current_app_id]").val());
    jQuery("input[name=username]").val(jQuery(el).parent().data('user'));
    jQuery("input[name=cred_id]").val(jQuery(el).parent().data('id'));
    jQuery("input[name=type]").val('update');
    jQuery("#add_credentials-main").show();
}

function updatepass(el){
    if(jQuery(el).data('action') == 'update'){
        jQuery(el).parent().children('label').children('span').hide();
        jQuery(el).hide();
        jQuery(el).next('a').hide();
        jQuery("#pass-form").show();
    }else{
        jQuery('.pass-btn').parent().children('label').children('span').show();
        jQuery('.pass-btn').show();
        jQuery('.pass-btn').next('a').show();
        jQuery("#pass-form").hide();
    }
}

function updatedb(el){
    if(jQuery(el).data('action') == 'update'){
        jQuery(el).parent().children('label').children('span').hide();
        jQuery(el).hide();
        jQuery(el).next('a').hide();
        jQuery("#db-form").show();
    }else{
        jQuery('.db-btn').parent().children('label').children('span').show();
        jQuery('.db-btn').show();
        jQuery('.db-btn').next('a').show();
        jQuery("#db-form").hide();
    }
}

jQuery(document).on('click',".tab-links",function(){
    jQuery(this).parent().addClass('active').siblings().removeClass('active');
    jQuery(".tab-content").removeClass('hide').addClass('hide');
    jQuery("#"+jQuery(this).data('tab')).removeClass('hide');console.log(jQuery(this).data('tab'));
    if(jQuery(this).data('tab') != 'access-details' && jQuery(this).data('tab') != 'cloudwayscdn'){
        renderelementHTML("#"+jQuery(this).data('tab'),{action:jQuery(this).data('action'),'server_id':jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val()});

    }
});


function backupnow(el){
    jQuery(el).prop('disabled',true);
    jQuery(el).html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : {server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'action':'take_backup'},            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery(el).prop('disabled',false);
            jQuery(el).html('Take Backup Now');
            if(resp.code ==200){
                document.getElementById("pending_process_count").value = 1;
                setTimeout(function(){
                    jQuery('a[data-tab="backup"]').trigger('click');
                },2000);
                
            }
        }
    });
}

function installCertificate(el){
    jQuery(el).prop('disabled',true);
    jQuery(el).html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : {server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'action':'installCertificate','email':jQuery("input[name=email]").val(),'dname':jQuery("input[name=dname]").val(),'ssl_method':jQuery("select[name=ssl_method]").val()},            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery(el).prop('disabled',false);
            jQuery(el).html('Intall Certificate');
            if(resp.code ==200){
                setTimeout(function(){
                    jQuery('a[data-tab="ssl"]').trigger('click');
                    //window.location.href = window.location.origin + '/bloxx-applications/';
                },2000);
                
            }
        }
    });
}

jQuery(document).on('click',"#restore-btn", function(e){
    if(jQuery("select[name=restore]").val() === null || jQuery("select[name=restore]").val() == ''){
        swal.fire('Please select a restore point.');
        return false;
    }
    jQuery(this).prop('disabled',true);
    jQuery(this).html('Please wait...');
    var ajax_url=bloxx.ajax_url;
    jQuery.ajax({
        type : "POST",
        url : ajax_url,
        dataType : "json",
        data : {server_id:jQuery("input[name=current_server_id]").val(),'app_id':jQuery("input[name=current_app_id]").val(),'action':'restore_app','time':jQuery("select[name=restore]").val()},            
        success: function(resp) {
            swal.fire(resp.message);
            jQuery("#restore-btn").prop('disabled',false);
            jQuery("#restore-btn").html('Restore Application Now');
            if(resp.code ==200){
                document.getElementById("pending_process_count").value = 1;
                setTimeout(function(){
                    jQuery('a[data-tab="backup"]').trigger('click');
                },2000);
                
            }
        }
    });
});


function renderelementHTML(element,params){
    jQuery(".app-loader").show();
    jQuery(element).html('');
    // jQuery(element).css('pointer-events','none');
    jQuery.ajax({
        type : "POST",
        url : bloxx.ajax_url,
        data : params,          
        success: function(resp) {
            jQuery(".app-loader").hide();
            // jQuery(element).css('pointer-events','all');
            jQuery(element).html(resp);
        }
    });
}

window.addEventListener('DOMContentLoaded', (event) => {
    if(document.getElementById("accessDetails_container")){
        setInterval(function(){
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == XMLHttpRequest.DONE) {
                    if(xhr.responseText.replace(/\s+/g, '') != 'success'){
                        document.getElementById("operation_status").innerHTML = 'Processing Pending Operations.....';
                        document.getElementById("operation_status").style.display = 'inline-block';
                        document.getElementById("pending_process_count").value = 1;
                        document.getElementById("accessDetails_container").style.pointerEvents = "none";
                    }else{
                        document.getElementById("pending_process_count").value = 0;
                        document.getElementById("operation_status").innerHTML = 'Process Completed.';
                        document.getElementById("accessDetails_container").style.pointerEvents = "all";
                        setTimeout(function(){document.getElementById("operation_status").style.display = 'none';},2000);
                    
                    }
                }
            }
            var app_id = document.getElementById('current_app_id').value;
            xhr.open('GET', bloxx.ajax_url+'?app_id='+app_id+'&action=operation_status', true);
            xhr.send(null);
        },10000)
    }
});

window.addEventListener('DOMContentLoaded', (event) => {
    if(document.getElementById("bloxxapp_table") && document.getElementById("pending_process_count").value.trim() !='0'){
        intervl = setInterval(checkforappstatus, 10000);
        
    }
});

jQuery(document).on('click','#adddomin-btn',function(e){
    var input = '<li  class="domain-'+Date.now()+'"><input class="subdomains domain-'+Date.now()+'" name="add_domain[]" type="text" /><i class="fa fa-trash" data-parent="domain-'+Date.now()+'" onclick="removeDomain(this)"></li>';
    jQuery(".domain-inputs ul").append(input); 
});

function removeDomain(el){
    var id = jQuery(el).attr('data-parent');
    if(jQuery('input.'+id).val() != ''){
        Swal.fire({
            title: 'Are You Sure? This Action Cannot Be Undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#000',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Delete The Domain',
            cancelButtonText: "Cancel",
        }).then((result) => {

            if (result.isConfirmed) {
                
                jQuery("."+id).remove();
            }
        }); 
    }else{
         jQuery("."+id).remove();
    } 
} 

function editsubdomain(el){
    jQuery(el).parent().css('visibility','collapse');
     jQuery('input.'+jQuery(el).attr('data-parent')).attr('type','text');
    jQuery('input.'+jQuery(el).attr('data-parent')).next('i').show();
}
function closeediting(el){
    jQuery('li.'+jQuery(el).attr('data-parent')).removeAttr('style');
     jQuery('input.'+jQuery(el).attr('data-parent')).attr('type','hidden');
    jQuery('input.'+jQuery(el).attr('data-parent')).next('i').hide();
}

jQuery(document).on('click','.add-ssl-domain',function(e){
    var input = '<div><input type="text" name="dname[]" placeholder="www.domain.com" required/><i class="fa fa-times" onclick="jQuery(this).parent().remove()"></i></div>';
    jQuery("#ssl_domains").append(input);
});

function deletesftp(el){
    Swal.fire({
            title: 'Are You Sure? This Action Cannot Be Undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#000',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Delete The SFTP',
            cancelButtonText: "Cancel",
        }).then((result) => {

            if (result.isConfirmed) {
                var ajax_url=bloxx.ajax_url;
                jQuery.ajax({
                    type : "POST",
                    url : ajax_url,
                    dataType : "json",
                    data : {server_id:jQuery(el).attr('data-server-id'),'app_id':jQuery(el).attr('data-app-id'),'action':'save_app_credentials','cred_id':jQuery(el).attr('data-id'),'type':'delete','term_id':jQuery(el).attr('data-term-id')},            
                    success: function(resp) {
                        swal.fire(resp.message);
                        if(resp.code ==200){
                            jQuery(el).parents('.sftp_inner_steps').remove();
                        }
                    }
                });
                
            }
        }); 
}