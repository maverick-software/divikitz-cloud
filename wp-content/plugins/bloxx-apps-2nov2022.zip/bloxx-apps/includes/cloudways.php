<?php
class Cloudways{
	public $access_token = '';
	private $baseurl = 'https://api.cloudways.com/api/v1';
	public $api_key = '5jnWMZjM1lWDN5yzNjyHp2h3jKiT3w';
	public $client_email = 'admin@gobloxx.io';
	// private $api_key = 'oWTc2iWa1iRiVPokrZNVMFDzlMIQMh';
	// private $client_email = 'server.web1experts@gmail.com';
	public function setToken($token,$update = false){
		$this->access_token = $token;
		if($update === true){
			update_option( 'cloudways_token', $token);
		}
	}
	public function __construct(){
		$this->api_key = get_option('cloudways_api_key');
		$this->client_email = get_option('cloudways_email');

		$hastoken = get_option('cloudways_token');
		if(!empty($hastoken) && $this->isvalidToken($hastoken) === true){
			$this->setToken($hastoken);
		}else{
			$response = $this->generateToken();
			if(isJson($response)){
				$output = json_decode($response);
				$this->setToken($output->access_token,true);
			}
			
		}
		//return $this->getToken();
		
	}

	public function isvalidToken($token){
		$this->access_token = $token;
		$output = json_decode($this->getallapps());
		if(isset($output->error) || is_null($output)){
			return false;
		}else{
			return true;
		}
	}

	public function getToken(){
		return $this->access_token;
	}

	public function postRequest($path,$data=array()){
		if(!isset($data['access_token'])){
			$data['access_token'] = $this->access_token;
		}
		$ch = curl_init();
		$url = $this->baseurl.$path;
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, 
		         http_build_query($data));

		// Receive server response ...
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);

		curl_close ($ch);

		return $server_output;
	}

	public function putRequest($path,$data = array()){
		if(!isset($data['access_token'])){
			$data['access_token'] = $this->access_token;
		}
		$ch = curl_init();
		$url = $this->baseurl.$path;
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_POSTFIELDS, 
		         http_build_query($data));
		// Receive server response ...
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);

		curl_close ($ch);

		return $server_output;

	}

	public function deleteRequest($path,$data = array()){
		if(!isset($data['access_token'])){
			$data['access_token'] = $this->access_token;
		}
		$ch = curl_init();
		$url = $this->baseurl.$path;
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_POSTFIELDS, 
		         http_build_query($data));
		// Receive server response ...
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);

		curl_close ($ch);

		return $server_output;

	}

	public function getRequest($path){
		$ch = curl_init();
		$url = $this->baseurl.$path;
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$response = curl_exec($ch);
		curl_close($ch);
		return $response;
	}
	public function generateToken(){
		return $this->postRequest('/oauth/access_token',array('email' => $this->client_email,'api_key'=>$this->api_key));
	}

	public function getallapps(){
		return $this->getRequest('/server?access_token='.$this->access_token);
	}

	public function createApp($data){
		$response = $this->postRequest('/app',$data);$fp = fopen(bloxx_path.'/lidn.txt', 'w');
                    fwrite($fp, json_encode($response));
                    fclose($fp);
		$response = json_decode($response);
		if(isset($response->operation_id)){
			return ['operation_id'=>$response->operation_id,'status'=>true];
		}else if(isset($response->error)){
			return ['error'=>$response->error,'status'=>false];
		}else{
			return ['error'=>'Something went wrong!','status'=>false];
		}
	}

	public function operationStatus($operation_id){
		return $this->getRequest('/operation/'.$operation_id.'?access_token='.$this->access_token);
	}

	public function createCredentials($data){
		$response = $this->postRequest('/app/creds',$data);
		$response = json_decode($response);
		return $response;
	}
}

function isJson($string) {
   json_decode($string);
   return json_last_error() === JSON_ERROR_NONE;
}