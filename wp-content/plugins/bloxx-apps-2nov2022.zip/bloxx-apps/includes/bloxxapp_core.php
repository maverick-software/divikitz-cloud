<?php
class Bloxxapp_core{
	
	 public function __construct(){

		add_action( 'wp_enqueue_scripts', array($this, 'pluginscripts' ));
		add_action( 'admin_init', array($this, 'check_divi_theme_installed' ));	
		add_action('wp_ajax_operation_status',array($this,'getoperationstatus'));
		add_action('wp_ajax_nopriv_operation_status',array($this,'getoperationstatus'));

		add_action('wp_ajax_application_status',array($this,'checkappStatus'));
		add_action('wp_ajax_nopriv_application_status',array($this,'checkappStatus'));	
		// Start session on init hook.
		//add_action( 'init',array($this,'wpse16119876_init_session') );
		
	}

	function wpse16119876_init_session() {
	    if ( ! session_id() ) {
	        session_start();
	    }
	}
	

	function pluginscripts() {
		wp_enqueue_style('bloxxapp-css', bloxx_url."assets/css/common.css?v=".time());
		wp_enqueue_script( 'bloxxapp-js', bloxx_url.'assets/js/bloxxapp.js?v='.time(), array('jquery'));
	}

	public function checkappStatus(){
		global $wpdb;
		$table = $wpdb->prefix . 'bloxx_operations';
		$cloud = new Cloudways();
		$userid = get_current_user_id();
		$operations = $wpdb->get_results( "SELECT * FROM $table WHERE status = 'processing' AND operation_type ='new_app' AND user_id = $userid" );
		if(!empty($operations)){
			$has_complete = false;
			foreach($operations as $k => $val){
				$output = json_decode($cloud->getRequest('/operation/'.$val->operation_id.'?access_token='.$cloud->getToken()));
				if(isset($output->operation)  && $output->operation->is_completed == '0'){
					echo 'pending';die;
				}else{
					$usermeta = get_user_meta( get_current_user_id(), 'application_data', true );
					if(!empty($usermeta) && unserialize($usermeta) !== false){ 
						$usermeta = unserialize($usermeta);
						$operation_ids = array_column($usermeta['application'], 'operation_id');
						if(!empty($operation_ids)){
							$newmeta = $usermeta;
							if(isset($output->operation->app_id) && $output->operation->app_id != '0'){
								$cats_id=$_REQUEST['cats_id'];
								update_term_meta($cats_id, "bloxx_app_id", $output->operation->app_id);

								sleep(5);

								//Check App from clodways
								$allapps = $cloud->getallapps();
								$allapps = json_decode($allapps);//var_dump($allapps);
								
								if(isset($allapps->servers)): 
				    				foreach($allapps->servers as $key => $app): 
				    					if(isset($app->apps) && count($app->apps) > 0):
					    					$pkey = key_get_parents2($output->operation->app_id,$app->apps);
					    					if(is_null($pkey)){
					    						continue;
				    						} 
					    					if ( !metadata_exists( 'user', get_current_user_id(), 'website_'.$app->apps[$pkey]->id ) ) {
					    						
												$app->apps[$pkey]->sftp_user = $app->master_user;
												$app->apps[$pkey]->sftp_pass = $app->master_password;
												$app->apps[$pkey]->public_ip = $app->public_ip;
												$bloxx_serverIP = get_option('options_server_ip','147.182.192.24');
												checkifwhiteList(['server_id'=>$app->id,'tab'=>'mysql','ip'=>[$bloxx_serverIP],'type'=>'mysql','ipPolicy'=>'allow_all']);

												update_user_meta(get_current_user_id(), 'website_'.$app->apps[$pkey]->id , $app->apps[$pkey]);
												$wpdb->update($table, array('status'=>'completed'), array('id'=>$val->id));
												$has_complete = true;
					    					}
						    			endif; 
					    			endforeach;
					    		endif;
								$parentkey = parentKeyarray($val->operation_id,$usermeta['application']);
								if(!is_null($parentkey)){
									$newmeta['application'][$parentkey]['app_id'] = $output->operation->app_id;
								}
							}
							if($usermeta !== $newmeta){
								update_user_meta(get_current_user_id(), 'application_data', serialize($newmeta));
							}
						}
					}	
				}
			}
			if($has_complete === true){
				echo 'completed';die;
			}else{
				echo 'pending';die;
			}
		}else{
			echo 'no operations';	die;
		}	
		

	}
	 
	public function getoperationstatus(){
		$app_id = $_REQUEST['app_id'];
		global $wpdb;
		$table = $wpdb->prefix . 'bloxx_operations';
		$cloud = new Cloudways();
		$operations = $wpdb->get_results( "SELECT * FROM $table WHERE app_id = '$app_id' AND status = 'processing'" );
		if(!empty($operations)){
			foreach($operations as $k => $val){
				$output = json_decode($cloud->getRequest('/operation/'.$val->operation_id.'?access_token='.$cloud->getToken()));
				
				if(isset($output->operation)  && $output->operation->is_completed == '0'){
					echo 'pending';die;
				}else{
					$wpdb->update($table, array('status'=>'completed'), array('id'=>$val->id));
					echo 'success';	die;
				}
			}
		}	
		echo 'success';	die;
	}

	public function check_divi_theme_installed() {
		$theme = wp_get_theme();
		$er=0;
		if ('Divi' == $theme->name) {
			$er=0;
		} else if('Divi Child Theme' == $theme->name){
			$er=0;
		} else {
			$er=1;
		}

		if($er==1){
			$error_message="Please activate Divi theme for continue...  Custom Divi Builder Plugin";
			$this->error_message($error_message);
		}
	}


	// public function error_message($error_message){
	// 	? >
	// 	<div class="updated error divi_builder">
	// 		<p><?php esc_html_e( $error_message );? ></p>
	// 	</div>

	// 	<?php
	// }

}
$bloxxapp_core = new Bloxxapp_core();

function parentKeyarray($subject, $array,$keyname = 'operation_id')
{
	foreach ($array as $key => $val) {
       if ($val[$keyname] == $subject) {
           return $key;
       }
   }
   return null;
}

function parentKeyobject($subject, $array)
{
	foreach ($array as $key => $val) {
       if ($val->id === $subject) {
           return $key;
       }
   }
   return null;
}
function generateRandomUsername($length = 10) {
    $characters = 'abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


function key_get_parents($subject, $array,$keyname = 'operation_id')
	{
		foreach ($array as $key => $val) {
	       if ($val[$keyname] === $subject) {
	           return $key;
	       }
	   }
	   return null;
	}

	function key_get_parents2($subject, $array)
	{
		foreach ($array as $key => $val) {
	       if ($val->id === $subject) {
	           return $key;
	       }
	   }
	   return null;
	}

function checkifwhiteList($data){
	$cloud = new Cloudways();
	$output = json_decode($cloud->getRequest('/security/whitelistedIpsMysql?server_id='.$data['server_id'].'&access_token='.$cloud->getToken()));
	$bloxx_serverIP = get_option('options_server_ip','147.182.192.24');

	if(isset($output->ip_list) && in_array($bloxx_serverIP, $output->ip_list)){
		return true;
	}else{
		$res =  $cloud->postRequest('/security/whitelisted',$data);
		$data['tab'] = 'sftp';$data['type'] = 'sftp';
		$cloud->postRequest('/security/whitelisted',$data);
	}
	return true;
	
}