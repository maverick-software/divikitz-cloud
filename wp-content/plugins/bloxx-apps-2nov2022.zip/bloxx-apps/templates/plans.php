<style>
.selectPlan {display: flex;flex-flow: column wrap;justify-content: space-between;}
.radio-custom {opacity: 0;position: absolute;}
.radio-custom-label {display: block;cursor: pointer;margin: 0 0 0.5rem;border: 1px solid #eee;padding: 1.2rem 1.5rem 1.2rem 3.5rem;display: flex;align-items: center;justify-content: space-between;border-radius: 10px;}
.singlePlan:last-child .radio-custom-label {margin-bottom: 0;}
.radio-custom:checked + .radio-custom-label {background: #f4ac45;color: #fff;}
.radio-custom + .radio-custom-label::before {content: '';background: #F0F1FA;border: 0;display: inline-block;vertical-align: middle;width: 22px;height: 22px;padding: 0;margin-right: 0;text-align: center;position: absolute;text-align: center;line-height: 22px;border-radius: 50%;left: 35px}
.radio-custom:checked + .radio-custom-label:before {content: "\f00c";font-family: 'FontAwesome';color: #f4ac45;}
.item.featureList {background: #F0F1FA;padding: 2rem;height: 100%;border-radius: 10px}
.title-theme {font-weight: 500;font-size: 20px;margin-bottom: 1rem;}
.features h4 {display: flex;align-items: center;justify-content: space-between;font-size: 15px;color: #231942;margin-bottom: 0.5rem;}
.features h4 .default {color: #68B0AB}
.features h4 .gray_text {color: #9C9EB8}
.features h4 .disabled_text {color: #C2C4D9}
.switch-button {margin: auto auto 2rem}
#main-content .container::before {display: none}
.radio-custom-label h3 {padding: 0;color: #231942;font-size: 18px;font-weight: 500;}
.radio-custom-label h3 span {margin-top: 0.5rem;padding: 5px 15px;border-radius: 50px;-webkit-border-radius: 50px;font-size: 12px;display: block;background: #F0F1FA;color: #9C9EB8;font-weight: normal;}
.radio-custom-label .priceTag {color: #231942;font-size: 30px;font-weight: 600;margin: 0;}
.radio-custom-label .priceTag small {color: #9C9EB8;font-size: 12px;font-weight: normal;margin: 0;vertical-align: middle}
.radio-custom:checked + .radio-custom-label h3, .radio-custom:checked + .radio-custom-label .priceTag, .radio-custom:checked + .radio-custom-label .priceTag small {color: #fff}
.radio-custom:checked + .radio-custom-label h3 span {background: #ffffff20;color: #ffffff;}
.switchToggler {text-align: center;margin: 1rem 0 2rem}
.toggle, .toggler {display: inline-block;vertical-align: middle;margin: 10px;}
.toggler {color: #9C9EB8;transition: .2s;}
.toggler--is-active {color: #231942;font-weight: bold;}
.toggle {position: relative;width: 80px;height: 35px;border-radius: 100px;background-color: #F0F1FA;overflow: hidden;}
.check {position: absolute;display: block;cursor: pointer;top: 0;left: 0;width: 100%;height: 100%;opacity: 0;z-index: 6;}
.check:checked ~ .switch {right: 4px;left: auto;transition: 0.25s cubic-bezier(0.785, 0.135, 0.15, 0.86);transition-property: left, right;transition-delay: .08s, 0s;}
.switch {position: absolute;left: 4px;top: 0;bottom: 0;right: auto;background-color: #f4ac45;border-radius: 100px;z-index: 1;transition: 0.25s cubic-bezier(0.785, 0.135, 0.15, 0.86);transition-property: left, right;transition-delay: 0s, .08s;width: 26px;height: 26px;margin: auto;}
.hide{display: none;}
</style>
<section class="pricing-plans-table">
    <div class="container">
        <div class="switchToggler">
            <label class="toggler toggler--is-active" id="filt-monthly">Monthly</label>
            <div class="toggle">
                <input type="checkbox" id="switcher" class="check">
                <b class="b switch"></b>
            </div>
            <label class="toggler" id="filt-yearly">Yearly</label>
        </div>
        
        <div class="rowWrap monthly_view" id="monthly_view">
            <div class="flex-6">
                <div class="item featureList">
                    <div class="heading">
                        <h3 class="title-theme">Features</h3>
                    </div>
                    <div class="features">
                        <h4>
                            <span class="feature">Premium Hosting</span>
                            <span class="feature default"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Backups</span>
                            <span class="feature default"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Free SSL</span>
                            <span class="feature default"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Custom Domain</span>
                            <span class="feature gray_text">Good</span>
                        </h4>
                        <h4>
                            <span class="feature">Performance</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Tools</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Collaborators</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Integrations</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                    </div>
                </div>
            </div>
            <div class="flex-6">
                <div class="selectPlan">
                    <div class="singlePlan">
                        <input id="radio-1" class="radio-custom" name="radio-group" type="radio" checked>
                        <label for="radio-1" class="radio-custom-label">
                            <h3>Starter <span class="freeTag">Free</span></h3>
                            <p class="priceTag">$0 <small>/month</small></p>
                        </label>
                    </div>
                    <div class="singlePlan">
                        <input id="radio-2" class="radio-custom"name="radio-group" type="radio">
                        <label for="radio-2" class="radio-custom-label">
                            <h3>Lite <span class="freeTag">Save 20%</span></h3>
                            <p class="priceTag">$8 <small>/month</small></p>
                        </label>
                    </div>
                    <div class="singlePlan">
                        <input id="radio-3" class="radio-custom" name="radio-group" type="radio">
                        <label for="radio-3" class="radio-custom-label">
                            <h3>Standard <span class="freeTag">Save 40%</span></h3>
                            <p class="priceTag">$16 <small>/month</small></p>
                        </label>
                    </div>
                    <div class="singlePlan">
                        <input id="radio-4" class="radio-custom" name="radio-group" type="radio">
                        <label for="radio-4" class="radio-custom-label">
                            <h3>Elite <span class="freeTag">Save 40%</span></h3>
                            <p class="priceTag">$24 <small>/month</small></p>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="rowWrap yearly_view hide" id="yearly_view">
            <div class="flex-6">
                <div class="item featureList">
                    <div class="heading">
                        <h3 class="title-theme">Features</h3>
                    </div>
                    <div class="features">
                        <h4>
                            <span class="feature">Premium Hosting</span>
                            <span class="feature default"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Backups</span>
                            <span class="feature default"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Free SSL</span>
                            <span class="feature default"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Custom Domain</span>
                            <span class="feature gray_text">Good</span>
                        </h4>
                        <h4>
                            <span class="feature">Performance</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Tools</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Collaborators</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                        <h4>
                            <span class="feature">Integrations</span>
                            <span class="feature disabled_text"><i class="fas fa-check-circle"></i></span>
                        </h4>
                    </div>
                </div>
            </div>
            <div class="flex-6">
                <div class="selectPlan">
                    <div class="singlePlan">
                        <input id="radio-5" class="radio-custom" name="radio-group" type="radio" checked>
                        <label for="radio-5" class="radio-custom-label">
                            <h3>Starter <span class="freeTag">Free</span></h3>
                            <p class="priceTag">$8 <small>/month</small></p>
                        </label>
                    </div>
                    <div class="singlePlan">
                        <input id="radio-6" class="radio-custom"name="radio-group" type="radio">
                        <label for="radio-6" class="radio-custom-label">
                            <h3>Lite <span class="freeTag">Save 20%</span></h3>
                            <p class="priceTag">$18 <small>/month</small></p>
                        </label>
                    </div>
                    <div class="singlePlan">
                        <input id="radio-7" class="radio-custom" name="radio-group" type="radio">
                        <label for="radio-7" class="radio-custom-label">
                            <h3>Standard <span class="freeTag">Save 40%</span></h3>
                            <p class="priceTag">$24 <small>/month</small></p>
                        </label>
                    </div>
                    <div class="singlePlan">
                        <input id="radio-8" class="radio-custom" name="radio-group" type="radio">
                        <label for="radio-8" class="radio-custom-label">
                            <h3>Elite <span class="freeTag">Save 40%</span></h3>
                            <p class="priceTag">$36 <small>/month</small></p>
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
var e = document.getElementById("filt-monthly"),
    d = document.getElementById("filt-yearly"),
    t = document.getElementById("switcher"),
    m = document.getElementById("monthly_view"),
    y = document.getElementById("yearly_view");

e.addEventListener("click", function(){
  t.checked = false;
  e.classList.add("toggler--is-active");
  d.classList.remove("toggler--is-active");
  m.classList.remove("hide");
  y.classList.add("hide");
});

d.addEventListener("click", function(){
  t.checked = true;
  d.classList.add("toggler--is-active");
  e.classList.remove("toggler--is-active");
  m.classList.add("hide");
  y.classList.remove("hide");
});

t.addEventListener("click", function(){
  d.classList.toggle("toggler--is-active");
  e.classList.toggle("toggler--is-active");
  m.classList.toggle("hide");
  y.classList.toggle("hide");
})    
</script>