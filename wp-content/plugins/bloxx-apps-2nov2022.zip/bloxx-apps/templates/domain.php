<?php

class Domain{
	

	public function __construct(){
		
		add_action("wp_ajax_nopriv_app_domain_save", array($this, "appDomainsave"));
		add_action("wp_ajax_app_domain_save", array($this, "appDomainsave"));
		add_action('wp_ajax_app_domain', array($this, 'getapp_domainlist'));
		add_action('wp_ajax_nopriv_app_domain', array($this, 'getapp_domainlist'));
		add_action('wp_ajax_nopriv_backup-restore', array($this, 'backupandrestore'));
		add_action('wp_ajax_backup-restore', array($this, 'backupandrestore'));
		add_action('wp_ajax_take_backup',array($this,'takebackup'));
		add_action('wp_ajax_nopriv_take_backup',array($this,'takebackup'));
		add_action('wp_ajax_restore_app',array($this,'restoreApp'));
		add_action('wp_ajax_nopriv_restore_app',array($this,'restoreApp'));

		add_action('wp_ajax_operation',array($this,'getoperation'));
		add_action('wp_ajax_nopriv_operation',array($this,'getoperation'));

		add_action('wp_ajax_primary_domain',array($this,'primarydomainRequest'));
		add_action('wp_ajax_nopriv_primary_domain',array($this,'primarydomainRequest'));
	}

	public function appDomainsave(){
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$code = 200;$msg = '';
			if(is_user_logged_in()){ 
				$input = array_column($_POST['domain'],'value');
				if(!empty($input) && is_array($input)){
					for ($i=0; $i <count($input) ; $i++) { 
						$input[$i] = trim($input[$i], '/');
						$input[$i] = str_replace(['https://','http://','www.'], '', $input[$i]);					}
				
			   
				    $webdata = get_user_meta(get_current_user_id(),trim('website_'.$_POST['app_id']),true);

				    // Remove www.
				    //$domain_name = preg_replace('/^www\./', '', $urlParts['host']);
				    

					$cloud = new Cloudways();
					$output = json_decode($cloud->postRequest('/app/manage/aliases',['server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'aliases'=>$input]));
					if(empty($output)){
						if(!empty($webdata) && isset($webdata->aliases)){
							$webdata->aliases = array_unique($input);
							update_user_meta(get_current_user_id(),trim('website_'.$_POST['app_id']),$webdata);
						}
						$code = 200;$msg = 'Additional Domain Added Successfully.';
					}else{
						$code = 500;$msg = (isset($output->message))?$output->message:'Something Went Wrong.';
					}
				}else{
					$code = 500; $msg = 'Domain cannot be empty.';
				}
				$result=array(
					'code' => $code,					
					'message' => $msg
				);
				echo json_encode($result);
				die();
			}
		}else{
			$result=array(
				'code' => 500,					
				'message' => 'Method Not Allowed'
			);
			echo json_encode($result);
			die();
		}
	}

	public function primarydomainRequest(){
		global $wpdb;
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$code = 200;$msg = '';
			$input = $_POST['domain'];

		    // If URI is like, eg. www.way2tutorial.com/
		    $input = trim($input, '/');


		    // Remove www.
		    //$domain_name = preg_replace('/^www\./', '', $urlParts['host']);
		    $domain_name = str_replace(['https://','http://','www.'], '', $input);//var_dump($domain_name);die;
			$cloud = new Cloudways();
			$output = json_decode($cloud->postRequest('/app/manage/cname',['server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'cname'=>trim($domain_name)]));
			

			if(isset($output->operation_id)){
				$userID = get_current_user_id();
				insertOperation(['user_id'=>$userID,'operation_id'=>$output->operation_id,'server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'status'=>'processing','operation_type'=>'others']);
				$web_meta = get_user_meta($userID,trim('website_'.$_POST['app_id']),true);
				if(is_object($web_meta) && !empty($web_meta)){
					$web_meta->app_fqdn = trim($domain_name);
					$web_meta->cname = trim($domain_name);
					update_user_meta($userID,trim('website_'.$_POST['app_id']),$web_meta);

			        $conn_site = $wpdb->prefix . 'connected_sites';
			        $wpdb->update($conn_site, array('site_url'=>'https://'.$domain_name), array('siteblox_user_id'=>$userID,'siteblox_termid'=>$_POST['termid']));
				}
				$code = 200;$msg = 'Your Request has been submitted. It will take 2-3 mins to complete.';
			} else {
				$msg= (isset($output->message))?$output->message:'';
				
				// foreach($output->cname as $result):
				// 	$msg.= $result->message;
				// endforeach;

				$code = 500;$msg = $msg;
			}
			$result=array(
				'code' => $code,					
				'message' => $msg
			);
			echo json_encode($result);
			die();
		}else{
			$result=array(
				'code' => 500,					
				'message' => 'Method Not Allowed'
			);
			echo json_encode($result);
			die();
		}
	}

	public function takebackup(){
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$code = 200;$msg = '';
			if(is_user_logged_in()){ 
				// if(getoperation($_POST['app_id']) === false){
				// 	$result=array(
				// 		'code' => 500,					
				// 		'message' => 'Previous Process is not completed yet. Please try after some time.'
				// 	);
				// 	echo json_encode($result);
				// 	die();
				// }
				// sleep(2);
				$cloud = new Cloudways();
				$output = json_decode($cloud->postRequest('/app/manage/takeBackup',['server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id']]));
					if(isset($output->operation_id)){
						insertOperation(['user_id'=>get_current_user_id(),'operation_id'=>$output->operation_id,'server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'status'=>'processing','operation_type'=>'others']);
						$code = 200;$msg = 'Backup Created Successfully.';
					}else{
						$code = 500;$msg = (isset($output->error))?$output->error:'Something Went Wrong.';
					}
				$result=array(
					'code' => $code,					
					'message' => $msg
				);
				echo json_encode($result);
				die();
			}
		}else{
			$result=array(
				'code' => 500,					
				'message' => 'Method Not Allowed'
			);
			echo json_encode($result);
			die();
		}
	}
	public function getapp_domainlist(){

		$cloud = new Cloudways();
		// $allapps = $cloud->getallapps();
		// $allapps = json_decode($allapps);
		// $domains = '<ul>';
		// if(isset($allapps->servers)){
		// 	foreach($allapps->servers as $key => $app){
		// 		if(isset($app->apps) && count($app->apps) > 0){
		// 		    for ($a=0; $a< count($app->apps)); $a++){
		// 				if($app->apps[$a]->id != $_REQUEST['app_id']){
		// 					continue;
		// 				}else{
		// 					$pkey = getparentkeyindex($_REQUEST['app_id'],$app->apps);
	 //    					if(is_null($pkey)){
	 //    						continue;
	 //    					}else{
	 //    						if(!empty($app->apps[$pkey]->alias)){
	 //    							for ($i=0; $i < count($app->apps[$pkey]->alias); $i++) { 
	 //    								$domains .= '<li><a href="javascript:void(0)" class="db-btn" onclick="removedomain(this)"><i class="fa fa-pencil"></i></a></li>'
	 //    							}
	 //    						}
	 //    					}
		// 				}
		// 			}
		// 		}
		// 	}
		// }
		// $domains .= '</ul>';
		print '<h2>Domain Management</h2>
	                <div class="columnHalf paddR">
	                    <h4>Primary Domain</h4>
	                    <input type="text" name="primary_domain" placeholder="Enter Primary Domain" />
	                    <button type="button" class="buttonCustom" id="primry_domain-btn">Add Domain</button>
	                </div>';die;


	                // <div class="columnHalf">
	                //     <h4>Additional Domain</h4>
	                //     <input type="text" name="domain" placeholder="Enter Domain" />
	                //     <button type="button" class="buttonCustom" id="savedomain-btn">Add Domain</button>
	                // </div>

	}

	public function backupandrestore($attr){

		$cloud = new Cloudways();
		$options = array();
		 $backups = json_decode($cloud->getRequest('/app/manage/backup?access_token='.$cloud->getToken().'&server_id='.$_REQUEST['server_id'].'&app_id='.$_REQUEST['app_id']));
		if(isset($backups->operation_id)){
			sleep(4);
			$operation = json_decode($cloud->getRequest('/operation/'.$backups->operation_id.'?access_token='.$cloud->getToken().'&id='.$backups->operation_id));
			if(isset($operation->operation) && $operation->operation->is_completed == '1'){
				$operationdata = json_decode($operation->operation->parameters);
            	if(@$operationdata->backup_dates){
            		for ($i=0; $i < count(@$operationdata->backup_dates); $i++) {
            			$options[]= @$operationdata->backup_dates[$i];
            		}
            	}
            }
			
		}
		
		$result=array(
			'code'=> 200,
			'message' => "Backup restore refreshed",
			'options'=> $options
		);

		echo json_encode($result);
		die();
	}

	public function restoreApp(){
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$code = 200;$msg = '';
			if(is_user_logged_in()){ 
				// if(getoperation($_POST['app_id']) === false){
				// 	$result=array(
				// 		'code' => 500,					
				// 		'message' => 'Previous Process is not completed yet. Please try after some time.'
				// 	);
				// 	echo json_encode($result);
				// 	die();
				// }
				$cloud = new Cloudways();
				$output = json_decode($cloud->postRequest('/app/manage/restore',['server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'time'=>$_POST['time']]));
					if(isset($output->operation_id)){
						insertOperation(['user_id'=>get_current_user_id(),'operation_id'=>$output->operation_id,'server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'status'=>'processing','operation_type'=>'others']);
						$code = 200;$msg = 'Successfull! It will take 4-5 minutes to restore your app completely.';
					}else{
						$code = 500;$msg = (isset($output->error))?$output->error:'Something Went Wrong.';
					}
				$result=array(
					'code' => $code,					
					'message' => $msg
				);
				echo json_encode($result);
				die();
			}
		}else{
			$result=array(
				'code' => 500,					
				'message' => 'Method Not Allowed'
			);
			echo json_encode($result);
			die();
		}
	}

	
}

$domain = new Domain();