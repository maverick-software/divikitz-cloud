<?php

class Apps {

    public $cloudobj;

    public function __construct() {

        add_shortcode('bloxx_app_list', array($this, 'listall_applications'));
        add_shortcode('bloxx_app_details', array($this, 'appDetails'));
        add_action("wp_ajax_save_app_credentials", array($this, "save_app_credentials"));
        add_action("wp_ajax_nopriv_save_app_credentials", array($this, "save_app_credentials"));
        add_action("wp_ajax_save_db_credentials", array($this, "save_db_credentials"));
        add_action("wp_ajax_nopriv_save_db_credentials", array($this, "save_db_credentials"));
        add_action("wp_ajax_save_admin_credentials", array($this, "changeAdminCredentials"));
        add_action("wp_ajax_nopriv_save_admin_credentials", array($this, "changeAdminCredentials"));
        add_action("wp_ajax_deleteapp", array($this, "deleteapp"));
        add_action("wp_ajax_nopriv_deleteapp", array($this, "deleteapp"));
        // add_action('wp_ajax_removesftp',array($this,'removesftpaction'));
        // add_action('wp_ajax_nopriv_removesftp',array($this,'removesftpaction'));

        // New actions for schedular
        add_action("wp_ajax_create_bloxx_app", array($this, "schedulenewapp"));
        add_action("wp_ajax_nopriv_create_bloxx_app", array($this, "schedulenewapp"));

        add_action("newappprocess", array($this, "createAppnew"), 10, 3);
        add_action("checkifappCreated", array($this, "checkifappCreatedfun"), 10, 3);
        add_action("checkifserverCreated",array($this,"checkifserverCreatedfun"),10,4);
        add_action('trackappprogress',array($this, "trackappprogressfun"), 10, 3);
        add_action("wp_ajax_checkuser_appmeta", array($this, "checkuser_appmeta"));
        add_action("wp_ajax_nopriv_checkuser_appmeta", array($this, "checkuser_appmeta"));
        add_action('addssltoapp',array($this,'addssltoappfun'),10,3);
        add_shortcode('option_shot',array($this,'optionget'));
        add_action('updatesshparams',array($this,'updatesshparamsfun'),10,2);
        add_action('setupnewapphook',array($this,'setupnewapp'),10,3);
        add_shortcode('planssetup',array($this,'planssetup'));

        add_action('createserverandapp',array($this,'createserverandappaction'),10,4);

        add_action("wp_ajax_site_icon", array($this, "update_faviconaction"));
        add_action("wp_ajax_nopriv_site_icon", array($this, "update_faviconaction"));
        add_action("resetfile_permission",array($this, "resetfilepermission"),10,2);
    }

    public function planssetup(){
        require_once(bloxx_path.'templates/plans.php');
    }

    public function update_faviconaction(){
       
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $_REQUEST['site_url'].'/wp-json/builder-page/update-favicon/',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('file'=> new CURLFILE($_FILES['file']['tmp_name'])),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        echo $response;die;
    }

    public function optionget(){
        $serverid = '661204';
        $available_apps = get_option('server_665865',true);
            // if(gettype($available_apps) == 'string'){
                //$available_apps = json_decode($available_apps,true);
            // }
         
            if(is_array($available_apps) && count($available_apps) > 0){

                $app_index =  (count($available_apps) > 1)?rand(0,count($available_apps)-1):0; 
                $assigned_app_id = $available_apps[$app_index]->id;
            }
            echo @$assigned_app_id;
    }
    public function checkuser_appmeta() {
        global $wpdb;
        $term_id = isset($_POST['term_id']) ? $_POST['term_id'] : '';
        $term_meta = get_term_meta($term_id, 'bloxx_app_id', true);

        $table = $wpdb->prefix . 'bloxx_operations';
        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE app_id = '".$term_meta."' AND status = 'processing' AND operation_type='cron'");
        if($rowcount > 0){
            echo 'no';die;
        }

        if (empty($term_meta) || $term_meta === false || !metadata_exists('user', get_current_user_id(), 'website_' . $term_meta)) {
            echo 'no';
            die();
        } else {
            echo 'yes';
            die();
        }
    }

    public function checkifappCreatedfun($userid, $cats_id,$operation_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'bloxx_operations';
        $cloud = new Cloudways();
        $this->cloudobj = $cloud;
        // $operations = $wpdb->get_results("SELECT * FROM $table WHERE status = 'processing' AND operation_type ='new_app' AND user_id = $userid");
        // if (!empty($operations)) {
            $has_complete = false;
            //foreach ($operations as $k => $val) {
                $output = json_decode($cloud->getRequest('/operation/' . $operation_id . '?access_token=' . $cloud->getToken()));
                if (isset($output->operation) && $output->operation->is_completed == '0') {
                      if (wp_next_scheduled('checkifappCreated', [$userid, $cats_id,$operation_id])) {
                            wp_clear_scheduled_hook('checkifappCreated');
                        }
                        $time = time() + 30;
                        wp_schedule_single_event($time, 'checkifappCreated', [$userid, $cats_id,$operation_id]);
                    echo 'pending';
                    die;
                } else {
                    
                            if (isset($output->operation->app_id) && $output->operation->app_id != '0') {

                                update_term_meta($cats_id, "bloxx_app_id", $output->operation->app_id);

                                sleep(5);

                                //Check App from clodways
                                $allapps = $cloud->getallapps();
                                $allapps = json_decode($allapps); 

                                if (isset($allapps->servers)):
                                    foreach ($allapps->servers as $key => $app):
                                        if (isset($app->apps) && count($app->apps) > 0):
                                            $pkey = key_get_parents2($output->operation->app_id, $app->apps);
                                            if (is_null($pkey)) {
                                                continue;
                                            }
                                            if (!metadata_exists('user', $userid, 'website_' . $app->apps[$pkey]->id)) {

                                                $app->apps[$pkey]->sftp_user = $app->master_user;
                                                $app->apps[$pkey]->sftp_pass = $app->master_password;
                                                $app->apps[$pkey]->public_ip = $app->public_ip;
                                                $bloxx_serverIP = get_option('options_server_ip', '45.63.49.199');
                                                checkifwhiteList(['server_id' => $app->id, 'tab' => 'mysql', 'ip' => [$bloxx_serverIP], 'type' => 'mysql', 'ipPolicy' => 'allow_all']);
                                                $hosting_plan_id = get_term_meta($cats_id, 'hosting_planid',true);
                                                $subdomain = get_field('domain',$hosting_plan_id);
                                                $this->updateDomain(['server_id' => $app->id, 'app_id' => $app->apps[$pkey]->id, 'cname' => $app->apps[$pkey]->app_fqdn, 'public_ip' => $app->public_ip],$subdomain);

                                                $app->apps[$pkey]->app_fqdn = str_replace('cloudwaysapps', $subdomain.'.bloxxapps', $app->apps[$pkey]->app_fqdn);


                                                update_user_meta($userid, 'website_' . trim($app->apps[$pkey]->id), $app->apps[$pkey]);

                                                $this->updateapplicatonusername($userid,$app->apps[$pkey]->id);
                                                wp_schedule_single_event(time()+20, 'resetfile_permission', [$app->id,$app->apps[$pkey]->id]);
                                                

                                                $wpdb->update($table, array('status' => 'completed'), array('id' => $val->id));
                                                $has_complete = true;
                                                $time = time() + 60;
                                                wp_schedule_single_event($time, 'bloxx_plugin_process_cron', [$userid, $cats_id]);

                                            }
                                        endif;
                                    endforeach;
                                endif;
                                $parentkey = parentKeyarray($val->operation_id, $usermeta['application']);
                                if (!is_null($parentkey)) {
                                    $newmeta['application'][$parentkey]['app_id'] = $output->operation->app_id;
                                }
                            }
                            if ($usermeta !== $newmeta) {
                                update_user_meta($userid, 'application_data', serialize($newmeta));
                            }
                   
            if ($has_complete === true) {
                echo 'completed';
                die;
            } else {
                if (wp_next_scheduled('checkifappCreated', [$userid, $cats_id])) {
                    wp_clear_scheduled_hook('checkifappCreated');
                }
                $time = time() + 30;
                wp_schedule_single_event($time, 'checkifappCreated', [$userid, $cats_id]);
                echo 'pending';
                die;
            }
        }
    }

    public function checkifserverCreatedfun($userid, $cats_id,$operation_id,$hosting_plan_id) {
        global $wpdb;
        $cloud = new Cloudways();
        $this->cloudobj = $cloud;
        $has_complete = false;
        $output = json_decode($cloud->getRequest('/operation/' . $operation_id . '?access_token=' . $cloud->getToken()));
        $fp = fopen(bloxx_path.'/abc.txt', 'w');
                                fwrite($fp, 'hree'.json_encode($output));
                                fclose($fp); 
        if (isset($output->operation) && $output->operation->is_completed == '0') {
              if (wp_next_scheduled('checkifserverCreated', [$userid, $cats_id,$operation_id,$hosting_plan_id])) {
                    wp_clear_scheduled_hook('checkifserverCreated');
                }
                $time = time() + 90;
                wp_schedule_single_event($time, 'checkifserverCreated', [$userid, $cats_id,$operation_id,$hosting_plan_id]);
            echo 'pending';
            die;
        } else {
            if (isset($output->server) && count($output->server[0]->apps) > 0) {
                $fp = fopen(bloxx_path.'/abc.txt', 'w');
                                fwrite($fp, 'yes');
                                fclose($fp); 
                update_term_meta($cats_id, "bloxx_app_id",$output->server[0]->apps[0]->id);
                
                if (!metadata_exists('user', $userid, 'website_' . $output->server[0]->apps[0]->id)) {

                    $output->server[0]->apps[0]->sftp_user = $output->server[0]->master_user;
                    $output->server[0]->apps[0]->sftp_pass = $output->server[0]->master_password;
                    $output->server[0]->apps[0]->public_ip = $output->server[0]->public_ip;
                    $bloxx_serverIP = get_option('options_server_ip', '45.63.49.199');
                    checkifwhiteList(['server_id' => $output->server[0]->id, 'tab' => 'mysql', 'ip' => [$bloxx_serverIP], 'type' => 'mysql', 'ipPolicy' => 'allow_all']);
                    $hosting_plan_id = get_term_meta($cats_id, 'hosting_planid',true);
                    //$subdomain = get_field('domain',$hosting_plan_id);
                    // $this->updateDomain(['server_id' => $output->server[0]->id, 'app_id' => $output->server[0]->apps[0]->id, 'cname' => $output->server[0]->apps[0]->app_fqdn, 'public_ip' => $output->server[0]->public_ip],$subdomain);

                    //$app->apps[$pkey]->app_fqdn = str_replace('cloudwaysapps', $subdomain.'.bloxxapps', $app->apps[$pkey]->app_fqdn);


                    update_user_meta($userid, 'website_' . trim($output->server[0]->apps[0]->id), $output->server[0]->apps[0]);

                    $this->updateapplicatonusername($userid,$output->server[0]->apps[0]->id);

                    wp_schedule_single_event(time()+20, 'resetfile_permission', [$output->server[0]->id,$output->server[0]->apps[0]->id]);

                    
                    //$wpdb->update($table, array('status' => 'completed'), array('id' => $val->id));
                    $has_complete = true;
                    $time = time() + 90;
                    wp_schedule_single_event($time, 'bloxx_plugin_process_cron', [$userid, $cats_id]);
                    $table = $wpdb->prefix . 'bloxx_operations';
                    $wpdb->insert($table,['user_id'=>$userid,'server_id'=>$output->server[0]->id,'app_id'=>$output->server[0]->apps[0]->id,'operation_id'=>rand(1,999999),'operation_type'=>'cron','status'=>'processing']);
                }
                
            }else{
                if (wp_next_scheduled('checkifserverCreated', [$userid, $cats_id,$operation_id,$hosting_plan_id])) {
                    wp_clear_scheduled_hook('checkifserverCreated');
                }
                $time = time() + 90;
                wp_schedule_single_event($time, 'checkifserverCreated', [$userid, $cats_id,$operation_id,$hosting_plan_id]);
            }
            if ($has_complete === true) {
                echo 'completed';
                die;
            } else {
                if (wp_next_scheduled('checkifserverCreated', [$userid, $cats_id,$operation_id,$hosting_plan_id])) {
                    wp_clear_scheduled_hook('checkifserverCreated');
                }
                $time = time() + 90;
                wp_schedule_single_event($time, 'checkifserverCreated', [$userid, $cats_id,$operation_id,$hosting_plan_id]);
                echo 'pending';
                die;
            }
        }
    }


    public function trackappprogressfun($serverid,$operation_id,$term_id){
        $cloud = new Cloudways();
        $this->cloudobj = $cloud;
        $output = json_decode($cloud->getRequest('/operation/' . $operation_id . '?access_token=' . $cloud->getToken()));
        if (isset($output->operation) && $output->operation->is_completed != '1' || empty($output) || is_null($output)) {
              if (wp_next_scheduled('trackappprogress', [$serverid, $operation_id,$term_id])) {
                    wp_clear_scheduled_hook('trackappprogress');
                }
                $time = time() + 40;
                wp_schedule_single_event($time, 'trackappprogress', [$serverid, $operation_id,$term_id]);
            die;
        } else {
            
                $time = time() + 30;
                wp_schedule_single_event($time, 'setupnewapphook', [$serverid,$output->operation->app_id,$term_id]);
                
                   
        }
    }


    public function setupnewapp($serverid,$app_id,$term_id){
        $cloud = new Cloudways();
        $allapps = $cloud->getallapps();
        $allapps = json_decode($allapps); //var_dump($allapps);
        
        if(empty($allapps)){
            if (wp_next_scheduled('setupnewapphook', [$serverid, $app_id,$term_id])) {
                wp_clear_scheduled_hook('setupnewapphook');
            }
            $time = time() + 30;
            wp_schedule_single_event($time, 'setupnewapphook', [$serverid,$app_id,$term_id]);
            die;
        }
        if (isset($allapps->servers)):
            foreach ($allapps->servers as $key => $app):
                if (isset($app->apps) && count($app->apps) > 0):
                    $pkey = key_get_parents2($app_id, $app->apps);
                    if (is_null($pkey)) {
                        continue;
                    }



                    $app->apps[$pkey]->sftp_user = $app->master_user;
                    $app->apps[$pkey]->sftp_pass = $app->master_password;
                    $app->apps[$pkey]->public_ip = $app->public_ip;

                    $bloxx_serverIP = get_option('options_server_ip', '45.63.49.199');
                    checkifwhiteList(['server_id' => $app->id, 'tab' => 'mysql', 'ip' => [$bloxx_serverIP], 'type' => 'mysql', 'ipPolicy' => 'allow_all']);
                    $hosting_plan_id = get_term_meta($term_id, 'hosting_planid',true);
                    $subdomain = get_field('domain',$hosting_plan_id);
                    $this->updateDomain(['server_id' => $app->id, 'app_id' => $app->apps[$pkey]->id, 'cname' => $app->apps[$pkey]->app_fqdn, 'public_ip' => $app->public_ip],$subdomain);
                    $app->apps[$pkey]->app_fqdn = str_replace('cloudwaysapps', $subdomain.'.bloxxapps', $app->apps[$pkey]->app_fqdn);
                    $available_apps = get_option(trim('server_'.$serverid),true);
                    if(gettype($available_apps) == 'string'){
                        $available_apps = json_decode($available_apps);
                    }
                    if(is_array($available_apps)){
                        array_push($available_apps,$app->apps[$pkey]);

                    }
                        
                    update_option(trim('server_'.$serverid),array_values($available_apps));
                   
                    break;
                endif;
            endforeach;
        else:
             $fp = fopen(bloxx_path.'/abc.txt', 'w');
                        fwrite($fp, 'sdfdfs');
                        fclose($fp);
       
        endif;
    }


    public function schedulenewapp_free() {
        $userID = get_current_user_id();
        $project_catnm = get_user_meta($userID, 'current_project_name', true);
        $project_count = get_user_meta($userID, 'project_limit', true);
        $latest_limit=$project_count-1;
        
        $builder_terms = get_terms(
            array(
                'taxonomy' => 'project_categories',
                'name' => $project_catnm,
                'meta_query' => array(
                    array(
                        'key' => 'builder_cat_user',
                        'value' => $userID,
                        'compare' => '='
                    )
                )
            )
        );
        if(!empty($builder_terms) && count($builder_terms) > 0){
            $result = array(
                'code' => '500',
                'message' => 'Project already exists with this name'
            );
            return $result;
            echo json_encode($result);die();
        }else{
            $user_role = get_user_role_name($userID);
            //get_user_meta($userID,'current_project_name',true);
            $slug = sanitize_title($project_catnm);
            $args = array('name' => $project_catnm, 'taxonomy' => 'project_categories');
            $termslug = wp_unique_term_slug($slug, (object) $args);
            if(empty($project_catnm)){
                return '';exit;
            }
            $cid = wp_insert_term($project_catnm, 'project_categories', array(
                'description' => '', 'slug' => $termslug
            ));
            //$builder_elementor_type=get_user_meta($userID, 'current_builder_option', true);
          
            $term_id = $cid['term_taxonomy_id'];

            //$builder_elementor_type=get_user_meta($userID, 'current_builder_option', true);
         
            add_term_meta($term_id, "builder_cat_user", $userID);
            $subs_plan = get_user_meta($userID, 'current_plan', true);
            // $hosting_plan = get_user_meta($userID, 'hosting_planid', true);
            update_term_meta($term_id, 'current_plan', "");
            update_term_meta($term_id, 'hosting_planid', "75783");
            update_term_meta($term_id, 'hosting_orderid', "");
            update_user_meta($userID, 'project_limit', $latest_limit);
            wp_schedule_single_event(time(), 'newappprocess', [$project_catnm, $userID,$term_id]);
            
            
            $code = 200;
            $msg = 'Your request for creating an application is submitted.';
            $result = array(
                'code' => $code,
                'message' => $msg
            );
            return $result;
            echo json_encode($result);
            die;
        }
    }


    public function schedulenewapp($order_id,$hosting_plan,$divi_hosting = false) {
        $userID = get_current_user_id();
        $project_catnm = get_user_meta($userID, 'current_project_name', true);
        $builder_terms = get_terms(
            array(
                'taxonomy' => 'project_categories',
                'name' => $project_catnm,
                'meta_query' => array(
                    array(
                        'key' => 'builder_cat_user',
                        'value' => $userID,
                        'compare' => '='
                    )
                )
            )
        );
        if(!empty($builder_terms) && count($builder_terms) > 0){
            $result = array(
                'code' => '500',
                'message' => 'Project already exists with this name'
            );
            return $result;
            echo json_encode($result);die();
        }else{
            $user_role = get_user_role_name($userID);
            //get_user_meta($userID,'current_project_name',true);
            $slug = sanitize_title($project_catnm);
            $args = array('name' => $project_catnm, 'taxonomy' => 'project_categories');
            $termslug = wp_unique_term_slug($slug, (object) $args);
            if(empty($project_catnm)){
                return '';exit;
            }
            $cid = wp_insert_term($project_catnm, 'project_categories', array(
                'description' => '', 'slug' => $termslug
            ));
            //$builder_elementor_type=get_user_meta($userID, 'current_builder_option', true);
          
            $term_id = $cid['term_taxonomy_id'];

            //$builder_elementor_type=get_user_meta($userID, 'current_builder_option', true);
         
            add_term_meta($term_id, "builder_cat_user", $userID);
            $subs_plan = get_user_meta($userID, 'current_plan', true);
            // $hosting_plan = get_user_meta($userID, 'hosting_planid', true);
            update_term_meta($term_id, 'current_plan', $subs_plan);
            update_term_meta($term_id, 'hosting_planid', $hosting_plan);
            update_term_meta($term_id, 'hosting_orderid', $order_id);
            
            //update_term_meta($term_id, 'builder_wordpress_type', $builder_elementor_type);
            if($divi_hosting === true){
                wp_schedule_single_event(time(), 'createserverandapp', [$project_catnm, $userID,$term_id, $hosting_plan]);
            }else{
                wp_schedule_single_event(time(), 'newappprocess', [$project_catnm, $userID,$term_id]);
            }
            
            $code = 200;
            $msg = 'Your request for creating an application is submitted.';
            $result = array(
                'code' => $code,
                'message' => $msg
            );
            return $result;
            echo json_encode($result);
            die;
        }
    }

    public function deleteapp() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = 200;
            $msg = '';
            $cloud = new Cloudways();
            $output = json_decode($cloud->deleteRequest('/app/' . $_POST['app_id'], ['server_id' => $_POST['server_id'], 'appId' => $_POST['app_id']]));
            if (isset($output->operation_id)) {
                $usermeta = get_user_meta(get_current_user_id(), 'application_data', true);
                if (!empty($usermeta) && unserialize($usermeta) !== false) {
                    $usermeta = unserialize($usermeta);
                    $application_ids = array_column($usermeta['application'], 'app_id');

                    if (!empty($application_ids)) {
                        $newmeta = $usermeta;
                        $parentkey = key_get_parents($_POST['app_id'], $usermeta['application'], 'app_id');
                        if (!is_null($parentkey)) {
                            unset($newmeta['application'][$parentkey]);
                            $newmeta['application'] = array_values($newmeta['application']);
                            if ($usermeta !== $newmeta) {
                                update_user_meta(get_current_user_id(), 'application_data', serialize($newmeta));
                            }
                        }
                    }
                }
                sleep(2);
                $code = 200;
                $msg = 'Application Deleted Successfully.';
            } else {
                $code = 500;
                $msg = (isset($output->error)) ? $output->error : 'Something Went Wrong.';
            }
        } else {
            $code = 500;
            $msg = 'Method Not Allowed';
        }

        $result = array(
            'code' => $code,
            'message' => $msg
        );
        echo json_encode($result);
        die();
    }

    public function save_db_credentials() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = 200;
            $msg = '';
            if (is_user_logged_in()) {
                $cloud = new Cloudways();
                $output = json_decode($cloud->postRequest('/app/manage/dbPassword', ['server_id' => $_POST['server_id'], 'app_id' => $_POST['app_id'], 'password' => $_POST['password']]));
                if (empty($output)) {

                    $userID = get_current_user_id();
                    $web_meta = get_user_meta($userID,trim('website_'.$_POST['app_id']),true);
                    if(is_object($web_meta) && !empty($web_meta)){
                        $web_meta->mysql_password = $_POST['password'];
                        update_user_meta($userID,trim('website_'.$_POST['app_id']),$web_meta);

                    }

                    $code = 200;
                    $msg = 'Database Password Updated Successfully.';
                } else {
                    $code = 500;
                    $msg = (isset($output->error)) ? $output->error : 'Something Went Wrong.';
                }
                $result = array(
                    'code' => $code,
                    'message' => $msg
                );
                echo json_encode($result);
                die();
            }
        } else {
            $result = array(
                'code' => 500,
                'message' => 'Method Not Allowed'
            );
            echo json_encode($result);
            die();
        }
    }
    public function changeAdminCredentials(){
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = 200;
            $msg = '';
            if (is_user_logged_in()) {
                $userID = get_current_user_id();
                global $wpdb;
                $user_meta = get_user_meta($userID,trim('website_'.$_POST['app_id']),true);
                $website_url="https://".$user_meta->app_fqdn."/";

                $sys_user= $user_meta->sys_user;


                //SFTP
                $public_ip = $user_meta->public_ip;
                $sftp_user = $user_meta->sftp_user;
                $sftp_pass = $user_meta->sftp_pass;


                //Mysql Connectiviety 
                $servername = $public_ip;
                $username = $user_meta->mysql_user;
                $password = $user_meta->mysql_password;
                $dbname = $user_meta->mysql_db_name;

               
                //External DB connectivity
                @$conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                
                if ($conn->connect_error) {
                    $code = 202;             
                    $message = "Database connectivity failed";
                             
                } else {

                    $sql_user_update = "UPDATE wp_users SET user_pass= '".md5($_POST['password'])."' WHERE ID='1'";
                    if($conn->query($sql_user_update)){
                        $user_meta->app_password = $_POST['password'];
                        update_user_meta($userID,trim('website_'.$_POST['app_id']),$user_meta);

                        
                        $code = 200;
                        $msg = 'Application Password Updated Successfully.';
                    }else {
                        $code = 500;
                        $msg = (isset($output->error)) ? $output->error : 'Something Went Wrong.';
                    }
                } 
                $result = array(
                    'code' => $code,
                    'message' => $msg
                );
                echo json_encode($result);
                die();
            }
        } else {
            $result = array(
                'code' => 500,
                'message' => 'Method Not Allowed'
            );
            echo json_encode($result);
            die();
        }
    }

    public function save_app_credentials() {

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = 200;
            $msg = '';
            if (is_user_logged_in()) {
                $cloud = new Cloudways();

                $term_id = $_REQUEST['term_id'];
                $sftp_meta = get_term_meta($term_id, "sftp_credentials", true);
                $final_array = $last_array = array();

                if ($_POST['type'] == 'add') {
                    $output = $cloud->createCredentials(['server_id' => $_POST['server_id'], 'app_id' => $_POST['app_id'], 'username' => $_POST['username'], 'password' => $_POST['password']]);

                    if (isset($output->app_cred_id)) {
                        $cred_id = $output->app_cred_id;

                        $usernm = $_POST['username'];
                        $userpwd = $_POST['password'];
                        $app_credentials = json_decode($cloud->getRequest('/app/creds?access_token=' . $cloud->getToken() . '&server_id=' . $_REQUEST['server_id'] . '&app_id=' . $_REQUEST['app_id']));

                        if (isset($app_credentials->app_creds)):
                            foreach ($app_credentials->app_creds as $k => $cred):
                                $final_array[] = array(
                                    'cred_id' => $cred->id,
                                    'username' => $cred->sys_user,
                                    'user_pwd' => $cred->sys_password
                                );
                            endforeach;
                            update_term_meta($term_id, "sftp_credentials", $final_array);
                        else:
                            if (isset($sftp_meta) && !empty($sftp_meta)) {
                                foreach ($sftp_meta as $inner_array) {
                                    $last_array[] = array(
                                        'cred_id' => $inner_array['cred_id'],
                                        'username' => $inner_array['username'],
                                        'user_pwd' => $inner_array['user_pwd']
                                    );
                                }

                                $save_sftp[] = array(
                                    'cred_id' => $cred_id,
                                    'username' => $usernm,
                                    'user_pwd' => $userpwd
                                );

                                $final_array = array_merge($last_array, $save_sftp);
                            } else {
                                $final_array[] = array(
                                    'cred_id' => $cred_id,
                                    'username' => $usernm,
                                    'user_pwd' => $userpwd
                                );
                            }
                            update_term_meta($term_id, "sftp_credentials", $final_array);
                        endif;
                        $code = 200;
                        $msg = 'App Credentials Created Successfully.';
                    } else {
                        $code = 500;
                        if(isset($output->username)){
                            $msg = @$output->username[0]->message;
                        }else{
                            $msg = (isset($output->message)) ? $output->message : 'Something Went Wrong.';
                        }
                        
                    }
                } elseif($_POST['type'] == 'update') {

                    $output = json_decode($cloud->putRequest('/app/creds/' . $_POST['cred_id'], ['app_cred_id' => $_POST['cred_id'], 'server_id' => $_POST['server_id'], 'app_id' => $_POST['app_id'], 'username' => $_POST['username'], 'password' => $_POST['password']]));

                    if (isset($output->message)) {
                        $code = 500;
                        $msg = (isset($output->message)) ? $output->message : 'Something Went Wrong.';
                    } else if (isset($output->status)) {
                        $usernm = $_POST['username'];
                        $userpwd = $_POST['password'];
                        $cred_id = $_REQUEST['cred_id'];

                        //Unset Array
                        $sftp_meta_parent = array_search($cred_id, array_column($sftp_meta, 'cred_id'));
                        unset($sftp_meta[$sftp_meta_parent]);
                        $app_credentials = json_decode($cloud->getRequest('/app/creds?access_token=' . $cloud->getToken() . '&server_id=' . $_REQUEST['server_id'] . '&app_id=' . $_REQUEST['app_id']));

                        if (isset($app_credentials->app_creds)):
                            foreach ($app_credentials->app_creds as $k => $cred):
                                $final_array[] = array(
                                    'cred_id' => $cred->id,
                                    'username' => $cred->sys_user,
                                    'user_pwd' => $cred->sys_password
                                );
                            endforeach;
                            update_term_meta($term_id, "sftp_credentials", $final_array);
                        else:
                            //Loop
                            foreach ($sftp_meta as $inner_array) {
                                $last_array[] = array(
                                    'cred_id' => $cred_id,
                                    'username' => $inner_array['username'],
                                    'user_pwd' => $inner_array['user_pwd']
                                );
                            }

                            $save_sftp[] = array(
                                'cred_id' => $cred_id,
                                'username' => $usernm,
                                'user_pwd' => $userpwd
                            );

                            $final_array = array_merge($last_array, $save_sftp);
                            update_term_meta($term_id, "sftp_credentials", $final_array);
                        endif;

                        $code = 200;
                        $msg = 'App Credentials Created Successfully.';
                    } else {
                        $code = 500;
                        $msg = (isset($output->error)) ? $output->error : 'Something Went Wrong.';
                    }
                }elseif($_POST['type'] == 'delete') {

                    $output = json_decode($cloud->deleteRequest('/app/creds/' . $_POST['cred_id'], ['app_cred_id' => $_POST['cred_id'], 'server_id' => $_POST['server_id'], 'app_id' => $_POST['app_id']]));
                    
                    if(!empty($output)) {
                        $code = 500;
                        $msg = (isset($output->message)) ? $output->message : 'Something Went Wrong.';
                    } else  {
                        $cred_id = $_REQUEST['cred_id'];

                        //Unset Array
                        $sftp_meta_parent = array_search($cred_id, array_column($sftp_meta, 'cred_id'));
                        unset($sftp_meta[$sftp_meta_parent]);


                        $app_credentials = json_decode($cloud->getRequest('/app/creds?access_token=' . $cloud->getToken() . '&server_id=' . $_REQUEST['server_id'] . '&app_id=' . $_REQUEST['app_id']));

                        if (isset($app_credentials->app_creds)):
                            foreach ($app_credentials->app_creds as $k => $cred):
                                $final_array[] = array(
                                    'cred_id' => $cred->id,
                                    'username' => $cred->sys_user,
                                    'user_pwd' => $cred->sys_password
                                );
                            endforeach;
                            update_term_meta($term_id, "sftp_credentials", $final_array);
                        else:
                            update_term_meta($term_id, "sftp_credentials", $sftp_meta);
                        endif;
                        $code = 200;
                        $msg = 'App Credentials Deleted Successfully.';
                    }
                }
                $result = array(
                    'code' => $code,
                    'message' => $msg
                );
                echo json_encode($result);
                die();
            }
        } else {
            $result = array(
                'code' => 500,
                'message' => 'Method Not Allowed'
            );
            echo json_encode($result);
            die();
        }
    }

    public function checkavailableServer($args) {
        
        $hosting_plan_id = get_term_meta($args['term_id'], 'hosting_planid', true);
        $assigned_server_id = '679324';
        $assigned_server_id = get_field(trim('current_server'),$hosting_plan_id);

        return $assigned_server_id;
    }

    
    public function createappnew($project_catnm, $userID,$term_id) {

        global $wpdb;
        $code = 200;
        $msg = '';
        $cloudway = new Cloudways();
        // Create Project first


        if (isset($term_id)) {

            $hosting_plan_id = get_term_meta($term_id, 'hosting_planid',true);


            // Check for server capacity
            $serverid = $this->checkavailableServer(['term_id' => $term_id]);
            $available_apps = get_option(trim('server_'.$serverid),true); 
            

            if(is_array($available_apps) && count($available_apps) > 0){

                $app_index =  (count($available_apps) > 1)?rand(0,count($available_apps)-1):0; 
                $assigned_app_id = $available_apps[$app_index]->id;
            }

            $category_data = get_term_by('id', $term_id, 'project_categories');

            wp_schedule_single_event(time() + 600, 'monitorserver', [$serverid]);

            $app_nm = $category_data->name;
            $newappname = $this->generateStringRandom(10);
            if(!isset($assigned_app_id) && empty($assigned_app_id)){
                $res = $cloudway->createApp(['server_id' => $serverid, 'application' => 'wordpressdefault', 'app_label' => $newappname]);

                if (is_array($res)) {
                    if ($res['status'] === true) {
                        $appid = 0;
                        // $isexist = get_user_meta($userID, 'application_data', true);
                        // if (!empty($isexist) && unserialize($isexist) !== false) {
                        //     $olddata = unserialize($isexist);
                        //     $olddata['application'][] = ['server_id' => $serverid, 'operation_id' => $res['operation_id'], 'app_id' => $appid];
                        //     $metadata = $olddata;
                        // } else {
                        //     $metadata['application'][] = ['server_id' => $serverid, 'operation_id' => $res['operation_id'], 'app_id' => $appid];
                        // }

                        //update_user_meta(get_current_user_id(), 'application_data', serialize($metadata));
                        insertOperation(['user_id' => $userID, 'server_id' => $serverid, 'operation_id' => $res['operation_id'], 'app_id' => $appid, 'status' => 'processing', 'operation_type' => 'new_app']);
                        $code = 200;
                        $msg = 'Your request for creating an application is submitted.';
                        delete_user_meta($userID, 'current_project_name');
                        $time = time() + 60;
                        wp_schedule_single_event($time, 'checkifappCreated', [$userID, $term_id,$res['operation_id']]);
                    } else {
                        $code = 500;
                        $msg = $res['error'];
                    }
                } else {
                    $code = 500;
                    $msg = 'Something Went Wrong.';
                }
            }else{
                update_term_meta($term_id, "bloxx_app_id", $assigned_app_id);
                $available_apps[$app_index]->label = $app_nm;
                $available_apps[$app_index]->app_user = 'admin';
                update_user_meta($userID, 'website_' . $assigned_app_id, $available_apps[$app_index]);
                // update application password
                $this->updateapplicatonusername($userID,$assigned_app_id);

                // Reset file permission
                    wp_schedule_single_event(time() + 20, 'resetfile_permission', [$serverid,$assigned_app_id]);
              
                // End




                $time = time();
                wp_schedule_single_event($time, 'bloxx_plugin_process_cron', [$userID, $term_id]);

                $table = $wpdb->prefix . 'bloxx_operations';
                $wpdb->insert($table,['user_id'=>$userID,'server_id'=>$serverid,'app_id'=>$assigned_app_id,'operation_id'=>rand(1,999999),'operation_type'=>'cron','status'=>'processing']);
                $code = 200;
                $cloudway->putRequest('/app/'.$assigned_app_id,['appId'=>$assigned_app_id,'server_id'=>$serverid,'label'=>$app_nm]);
                $msg = 'Your request for creating an application is submitted.';
                delete_user_meta($userID, 'current_project_name');  
                unset($available_apps[$app_index]);

                

                 $available_apps = update_option(trim('server_'.$serverid),array_values($available_apps));
                 $newappname = $this->generateStringRandom(10);
                $res = $cloudway->createApp(['server_id' => $serverid, 'application' => 'wordpressdefault', 'app_label' => $newappname]);
                
                if (is_array($res)) {
                    if ($res['status'] === true) {
                        $time = time() + 60;
                        wp_schedule_single_event($time, 'trackappprogress', [$serverid, $res['operation_id'],$term_id]);
                    } else {
                        $code = 500;
                        $msg = $res['error'];
                    }
                }


            }

            $result = array(
                'code' => $code,
                'message' => $msg,
                'term_id' => $term_id
            );
            echo json_encode($result);
            die();
        } else {
            $code = 500;
            $msg = 'Something Went Wrong.';
            $result = array(
                'code' => $code,
                'message' => $msg
            );
            echo json_encode($result);
            die();
        }
    }

    public function listall_applications() {
        if (is_user_logged_in()) {
            ?>
            <div class="contentWrapper" id="table-page">
                <!-- //sidebar  --> 
                <?php require_once ABSPATH . 'wp-content/plugins/divi-builder/templates/builder_siderbar.php'; //require_once 'builder_siderbar.php'; ?>
                <div class="wrapContent">
                    <div class="topWrapmenu" >
                        <div>
                            <a href="javascript:void(0);" class="togglebar"><img src="<?php echo plugins_url(); ?>/divi-builder/images/right-arrow.png"/></a>
                        </div>
                    </div>
                    <span class="page_edit_url" id="<?php echo site_url(); ?>"><!-- Site URL --></span>
                    <?php
                    $back_url = site_url() . "/apps";
                    $cloud = new Cloudways;
                    // $allapps = $cloud->getallapps();
                    // $allapps = json_decode($allapps);var_dump($allapps);
                    $userapps = [];
                    $usermeta = get_user_meta(get_current_user_id(), 'application_data', true);
                    if (!empty($usermeta) && unserialize($usermeta) !== false) {
                        $usermeta = unserialize($usermeta);
                        $userapps = array_column($usermeta['application'], 'app_id');
                        $application_ids = array_column($usermeta['application'], 'operation_id');

                        if (!empty($application_ids)) {
                            $newmeta = $usermeta;
                            for ($i = 0; $i < count($application_ids); $i++) {
                                $operationstatus = $cloud->operationStatus($application_ids[$i]);
                                $operationstatus = json_decode($operationstatus);

                                if (isset($operationstatus->operation->app_id) && $operationstatus->operation->app_id != '0') {
                                    $parentkey = key_get_parents($application_ids[$i], $usermeta['application']);

                                    if (!is_null($parentkey)) {
                                        $newmeta['application'][$parentkey]['app_id'] = $operationstatus->operation->app_id;
                                        $userapps[] = $operationstatus->operation->app_id;
                                    }
                                } else {
                                    $parentkey = key_get_parents($application_ids[$i], $usermeta['application']);
                                    $userapps[] = $usermeta['application'][$parentkey]['app_id'];
                                }
                            }
                            if ($usermeta !== $newmeta) {
                                update_user_meta(get_current_user_id(), 'application_data', serialize($newmeta));
                            }
                        }
                    }


                    $allapps = $cloud->getallapps();
                    $allapps = json_decode($allapps);
                    $userapps = array_unique($userapps); //echo "<pre>";print_r($userapps);
                    ?>
                    <div class="tabWrapcontent">                        
                        <div class="project_buttons_light bg-theme-gradient rounded-top-left-right">
                            <div class="project_heading">
                                <h3 class="text-white">Applications</h3>
                            </div>
                            <div class="project_theme_button builder_cats builder_page">
                                <a id="add_app" class="add_app project-btn" data-user="" href="javascript:void(0)"><img src="<?php echo plugins_url(); ?>/bloxx-apps/assets/img/icon-plus.png" width="10px">&nbsp;&nbsp;</a>
                                <p id="operation_status" style="display: none;"></p>

                            </div>
                        </div>
                        <div class="siteTable template-table-responsive">
                            <table cellSpacing="0" id="bloxxapp_table" class="table table-striped">
                                <thead>
                                <th>Name</th>
                                <th>IP Address</th>
                                <th>Options</th>
                                </thead>
                                <?php
                                $counter = 0;
                                if (!empty($userapps) && isset($allapps->servers)):

                                    foreach ($allapps->servers as $key => $app):
                                        if (isset($app->apps) && count($app->apps) > 0):
                                            for ($a = 0; $a < count($userapps); $a++):
                                                if (!isset($userapps[$a])) {
                                                    continue;
                                                }
                                                $pkey = key_get_parents2($userapps[$a], $app->apps);
                                                if (is_null($pkey)) {
                                                    continue;
                                                }
                                                $counter++;
                                                if (!metadata_exists('user', get_current_user_id(), 'website_' . $app->apps[$pkey]->id)) {
                                                    //          $sftpuser = generateRandomUsername(10);
                                                    //          $sftp_pass = generateRandomPassword(10);
                                                    //          $output = $cloud->createCredentials(['server_id'=>$app->apps[$pkey]->server_id,'app_id'=>$app->apps[$pkey]->id,'username'=>$sftpuser,'password'=>$sftp_pass]);
                                                    // if(isset($output->app_cred_id)){
                                                    $app->apps[$pkey]->sftp_user = $app->master_user;
                                                    $app->apps[$pkey]->sftp_pass = $app->master_password;
                                                    $app->apps[$pkey]->public_ip = $app->public_ip;

                                                    update_user_meta(get_current_user_id(), 'website_' . $app->apps[$pkey]->id, $app->apps[$pkey]);
                                                    // }
                                                }
                                                // foreach ($app->apps as $k => $value):
                                                //  if(!in_array($value->id, $userapps)){
                                                //      continue;
                                                //  }
                                                ?>
                                                <tr>
                                                    <td>
                                                        <span><?php echo $app->apps[$pkey]->label; ?> </span>
                                                    </td>
                                                    <td>
                                                        <?php echo $app->public_ip; ?>
                                                    </td>
                                                    <td>
                                                        <ul class="builder_action_btn">
                                                            <li>
                                                                <form action="<?php echo site_url() . '/bloxx-application-details/'; ?>" method="get">
                                                                    <input type="hidden" name="app_label" value="<?php echo $app->apps[$pkey]->label; ?>">
                                                                    <input type="hidden" name="app_ip" value="<?php echo $app->public_ip; ?>">
                                                                    <input type="hidden" name="app_url" value="<?php echo $app->apps[$pkey]->app_fqdn; ?>">
                                                                    <input type="hidden" name="app_db" value="<?php echo $app->apps[$pkey]->mysql_db_name; ?>">
                                                                    <input type="hidden" name="db_user" value="<?php echo $app->apps[$pkey]->mysql_user; ?>">
                                                                    <input type="hidden" name="db_pass" value="<?php echo $app->apps[$pkey]->mysql_password; ?>">
                                                                    <input type="hidden" name="server_id" value="<?php echo $app->apps[$pkey]->server_id; ?>">
                                                                    <input type="hidden" name="app_user" value="<?php echo $app->apps[$pkey]->app_user; ?>">
                                                                    <input type="hidden" name="app_password" value="<?php echo $app->apps[$pkey]->app_password; ?>">
                                                                    <input type="hidden" name="app_id" value="<?php echo $app->apps[$pkey]->id; ?>">
                                                                    <button type="submit" name="submit"><i class="fa fa-external-link" aria-hidden="true"></i></button>
                                                                </form>
                                                            </li>
                                                            <li>
                                                                <button type="button" data-server-id="<?php echo $app->apps[$pkey]->server_id; ?>" data-app-id="<?php echo $app->apps[$pkey]->id; ?>" onclick="deleteApp(this)"><i class="fa fa-trash" aria-hidden="true"></i></button></td>
                                                            </li>
                                                </tr>
                                                <?php
                                            endfor;
                                        endif;
                                    endforeach;
                                endif;
                                $totalapplisted = ($counter == count($userapps)) ? 0 : 1;
                                ?>

                            </table>
                            <input type="hidden" name="pending_process_count" id="pending_process_count" value="<?php echo @$totalapplisted; ?>">
                            <div id="add_app-main" class="modal" style="display: none;">
                                <div class="modal-content modal-sm">
                                    <div class="modal-header">
                                        <span class="closebtn" onclick="jQuery('#add_app-main').hide();"><img src="<?php echo plugins_url(); ?>/divi-builder/images/cancel.png" class="img-fluid" width="20px"></span>
                                        <h3 id="page_nm" class="text-white text-center text-bold">Add Application</h3>
                                    </div>
                                    <div class="importBox">
                                        <form method="post" class="bloxx_app" id="bloxx_app" autocomplete="off" style="width: 100%;">
                                            <div>
                                                <div id="step1">
                                                    <!-- <div class="form-group">
                                                            <select name="plan" class="form-select" onchange="jQuery('select[name=server_id]').val(jQuery(this).data('server-id'))">
                                                                    <option value="lite" data-server-id="624207">Lite</option>
                                                                    <option value="standard" data-server-id="624207">Standard</option>
                                                                    <option value="elite" data-server-id="624207">ELite</option>
                                                                    <option value="dedicated" data-server-id="624207">Dedicated</option>
                                                            </select>
                                                    </div> -->
                                                    <div class="form-group">
                                                        <input type="text" placeholder="Application Name" name="app_label" required class="form-input">
                                                    </div>
                                                    <!-- <input type="hidden" name="server_id" value="589117"> -->
                                                    <input type="hidden" name="server_id" value="679324">
                                                    <input type="hidden" name="plan" value="lite">
                                                </div>

                                            </div>
                                            <button type="submit" class="default-btn" id="createapp-btn"><i class="fa fa-plus"></i>&nbsp;&nbsp;Create</button>
                                    </div>
                                    <input type="hidden" name="action" value="create_bloxx_app">
                                    </form>
                                    <p id="res-msg"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <?php
        }
    }

    public function appDetails() {

        if (is_user_logged_in() && isset($_REQUEST['server_id'])) {

            $cloud = new Cloudways();
            $app_credentials = json_decode($cloud->getRequest('/app/creds?access_token=' . $cloud->getToken() . '&server_id=' . $_REQUEST['server_id'] . '&app_id=' . $_REQUEST['app_id']));
            ?>
            <style type="text/css">
                .tab-content.hide{display: none;}
            </style>
            <div class="contentWrapper" id="table-page">
                <!-- //sidebar  --> 
                <?php require_once builder_path . 'templates/builder_siderbar.php'; //require_once 'builder_siderbar.php';  ?>
                <div class="wrapContent">
                    <div class="topWrapmenu" >
                        <div>
                            <a href="javascript:void(0);" class="togglebar"><img src="<?php echo plugins_url(); ?>/divi-builder/images/right-arrow.png"/></a>
                        </div>
                    </div>
                    <span class="page_edit_url" id="<?php echo site_url(); ?>"><!-- Site URL --></span>
                    <?php
                    $back_url = site_url() . "/apps";
                    $category_data = get_term_by('id', $_REQUEST['term_id'], 'project_categories');
                    ?>
                    <div class="project_heading  col-sm">
                        <p>
                            <a href="<?php echo site_url(); ?>/my-projects" class="link-btn"><i class="fa fa-angle-left"></i><span>&nbsp;&nbsp;Go Back</span></a>
                        </p>
                        <span class="title-light-theme">Project</span>
                        <h2 class="title-gradient project-title">
                            <?php
                            if (!empty($category_data)) {
                                echo $category_data->name;
                            }
                            ?>
                        </h2>                               
                    </div>

                    <div class="tabWrapcontent">                        
                        <div class="project_buttons_light bg-theme-gradient rounded-top-left-right"">
                            <div class="project_heading">
                                <h3 class="text-white">Application Management - <?php echo $_REQUEST['app_label']; ?></h3>
                            </div>
                            <div class="project_theme_button builder_cats col-sm">
                                <p id="operation_status" style="display: none;"></p>
                            </div>
                        </div>
                        <div class="accessDetails" id="accessDetails_container">
                            <input type="hidden" name="pending_process_count" id="pending_process_count" value="0">
                            <div class="columnDiv">
                                <div class="accessMenu">
                                    <ul>
                                        <li class="active"><a  href="javascript:void(0)" class="tab-links"  data-tab="access-details">Access Details</a></li>
                                        <li><a href="javascript:void(0)" class="tab-links"  data-tab="domain" data-action="app_domain">Domain Management</a></li>
                                        <li><a href="javascript:void(0)" class="tab-links"  data-tab="backup" data-action="backup-restore">Backup and Restore</a></li>
                                        <li><a href="javascript:void(0)"  class="tab-links" data-tab="ssl" data-action="getssl">SSL Certificate</a></li>
                                    </ul>
                                </div>
                                <input type="hidden" name="current_server_id" value="<?php echo $_REQUEST['server_id']; ?>">
                                <input type="hidden" name="current_app_id" id="current_app_id" value="<?php echo $_REQUEST['app_id']; ?>">
                                <input type="hidden" name="current_app_name" value="<?php echo $_REQUEST['app_label']; ?>">
                                <div class="app-loader" style="display:none"></div>
                                <div class="detailsCell tab-content" id="access-details">
                                    <h2>Access Details</h2>
                                    <div class="columnHalf">

                                        <p><?php echo @$_REQUEST['app_label']; ?><a href="https://<?php echo @$_REQUEST['app_url']; ?>" target="_blank"><i class="fa fa-external-link" aria-hidden="true"></i></a></p>
                                        <h4>Admin Panel</h4>
                                        <p><label>URL: <span><?php echo @$_REQUEST['app_url'] . '/wp-admin'; ?> <a href="https://<?php echo @$_REQUEST['app_url'] . '/wp-admin'; ?>" target="_blank"><i class="fa fa-external-link" aria-hidden="true"></i></a></span></label></p>
                                        <p class="no-margin"><label>Username: <span><?php echo @$_REQUEST['app_user']; ?></span></label> </p>
                                        <p data-pass="<?php echo @$_REQUEST['app_password']; ?>"><label>Password: <span>.........</span></label> <a href="javascript:void(0)" onclick="showpass(this)" class="hide-pass"><i class="fa fa-eye"></i></a></p>
                                        <!-- <h4>MYSQL Access</h4>
                                        <p class="no-margin"><label>DB name: <span>< ? php echo trim(@$_REQUEST['app_db']);?></span></label></p>
                                        <p class="no-margin"><label>Username:  <span>< ?php echo trim(@$_REQUEST['db_user']);?></span></label></p>
                                        <p  data-pass="< ?php echo @$_REQUEST['db_pass'];?>"><label>Password: <span>........</span></label>
                                        <a href="javascript:void(0)" class="db-btn" onclick="updatedb(this)" data-action="update"><i class="fa fa-pencil"></i></a>
                                        <a href="javascript:void(0)" onclick="showpass(this)" class="hide-pass"><i class="fa fa-eye"></i></a>
                                        <div style="display:none" id="db-form">
                                                    <input type="text" name="db_new_password" minlength="8" maxlength="60">
                                                    <button type="button" onclick="savedb(this)" class="default-btn">Save</button>
                                                    <button type="button" class="default-btn" onclick="updatedb(this)" data-action="cancel">Cancel</button>
                                                    <ul>
                                                            <li>Length between 8 and 50 characters</li>
                                                            <li>At least one lowercase character</li>
                                                            <li>At least one uppercase character</li>
                                                            <li>At least one number</li>
                                                    </ul>
                                            </div>
                                    </p> -->
                                    </div>
                                    <div class="columnHalf">
                                        <h4>Application Credentials</h4>
                                        <p>You can create and use multiple Application credentials for SFTP or SSH access to this application.</p>
                                        <?php
                                        if (isset($app_credentials->app_creds)):
                                            foreach ($app_credentials->app_creds as $k => $cred):
                                                ?>
                                                <p class="no-margin"><label>Public IP: <?php echo @$_REQUEST['app_ip']; ?></label></p>
                                                <p class="no-margin"><label>Username:  <?php echo $cred->sys_user; ?></label></p>
                                                <p data-id="<?php echo $cred->id; ?>" data-user="<?php echo $cred->sys_user; ?>" data-pass="<?php echo $cred->sys_password; ?>"><label>Password: <span>.......</span></label><a href="javascript:void(0)" onclick="changeCredentials(this)"><i class="fa fa-pencil"></i></a><a href="javascript:void(0)" onclick="showpass(this)" class="hide-pass"><i class="fa fa-eye"></i></a></p>
                                                <?php
                                            endforeach;
                                        endif;
                                        ?>
                                        <input type="button" value="Add" class="create_cred buttonCustom" data-server-id="<?php echo @$_REQUEST['server_id']; ?>" data-app-id="<?php echo $_REQUEST['app_id']; ?>" />

                                    </div>
                                    <!-- <button type="button" class="buttonCustom">Launch Database Manager</button> -->
                                </div>
                                <div id="domain" class="detailsCell tab-content hide">
                                    <?php
                                    // echo do_shortcode("[app_domain server_id=".$_REQUEST['server_id']." app_id=".$_REQUEST['app_id']."]");
                                    ?>
                                </div>
                                <div id="backup" class="detailsCell tab-content hide">
                                    <?php
                                    // echo do_shortcode("[backup-restore server_id=".$_REQUEST['server_id']." app_id=".$_REQUEST['app_id']."]");
                                    ?>
                                </div>
                                <div id="ssl" class="detailsCell tab-content hide"></div>
                            </div>
                        </div>



                        <div id="add_credentials-main" class="modal" style="display: none;">
                            <div class="modal-content modal-sm">
                                <div class="modal-header">
                                    <span class="closebtn" onclick="jQuery('#add_credentials-main').hide();"><img src="<?php echo plugins_url(); ?>/divi-builder/images/cancel.png" class="img-fluid" width="20px"></span>
                                    <h3 id="page_nm" class="text-white text-center text-bold">APP CREDENTIALS</h3>
                                </div>
                                <div class="importBox">
                                    <form method="post" class="bloxx_app" id="bloxx_app_crendentials" autocomplete="off" style="width: 100%;">
                                        <div>
                                            <div id="step1">
                                                <div class="form-group">
                                                    <input type="text" placeholder="Enter Username" name="username" required class="form-input">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" placeholder="Enter Password" name="password" required class="form-input" minlength="8" maxlength="60">
                                                </div>
                                                <input type="hidden" name="server_id" value="">
                                                <input type="hidden" name="app_id" value="">
                                                <input type="hidden" name="action" value="save_app_credentials">
                                                <input type="hidden" name="cred_id" value="">
                                                <input type="hidden" name="type" value="add">
                                            </div>

                                        </div>
                                        <button type="submit" class="default-btn" id="add_cred-btn"><i class="fa fa-plus"></i>&nbsp;&nbsp;Submit</button>
                                    </form>
                                    <p id="res-msg"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    }

    public function updateDomain($data,$subdomain) {
        $cloud = new Cloudways();
        $replace = $subdomain.'.bloxxapps';
       $out =  $cloud->postRequest('/app/manage/cname', ['server_id' => $data['server_id'], 'app_id' => $data['app_id'], 'cname' => str_replace('cloudwaysapps',$replace , $data['cname'])]);
      
       $time1 = time() + 40;
        wp_schedule_single_event($time1, 'updatesshparams', [$data['server_id'], $data['app_id']]);
          $time = time() + 90;
        wp_schedule_single_event($time, 'addssltoapp', [$data['server_id'], $data['app_id'],str_replace('cloudwaysapps',$replace,$data['cname'])]);
       
        return 'true';
    }

     public function addssltoappfun($serverid,$appid,$domain){
        $cloudobj = new Cloudways();
        $output = $cloudobj->postRequest('/security/lets_encrypt_install',['server_id'=>$serverid,'app_id'=>$appid,'ssl_email'=>'admin@gobloxx.io','wild_card'=>false,'ssl_domains'=>[$domain]]);
        $fp = fopen(bloxx_path.'/lidn.txt', 'w');
        fwrite($fp, $output);
        fclose($fp);
        $output = json_decode($output);
        if (!isset($output->operation_id)) {
            $time = time() + 30;
            wp_schedule_single_event($time, 'addssltoapp', [$serverid, $appid,$domain]);
        }
        die;
    }

    public function updatesshparamsfun($serverid,$appid){
        $cloudobj = new Cloudways();
        $cloudobj->postRequest('/app/updateAppSshPerms', ['server_id' => $serverid, 'app_id' => $appid, 'update_perms_action' => 'confirmed_enable']);
        return true;
    }

    public function generateStringRandom($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function updateapplicatonusername($userID,$appid){
        global $wpdb;
        $the_user = get_user_by( 'id', $userID ); 
        $usermail = $the_user->user_email;
        $user_meta = get_user_meta($userID,trim('website_'.$appid),true);
        $public_ip = $user_meta->public_ip;

        //Mysql Connectiviety 
        $servername = trim($public_ip);
        $username = trim($user_meta->mysql_user);
        $password = trim($user_meta->mysql_password);
        $dbname = trim($user_meta->mysql_db_name);

       
        //External DB connectivity
        @$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        
        if ($conn->connect_error) {
            return false;
                     
        } else {
            $sql_user_update = "UPDATE wp_users SET user_nicename='".$usermail."',user_email='".$usermail."',user_login = '".$usermail."',display_name='".$usermail."' WHERE ID='1'";
            $conn->query($sql_user_update);
            if($conn->query($sql_user_update)){
                $user_meta->app_user = $usermail;
                update_user_meta($userID,trim('website_'.$appid),$user_meta);
                return true;
            }else {
                return false;
            }
        } 
        return true;
    }

    public function createserverandappaction($project_catnm, $userID,$term_id,$hosting_plan_id) {

        global $wpdb;
        $code = 200;
        $msg = '';
        $cloudway = new Cloudways();
        // Create Project first

        if (isset($term_id)) {

            $hosting_plan_id = get_term_meta($term_id, 'hosting_planid',true);
            $category_data = get_term_by('id', $term_id, 'project_categories');
            $ram = get_field('ram',$hosting_plan_id);

            $app_nm = $category_data->name;
            $res = json_decode($cloudway->postRequest('/server', ['cloud' => 'do', 'application' => 'wordpressdefault', 'app_label' => $app_nm,'region' => 'sfo1','instance_type' => trim($ram),'app_version' => '5.8','server_label' => 'Server '. $app_nm]));
           
            if ($res->server && isset($res->server->id) && isset($res->server->operations)) {
                $code = 200;
                $msg = 'Your request for creating an application is submitted.';
                delete_user_meta($userID, 'current_project_name');
                $time = time() + 300;
                wp_schedule_single_event($time, 'checkifserverCreated', [$userID, $term_id,$res->server->operations[0]->id,$hosting_plan_id]);
            } else {
                $code = 500;
                $msg = $res->error;
            }

            $result = array(
                'code' => $code,
                'message' => $msg,
                'term_id' => $term_id
            );
            echo json_encode($result);
            die();
        } else {
            $code = 500;
            $msg = 'Something Went Wrong.';
            $result = array(
                'code' => $code,
                'message' => $msg
            );
            echo json_encode($result);
            die();
        }
    }

    public function resetfilepermission($serverid,$appid){
        $cloudobj = new Cloudways();
        $cloudobj->postRequest('/app/manage/reset_permissions', ['server_id' => $serverid, 'app_id' => $appid, 'ownership' => 'master_user']);
        return true;
    }

}

$apps = new Apps;
