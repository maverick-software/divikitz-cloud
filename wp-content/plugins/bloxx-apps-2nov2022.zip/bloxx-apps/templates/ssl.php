<?php

class Ssl{
	
	public function __construct(){
		
		add_action("wp_ajax_nopriv_installCertificate", array($this, "installCertificate"));
		add_action("wp_ajax_installCertificate", array($this, "installCertificate"));
		add_action("wp_ajax_nopriv_getssl", array($this, "getssl"));
		add_action("wp_ajax_getssl", array($this, "getssl"));

	}

	public function installCertificate(){
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$code = 200;$msg = '';
			if(is_user_logged_in()){ 
				$cloud = new Cloudways();
				$input = $_POST['dname'];
			    // $input = trim($input, '/');
			    //  $domain_name = str_replace(['https://','http://','www.'], '', $input);
				if(!empty($input) && is_array($input)){
					for ($i=0; $i <count($input) ; $i++) { 
							$input[$i] = trim($input[$i], '/');
							$input[$i] = str_replace(['https://','http://','www.'], '', $input[$i]);		
						}
						//print_r($input);die;
					$output = json_decode($cloud->putRequest('/security/lets_encrypt_install',['server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'ssl_email'=>$_POST['email'],'wild_card'=>false,'ssl_domains'=>$input]));
					 	$webdata = get_user_meta(get_current_user_id(),trim('website_'.$_POST['app_id']),true);//var_dump(gettype($webdata->lets_encrypt));
						if(isset($output->operation_id)){
							if(!empty($webdata)){
								$webdata->lets_encrypt= (object) ['ssl_domains'=>array_unique($input)];
								//echo "<pre>";print_r($webdata);die;
								update_user_meta(get_current_user_id(),trim('website_'.$_POST['app_id']),$webdata);
							}
							//insertOperation(['operation_id'=>$output->operation_id,'server_id'=>$_POST['server_id'],'app_id'=>$_POST['app_id'],'status'=>'processing']);
							$code = 200;$msg = 'Operation is in Progress. It will take 2-3 minutes to complete.';
						}else{
							$code = 500;$msg = (isset($output->message))?$output->message:'Something Went Wrong.';
						}
				}else{
					$code = 500;$msg = (isset($output->message))?$output->message:'Domain cannot be empty.';
				}
				$result=array(
					'code' => $code,					
					'message' => $msg
				);
				echo json_encode($result);
				die();
			}
		}else{
			$result=array(
				'code' => 500,					
				'message' => 'Method Not Allowed'
			);
			echo json_encode($result);
			die();
		}
	}

	public function getssl(){
		echo '<h2>SSL Management</h2>
                <p>Cloudways supports Lets Encrypt and custom SSL certificates. You can either create a free SSL certificate (choose the Lets Encryption SSL option) or deploy a Paid SSL certificate for your applications (choose an option from Custom SSL).</p>
                <select name="ssl_method">
                    <option value="lets_encrypt">Lets Encrypt</option>
                    
                </select>
                <div class="encryptDiv newStyle">
                    <p>Install a Lets Encrypt SSL certificate by providing the information below. This will override any existing SSL certificate you may have installed.</p>
                    <p><label>Email Address</label>
                    <input type="email" name="email" placeholder="email@domain.com" /></p>
                    <p><label>Domain Name</label>
                    <input type="text" name="dname" placeholder="www.domain.com" /></p>
                    <button type="button" class="buttonCustom" onclick="installCertificate(this)">Install Certificate</button>
                </div>
                <div class="noCert newStyle" style="display: none;">
                    <p>Create a Certificate Signing Request (CSR) on the server by providing information about your application. This will override any existing CSR and private key generated earlier.</p>
                    <button type="button" class="buttonCustom">Create CSR</button>
                </div>
                <div class="certDiv newStyle" style="display: none;">
                    <p>Install a custom SSL certificate by providing your application certificate and the private key.</p>
                    <button type="button" class="buttonCustom">Install SSL</button>
                </div>';die;
	}
	
}

$ssl = new Ssl();