<?php
class Subscription_plan {

    public function __construct() {
        add_shortcode('subscription_plan', array($this, 'my_subscription_plan'));
      
    }

    public function my_subscription_plan() {
        /*
       if (is_user_logged_in()) {
                    
                   if (have_posts()) : ?>
                      <div>
                        <?php while (have_posts()) : the_post(); 
                         
                            the_content();

                          endwhile; ?> 
                      </div>
                    <?php endif; 
        }
        */

        if (is_user_logged_in()) {
            global $current_user, $wp_roles;
            $current_user = wp_get_current_user();
            $user_id = $current_user->ID;
			
            $user_plan=get_user_meta($user_id, "current_plan", true);
            if($user_plan==""){
                $user_plan=get_field("select_product", 'option');
            }
            ?>

            <div class="contentWrapper user_actions" id="table-page">
                <!-- //sidebar  --> 
                <?php require_once 'builder_siderbar.php'; ?>

                <div class="wrapContent">
                    <!-- //Top Bar  --> 
                    <?php require_once 'builder_topnav.php'; ?>


                    <div class="wrapContainer">
                        <div class="rowWrap">
                            <div class="flex-12 dashboard_no mBottom">
                                <section class="subsc--plans--Page">
                                    <div class="subs--plans">
                                        <div class="container">            
                                           <!--  start plan  -->
                                           <h2>Plans and Pricing</h2>
                                           <p>*All plans include email ticketing support. Chat support will be available in the near future.</p>
                                           <div class="plans--flex--table">

                                                <?php
                                                $args = array(
                                                    'post_type' => 'product',
                                                    'showposts' => 3,
                                                    'order' => 'asc',
                                                    'tax_query' => array(
                                                        array(
                                                            'taxonomy' => 'product_cat',
                                                            'field' => 'term_id',
                                                            'terms' => 866
                                                        )
                                                    )
                                                );
                                                $query = new WP_Query($args);
                                                $product = get_posts($args);

                                                ?>

                                                <?php
                                                foreach ($product as $monthly_view) { 
                                                    $title= $monthly_view->post_title;
                                                    $mv_post_id = $monthly_view->ID;
                                                    $assets = get_field('assets', $mv_post_id);
                                                    $api_connection = get_field('api_connection', $mv_post_id);
                                                    $fragments = get_field('fragments', $mv_post_id);
                                                    $neo_builder = get_field('neo_builder', $mv_post_id);
                                                    $neo_writer = get_field('neo_writer', $mv_post_id);

                                                    $monthly_price = get_post_meta($mv_post_id, '_price', true);
                                                    $monthly_period = get_post_meta($mv_post_id, '_ywsbs_price_is_per', true);
                                                    $monthly_rec = get_post_meta($mv_post_id, '_ywsbs_price_time_option', true);

                                                    if ($monthly_period == 1) {
                                                        if ($monthly_rec == "years") {
                                                            $mon_per = "$".$monthly_price."/year.";
                                                        } else if ($monthly_rec == "months") {
                                                            $mon_per = "$".$monthly_price."/mo.";
                                                        } else if ($monthly_rec == "weeks") {
                                                            $mon_per = "$".$monthly_price."/week.";
                                                        } else {
                                                            $mon_per = "$".$monthly_price."/daily.";
                                                        }  
                                                                
                                                    } else {
                                                        if ($monthly_rec == "years") {
                                                            $mon_per = "$".$monthly_price."/".$monthly_period."year.";
                                                        } else if ($monthly_rec == "months") {
                                                            $mon_per = "$".$monthly_price."/".$monthly_period."mo.";
                                                        } else if ($monthly_rec == "weeks") {
                                                            $mon_per = "$".$monthly_price."/".$monthly_period."week.";
                                                        } else {
                                                            $mon_per = "$".$monthly_price."/".$monthly_period."daily.";
                                                        }  
                                                    } 

                                                    

                                                ?>
                                                    <div class="plans--flex--tr">
                                                        <h3 class="title--free"><?= $title; ?></h3>
                                                        <ul>
                                                            <li>
                                                                <span>
                                                                    <svg viewBox="0 0 24 24">
                                                                        <path class="cls-1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm5.707,8.707-7,7a1,1,0,0,1-1.414,0l-3-3a1,1,0,0,1,1.414-1.414L10,14.586l6.293-6.293a1,1,0,0,1,1.414,1.414Z"/>
                                                                    </svg>
                                                                </span>
                                                                <?= $assets; ?> Assets
                                                            </li>
                                                            <li>
                                                                <span>
                                                                    <svg viewBox="0 0 24 24">
                                                                        <path class="cls-1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm5.707,8.707-7,7a1,1,0,0,1-1.414,0l-3-3a1,1,0,0,1,1.414-1.414L10,14.586l6.293-6.293a1,1,0,0,1,1.414,1.414Z"/>
                                                                    </svg>
                                                                </span>
                                                                <?= $api_connection; ?> API Connection
                                                            </li>
                                                            <li>
                                                                <span>
                                                                    <svg viewBox="0 0 24 24">
                                                                        <path class="cls-1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm5.707,8.707-7,7a1,1,0,0,1-1.414,0l-3-3a1,1,0,0,1,1.414-1.414L10,14.586l6.293-6.293a1,1,0,0,1,1.414,1.414Z"/>
                                                                    </svg>
                                                                </span>
                                                                <?= $fragments; ?> Free Fragments
                                                            </li>
                                                            <li>
                                                                <span>
                                                                    <?php if($neo_builder=="yes"){ ?>
                                                                    <svg viewBox="0 0 24 24">
                                                                        <path class="cls-1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm5.707,8.707-7,7a1,1,0,0,1-1.414,0l-3-3a1,1,0,0,1,1.414-1.414L10,14.586l6.293-6.293a1,1,0,0,1,1.414,1.414Z"/>
                                                                    </svg>
                                                                    <?php } else { ?>
                                                                        <svg viewBox="0 0 512 512">
                                                                            <path class="cls-1" d="M256,33C132.3,33,32,133.3,32,257c0,123.7,100.3,224,224,224c123.7,0,224-100.3,224-224C480,133.3,379.7,33,256,33z    M364.3,332.5c1.5,1.5,2.3,3.5,2.3,5.6c0,2.1-0.8,4.2-2.3,5.6l-21.6,21.7c-1.6,1.6-3.6,2.3-5.6,2.3c-2,0-4.1-0.8-5.6-2.3L256,289.8   l-75.4,75.7c-1.5,1.6-3.6,2.3-5.6,2.3c-2,0-4.1-0.8-5.6-2.3l-21.6-21.7c-1.5-1.5-2.3-3.5-2.3-5.6c0-2.1,0.8-4.2,2.3-5.6l75.7-76   l-75.9-75c-3.1-3.1-3.1-8.2,0-11.3l21.6-21.7c1.5-1.5,3.5-2.3,5.6-2.3c2.1,0,4.1,0.8,5.6,2.3l75.7,74.7l75.7-74.7   c1.5-1.5,3.5-2.3,5.6-2.3c2.1,0,4.1,0.8,5.6,2.3l21.6,21.7c3.1,3.1,3.1,8.2,0,11.3l-75.9,75L364.3,332.5z"/>
                                                                        </svg>
                                                                    <?php } ?>
                                                                </span>
                                                                Neo's Builder
                                                            </li>
                                                            <li>
                                                                <span>
                                                                    <?php if($neo_writer=="yes"){ ?>
                                                                        <svg viewBox="0 0 24 24">
                                                                            <path class="cls-1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm5.707,8.707-7,7a1,1,0,0,1-1.414,0l-3-3a1,1,0,0,1,1.414-1.414L10,14.586l6.293-6.293a1,1,0,0,1,1.414,1.414Z"/>
                                                                        </svg>
                                                                    <?php } else { ?>
                                                                        <svg viewBox="0 0 512 512">
                                                                            <path class="cls-1" d="M256,33C132.3,33,32,133.3,32,257c0,123.7,100.3,224,224,224c123.7,0,224-100.3,224-224C480,133.3,379.7,33,256,33z    M364.3,332.5c1.5,1.5,2.3,3.5,2.3,5.6c0,2.1-0.8,4.2-2.3,5.6l-21.6,21.7c-1.6,1.6-3.6,2.3-5.6,2.3c-2,0-4.1-0.8-5.6-2.3L256,289.8   l-75.4,75.7c-1.5,1.6-3.6,2.3-5.6,2.3c-2,0-4.1-0.8-5.6-2.3l-21.6-21.7c-1.5-1.5-2.3-3.5-2.3-5.6c0-2.1,0.8-4.2,2.3-5.6l75.7-76   l-75.9-75c-3.1-3.1-3.1-8.2,0-11.3l21.6-21.7c1.5-1.5,3.5-2.3,5.6-2.3c2.1,0,4.1,0.8,5.6,2.3l75.7,74.7l75.7-74.7   c1.5-1.5,3.5-2.3,5.6-2.3c2.1,0,4.1,0.8,5.6,2.3l21.6,21.7c3.1,3.1,3.1,8.2,0,11.3l-75.9,75L364.3,332.5z"/>
                                                                        </svg>
                                                                    <?php } ?>
                                                                </span>
                                                                Neo's Writer
                                                            </li>
                                                        </ul>
                                                        <h3><?= $mon_per ?></h3>

                                                        <?php if($user_plan==$mv_post_id){ ?>
                                                            <a href="javascript:void(0)" class="neo--btn neo-default" >Current</a>
                                                        <?php } else { ?>
                                                            <a href="<?php echo get_site_url();?>?add-to-cart=<?php echo $mv_post_id;?>" class="neo--btn" >Purchase</a>
                                                        <?php } ?>
                                                    </div>
                                                <?php } ?>
                                           </div> 
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </section>

                                <script>
                                    jQuery(document).ready(function () {
                                        jQuery(".switch-button-checkbox").on("change", function () {
                                            if (jQuery(".switch-button-checkbox:checked").val() == "Yearly") {
                                                jQuery("#yearly_view").show();
                                                jQuery("#monthly_view").hide();
                                            } else {
                                                jQuery("#yearly_view").hide();
                                                jQuery("#monthly_view").show();
                                            }
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>

                </div>  
                <?php require_once 'builder_footer.php'; ?>
            </div>
            <?php
        } else {
            restricate_page_content();
        }
    }

}

$subscription_plan = new Subscription_plan();
