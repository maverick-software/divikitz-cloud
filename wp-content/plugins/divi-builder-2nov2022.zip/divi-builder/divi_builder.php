<?php

/*
  Plugin Name: Neo's Cloud
  Plugin URI: https://web1experts.com/
  Description: Customize WordPress with Divi Builder.
  Version: 5.9.1
 */

error_reporting(E_ALL);
define('builder_url', plugin_dir_url(__FILE__));
define('builder_path', plugin_dir_path(__FILE__));
define('builder_plugin', plugin_basename(__FILE__));
define('builder_apiurl', "https://cloud.neosbuilder.com/");
define('CURRENT_SITEURL', get_site_url());

require_once 'includes/builder_core.php';


remove_role( 'vendor' );
remove_role( 'pending_vendor' );
remove_role( 'yith_affiliate' );
remove_role( 'disable_vendor' );
remove_role( 'wcfm_vendor' );
remove_role( 'shop_manager' );
remove_role( 'editor' );
remove_role( 'subscriber' );
remove_role( 'contributor' );
remove_role( 'author' );

if(!function_exists('pre')){
    function pre($arr){
        echo '<pre>';
        print_r($arr);
        echo '</pre>';
    }
}


function get_usertype_byapi_curl($current_user_email,$website_url,$api_key){
    $curl_url = builder_apiurl."wp-json/bloxx-user/check_usertype/";                
    $builder_page_array = array(
        'user_email' => $current_user_email,
        'website_url' => $website_url,
        'builder_key' => $api_key,
    );
}

function get_sitebloxx_userid_from_siteurl($website_url){
        
    global $wpdb;
    $connected_sites_table = $wpdb->prefix . 'connected_sites';
    $site_url = $website_url.'/';
   // $query="select * from $bloxx_apis where website_url='$website_url' and user_id='$user_id' and api_key='$api_key' and status=1";
    $query="select * from $connected_sites_table where site_url='$site_url'";
    $rows = $wpdb->get_results($query);
    $siteblox_user_id = @$rows[0]->siteblox_user_id;
    
    // pre($rows);
    if($siteblox_user_id!=''){
        $siteblox_user_id_final= $siteblox_user_id;
    } else {
        $siteblox_user_id_final = 0;
    }

    return $siteblox_user_id_final;
}

function siteurl_exists($siteurl){
    global $wpdb;
    $api_table = $wpdb->prefix . 'bloxx_apis';
    $sql3 = "SELECT * FROM `$api_table` WHERE `website_url` = '$siteurl'";
    $getdata3  = $wpdb->get_results($sql3);
    if(count($getdata3) > 0){
        $is_website_url_exists = 1;
    }
    else{
        $is_website_url_exists = 0; // this url not exists in divibloxx
    }

    return $is_website_url_exists;
}



function isSiteBlocked($api_key,$term_id){
   global $wpdb;

    $blocked_sites_table = $wpdb->prefix . 'bloxx_blocked_sites';

    //$sql3 = "SELECT * FROM `$blocked_sites_table` WHERE 
    //`api_key` = '$api_key' and  `site_url` = '$site_url' and  `term_id` = '$term_id' and  `user_id` = '$user_id'";
    
    $sql3 = "SELECT * FROM `$blocked_sites_table` WHERE 
    `api_key` = '$api_key' and  `term_id` = '$term_id'";
    $getdata3  = $wpdb->get_results($sql3);
    if(count($getdata3) > 0){
        $site_blocked = 1; //this url is blocked
    }
    else{
        $site_blocked = 0; // this url is not blocked
    }

    return $site_blocked;
}



function bloxx_encrypt($str){
 $code = bin2hex($str);
 return $code;
}

function bloxx_decrypt($str){
 $code = hex2bin($str);
 return $code;
}

function get_userid_by_username($username){
    $userdata = get_user_by('login', $username);
    if($userdata){
        $get_user_id = $userdata->ID;
        if($get_user_id){
            $user_id = $get_user_id;
        }else{
            $user_id = 0;
        }
    }else{
        $user_id = 0;
    }
    
    return $user_id;
}


function get_userid_by_email($username){
    $userdata = get_user_by('email', $username);

    if($userdata){
        $get_user_id = $userdata->ID;
        if($get_user_id){
            $user_id = $get_user_id;
        }else{
            $user_id = 0;
        }
    }else{
        $user_id = 0;
    }
    
    return $user_id;
}


function get_username_by_email($email){
    $userdata = get_user_by('email', $email);
    if($userdata){
        $get_user_login = $userdata->user_login;
        if($get_user_login){
            $user_login = $get_user_login;
        }else{
            $user_login = 0;
        }
    }else{
        $user_login = 0;
    }
    
    return $user_login;
}

function get_username_by_userid($user_id){
    $userdata = get_user_by('id', $user_id);
    if($userdata){
        $get_user_login = $userdata->user_login;
        if($get_user_login){
            $user_login = $get_user_login;
        }else{
            $user_login = 0;
        }
    }else{
        $user_login = 0;
    }
    
    return $user_login;
}


function siteblox_check_usertype_byapi($user_id, $website_url, $api_key){
    global $wpdb;
    $bloxx_apis = $wpdb->prefix . 'bloxx_apis';
    $query="select * from $bloxx_apis where website_url='$website_url' and api_key='$api_key' and status=1";
    $rows = $wpdb->get_results($query);
    $term_id = $rows[0]->term_id;
    if($rows[0]->id!='' && isSiteBlocked($api_key,$term_id)==0){
        $api_status = 1;
    } else {
        $api_status = 0;
    }
    return $api_status;
}


function generateRandomString($length = 25) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function get_current_user_limits($user_role) {
        
    if ($user_role == 'Administrator') {
        $assets = "10000000000";
        $api_connection= "10000000000";
        $fragment= "10000000000";
        $neo_builder="enable";
        $neo_writter="enable";
    }
    if ($user_role == 'Free') {
        $product_id= get_field('select_product', 'options');
        $assets = get_field('assets', $product_id);
        $api_connection= get_field('api_connection', $product_id);
        $fragment= get_field('fragments', $product_id);
        $neo_builder= get_field('neo_builder', $product_id);
        $neo_writter= get_field('neo_writer', $product_id);
    }
    if ($user_role == 'Freelancer') {
        $assets = 0;
        $api_connection= 0;
        $fragment= 0;
        $neo_builder="disable";
        $neo_writter="disable";
    }
    if ($user_role == 'Agency') {
        $assets = 0;
        $api_connection= 0;
        $fragment= 0;
        $neo_builder="disable";
        $neo_writter="disable";
    }
    if ($user_role == 'Team') {
        $assets = 0;
        $api_connection= 0;
        $fragment= 0;
        $neo_builder="disable";
        $neo_writter="disable";
    }

    $cloud_limit=array(
        "assets" => $assets,
        "api_limit"=> $api_connection,
        "fragment" => $fragment,
        "neo_builder"=> $neo_builder,
        "neo_writter"=> $neo_writter
    );
    return $cloud_limit;
    
}

add_action('get_current_user_limits', 'get_current_user_limits');



add_filter('template_include', 'wpse50201_set_template');

function wpse50201_set_template($template) {
    global $wp_query;
    if (isset($wp_query->post->ID)) {
        $pageid = $wp_query->post->ID;
    } 

    if (is_tax('project_categories')){
        $template = builder_path . 'templates/taxonomy-project_categories.php';
    } else if (is_page('964')) {
        $template = builder_path . 'templates/custom_checkout.php';
    } else if (is_page('965')){
         if (is_user_logged_in()) {
             $template = builder_path . 'templates/custom_my-account.php';
        } else {
            wp_redirect(get_site_url().'/login');
            exit;
        }
    } else if (is_page('963')){
        $template = builder_path . 'templates/custom_cart.php';
    } else if (is_page() && in_array($pageid, array('76654','76650','76651'))){
        if (is_user_logged_in()) {
            $template = builder_path . 'templates/custom_vdashboad.php';
        } else{
            wp_redirect(get_site_url().'/login');
            exit;
        }
    }
    return $template;
}


function wpdb_cat_list() {
    $current_user = wp_get_current_user();
    $current_user_id = $current_user->ID;
    $builder_projects = get_terms(array(
        'taxonomy' => 'project_category',
        'exclude'  => array(176, 502, 1062, 1063),
        'hide_empty' => false,
    ));
    $project_category = array();
    if (!empty($builder_projects)) {
        foreach ($builder_projects as $builder_cats):
            $builder_custom_cat_user = get_term_meta($builder_cats->term_id, 'builder_custom_cat_user', true);
            if ($builder_custom_cat_user == $current_user_id || $builder_custom_cat_user == "") {
                $project_category[$builder_cats->term_id] = $builder_cats->name;
            }
        endforeach;
    }

    return json_encode($project_category);
}


function wpdb_layout_cat_list() {
    $current_user = wp_get_current_user();
    $current_user_id = $current_user->ID;
    $builder_projects = get_terms(array(
        'taxonomy' => 'bloxx_categories',
        'hide_empty' => false,
    ));
    $project_category = array();
    if (!empty($builder_projects)) {
        foreach ($builder_projects as $builder_cats):
            $builder_custom_cat_user = get_term_meta($builder_cats->term_id, 'builder_custom_cat_user', true);
            if ($builder_custom_cat_user == $current_user_id || $builder_custom_cat_user == "") {
                $project_category[$builder_cats->term_id] = $builder_cats->name;
            }
        endforeach;
    }

    return json_encode($project_category);
}


function layout_ind_cat_list() {
    $current_user = wp_get_current_user();
    $current_user_id = $current_user->ID;
    $builder_projects = get_terms(array(
        'taxonomy' => 'service_type',
        'hide_empty' => false,
    ));
    $project_category = array();
    if (!empty($builder_projects)) {
        foreach ($builder_projects as $builder_cats):
            $builder_custom_cat_user = get_term_meta($builder_cats->term_id, 'builder_custom_cat_user', true);
            if ($builder_custom_cat_user == $current_user_id || $builder_custom_cat_user == "") {
                $project_category[$builder_cats->term_id] = $builder_cats->name;
            }
        endforeach;
    }

    return json_encode($project_category);
}


add_action('wp_footer', 'add_ajaxex_in_footer');

function add_ajaxex_in_footer() {
    echo "<script>var cat_list=" . json_encode(wpdb_cat_list(), JSON_PRETTY_PRINT) . ";";
    echo "</script>";

    echo "<script>var layout_list=" . json_encode(wpdb_layout_cat_list(), JSON_PRETTY_PRINT) . ";";
    echo "</script>";

    echo "<script>var industry_list=" . json_encode(layout_ind_cat_list(), JSON_PRETTY_PRINT) . ";";
    echo "</script>";
}



require_once 'templates/builder_dashboard.php';
require_once 'templates/subscription_plan.php';
require_once 'templates/builder_profile.php';
require_once 'templates/builder_apihandle.php';
require_once 'templates/builder_library.php';
require_once 'templates/builder_category.php';
require_once 'templates/active_plan.php';
require_once 'templates/subscription_invoice.php';
require_once 'templates/apikeys.php';