<?php

class Bloxx_dashboard_api {

    public function __construct() {
        //Enable/Disable Page meta ready for bloxx builder
        add_action("wp_ajax_bloxx_update_metabox", array($this, "bloxx_update_metabox"));
        add_action("wp_ajax_nopriv_bloxx_update_metabox", array($this, "bloxx_update_metabox"));


        //Swich Page Meta for enable bloxx builder to next page
        add_action("wp_ajax_bloxx_switch_metabox", array($this, "bloxx_switch_metabox"));
        add_action("wp_ajax_nopriv_bloxx_switch_metabox", array($this, "bloxx_switch_metabox"));
        
        
        add_action("wp_ajax_saveproject", array($this, "saveproject"));
        add_action("wp_ajax_nopriv_saveproject", array($this, "saveproject"));
        
        
        add_action("wp_ajax_et_builder_load_css", array($this, "et_builder_load_css"));
        add_action("wp_ajax_nopriv_et_builder_load_css", array($this, "et_builder_load_css"));
        
        add_action("wp_ajax_headfooter_assign", array($this, "headfooter_assign"));
        add_action("wp_ajax_nopriv_headfooter_assign", array($this, "headfooter_assign"));



        add_action("wp_ajax_bloxx_createpage", array($this, "bloxx_createpage"));
        add_action("wp_ajax_nopriv_bloxx_createpage", array($this, "bloxx_createpage"));
        
        

        //Send API when page is published
       // add_action('transition_post_status', array($this, 'send_notification'), 10, 3); 
    }



    public function bloxx_createpage(){
        extract($_REQUEST);
        $user_id = get_current_user_id();
        $create_page = array(
            'post_content' => "",
            'post_title' => $pnm,
            'post_status' => 'publish',
            'post_author' => $user_id,
            'post_type' => 'page'
        );

        $pid = wp_insert_post($create_page);
        update_post_meta($pid, '_et_pb_page_layout', 'et_no_sidebar');
        update_post_meta($pid, '_et_pb_use_builder', 'on');

        $page_permalink=get_the_permalink($pid);

        $enable_bloxx=$page_permalink."?bloxx_builder=enable";
        $result = array(
            "code" => 200,
            "message" => "$pnm Page published successfully",
            'page_link' => $enable_bloxx
        );
        echo json_encode($result);
        die();
    }

    public function send_notification($new_status, $old_status, $post ){
        if ( $new_status == 'publish' && $old_status != 'publish' ) {
            $builder_connect="no";
            if(get_option('bloxxbuilder_connect')!=""){
                $builder_connect = get_option('bloxxbuilder_connect');
            }

            if ($builder_connect == "yes") {
                $server_id=$post->ID;
                $server_title=$post->post_title;
                $server_content=$post->post_content;
                $bloxx_termid= get_option('bloxx_term_id');
                $bloxx_userid= get_option('bloxx_user_id');

                $curl_url = "https://app.gobloxx.io/wp-json/bloxx-page/insert";                
                $builder_page_array = array(
                    'server_page_id' => $server_id,
                    'server_title'  => $server_title,
                    'project_content' => $server_content,
                    'bloxx_term'    => $bloxx_termid,
                    'bloxx_user'    => $bloxx_userid
                );

                $bloxx_page_json = json_encode($builder_page_array);
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $curl_url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_SSL_VERIFYPEER => 0,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $bloxx_page_json,
                    CURLOPT_HTTPHEADER => array(
                        "cache-control: no-cache",
                        "content-type: application/json"
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
            }
        }
    }


    public function bloxx_switch_metabox() {
        extract($_REQUEST);
        update_post_meta($post_id, '_et_pb_page_layout', 'et_no_sidebar');
        update_post_meta($post_id, '_et_pb_use_builder', 'on');
        $user_id = get_current_user_id();
        //update_user_meta($user_id, 'show_admin_bar_front', 'false');

        if ($old_page != "" && $post_id !="") {
            //Disable Builder for old page 
            update_post_meta($old_page, 'bloxx_builder', 'disable');
            update_post_meta($old_page, '_wp_page_template', 'default');
            
            
            //Enable Builder for new page
            update_post_meta($post_id, 'bloxx_builder', 'enable');
            //update_post_meta($post_id, '_wp_page_template', 'bloxx_call_template.php');
            
            
            $result = array(
                'code' => 200,
                'message' => "Bloxx builder switched successfully"
            );
        } else {
            $result = array(
                'code' => 202,
                'message' => "Failed to switch bloxx builder"
            );
        }        
        echo json_encode($result);
        die();
    }
    
    

    public function bloxx_update_metabox() {
        extract($_REQUEST);
        update_post_meta($post_id, '_et_pb_page_layout', 'et_no_sidebar');
        update_post_meta($post_id, '_et_pb_use_builder', 'on');
        $user_id = get_current_user_id();
        $admin_bar_front = get_user_meta($user_id, 'show_admin_bar_front', true);

        if ($meta_type == "enable") {
            update_post_meta($post_id, 'bloxx_builder', 'enable');
            //update_post_meta($post_id, '_wp_page_template', 'bloxx_call_template.php');

            //update_user_meta($user_id, 'show_admin_bar_front', 'false');
            

            $result = array(
                'code' => 200,
                'message' => "Bloxx builder ready to launch"
            );
        } else if ($meta_type == "disable") {
            
            //update_user_meta($user_id, 'show_admin_bar_front', 'true');

            update_post_meta($post_id, 'bloxx_builder', 'disable');
            update_post_meta($post_id, '_wp_page_template', 'default');
            $result = array(
                'code' => 200,
                'message' => "Bloxx builder exit successfully"
            );
        } else {
            $result = array(
                'code' => 202,
                'message' => "Failed to load bloxx builder"
            );
        }
        echo json_encode($result);
        die();
    }
    
    
    
    
    //Save Page Code Here
    public function saveproject() {
        global $wpdb;
        if (isset($_POST['json_content']) && !empty($_POST['json_content'])) {
            $project_nm = $_REQUEST['builder_prj_title'];
            $project_id = $_REQUEST['builder_prj_id'];
            $project_title= get_the_title($project_id);
            
            $rm_cache= WP_CONTENT_DIR."/et-cache/$project_id";
            exec("rm -rf $rm_cache");
            
            $action_to_perform = $_REQUEST['action_to_perform'];
            $json_content = $_POST['json_content'];
            $ajax_content = "";
            foreach ($json_content as $drop_content):
                $ajax_content .= $drop_content;                
            endforeach;

            $remove_farward_slash = str_replace('\\', '', $ajax_content);
            
            
            $my_post = array(
                'ID' => $project_id,
                'post_content' => $remove_farward_slash,
            );
            wp_update_post($my_post);
            
            update_post_meta($project_id, 'page_referesh', 'yes');
            
            $result = array(
                'code' => 200,
                'project_id' => $pid,
                'message' => "$project_title page updated successfully"
            );
            
        } else {
            $result = array(
                'code' => 202,
                'message' => 'Please select layout before create save project'
            );
        }

        echo json_encode($result);
        die();
    }
    
    
    
    public function et_builder_load_css() {
        extract($_REQUEST);
        $time = time();

        $link_url = get_the_permalink($page_id);

        $shot_nm = "project_$time.png";   //Demo Variable
        $version = $link_url . "?ver=" . $time;

        //$scriptpath = "node " . siteblox_path . "/runpage_nodescript.js {$version} {$shot_nm}";

        //exec($scriptpath, $output);
        //$myJSON = $output;
        //$node_result = implode($myJSON);

        if ($version != "") {
            //$homepage = file_get_contents($cache_css);
            $page_html = file_get_contents($version);
            $resp = array(
                "page_html" => $page_html,
                "code" => 200,
                "message" => "Page css loaded successfully"
            );
        } else {
            $resp = array(
                "code" => 202,
                "message" => "Failed to load page css"
            );
        }

        echo json_encode($resp);
        die();
    }
    
    
    public function headfooter_assign(){
        extract($_REQUEST);
        global $wpdb;   
        $user_id = get_current_user_id();

        $page_content = str_replace('\\', '', $page_content);
        
        $wp_posts = $wpdb->prefix . 'posts';
        $pages_query = "SELECT ID FROM $wp_posts where post_type='page' and post_status='publish'";
        $pages_result= $wpdb->get_results($pages_query);

        foreach($pages_result as $allpages):
            $page_ids=$allpages->ID;
            update_post_meta($page_ids, 'page_referesh', 'yes');
        endforeach;
        
        
        
        if ($assign_type == "assign_header") {
            $post_type = 'et_header_layout';
            $meta_name = '_et_header_layout_id';
            $meta_enable = '_et_header_layout_enabled';
            $page_name= "header_assign";
            //$msg = "$page_name header";
            $msg = "Header";
            $guid = site_url() . "/?post_type=et_header_layout&p=";
        } else {
            $post_type = 'et_footer_layout';
            $meta_name = '_et_footer_layout_id';
            $page_name= "footer_assign";
            //$msg = "$page_name footer";
            $msg = "Footer";
            $meta_enable = '_et_footer_layout_enabled';
            $guid = site_url() . "/?post_type=et_footer_layout&p=";
        }
        
        $theme_builder_query = $wpdb->get_row("SELECT post_name, ID FROM {$wpdb->prefix}posts WHERE post_name = 'theme-builder'", 'ARRAY_A');
        if (null === $theme_builder_query) {
            $create_post = array(
                'post_content' => '',
                'post_title' => 'Theme Builder',
                'post_status' => 'publish',
                'post_author' => $user_id,
                'post_type' => 'et_theme_builder'
            );
            $theme_builder_id = wp_insert_post($create_post);
        } else {
            $theme_builder_id = $theme_builder_query['ID'];
        }
        
        
        
        $default_template_query = $wpdb->get_row("SELECT post_name, ID FROM {$wpdb->prefix}posts WHERE post_name = 'default-website-template'", 'ARRAY_A');

        if (null === $default_template_query) {
            $create_post = array(
                'post_content' => '',
                'post_title' => 'Default Website Template',
                'post_status' => 'publish',
                'post_author' => $user_id,
                'post_type' => 'et_template'
            );
            $default_template_id = wp_insert_post($create_post);
        } else {
            $default_template_id = $default_template_query['ID'];
        }
        
        
        
        update_post_meta($theme_builder_id, '_et_template', $default_template_id);
        update_post_meta($default_template_id, '_et_default', 1);
        update_post_meta($default_template_id, $meta_enable, 1);
        update_post_meta($default_template_id, '_et_enabled', 1);
        update_post_meta($default_template_id, '_et_body_layout_enabled', 1);
        
        
        $main_query = "SELECT post_name, ID FROM {$wpdb->prefix}posts WHERE post_type = '$post_type'";

        $tb_name = $wpdb->prefix . 'posts'; 

        $page_row = $wpdb->get_row($main_query, 'ARRAY_A');
        if (null === $page_row) {            
            $create_post = array(                
                'post_title' => $page_name,
                'post_content' => $page_content,
                'post_status' => 'publish',
                'post_author' => $user_id,
                'post_type' => $post_type
            );

            $wpdb->insert($tb_name, $create_post);
            $pid = $wpdb->insert_id;
            
            
            
            //$pid = wp_insert_post($create_post);

            $update_page = array(
                'ID' => $pid,
                'guid' => $guid . $pid
            );
            wp_update_post($update_page);

            update_post_meta($default_template_id, $meta_name, $pid);

            update_post_meta($pid, '_et_pb_use_builder', 'on');
            update_post_meta($pid, '_et_pb_show_page_creation', 'on');
            update_post_meta($pid, '_et_pb_built_for_post_type', 'on');
            
            $result = array(
                "code" => 200,
                "message" => "$msg set globally for all pages"
            );
        } else {
            $page_id = $page_row['ID'];            

            //Delete Before Insert
            $post_name=$page_id."-revision-v1";
            $wpdb->delete( $tb_name, array( 'id' => $page_id ) );
            $wpdb->delete( $tb_name, array( 'post_name' => $post_name ) );  //Also Delete revision


            $create_post = array(                
                'post_title' => $page_name,
                'post_content' => $page_content,
                'post_status' => 'publish',
                'post_author' => $user_id,
                'post_type' => $post_type
            );

            $wpdb->insert($tb_name, $create_post);
            $pid = $wpdb->insert_id;
            
            
            
            //$pid = wp_insert_post($create_post);

            $update_page = array(
                'ID' => $pid,
                'guid' => $guid . $pid
            );
            wp_update_post($update_page);

            update_post_meta($default_template_id, $meta_name, $pid);

            update_post_meta($pid, '_et_pb_use_builder', 'on');
            update_post_meta($pid, '_et_pb_show_page_creation', 'on');
            update_post_meta($pid, '_et_pb_built_for_post_type', 'on');           
            

            
            $result = array(
                "code" => 200,
                "message" => "$msg updated globally for all pages"
            );
        }
        echo json_encode($result);
        die();
    }

}

$bloxx_dashboard = new Bloxx_dashboard_api();
