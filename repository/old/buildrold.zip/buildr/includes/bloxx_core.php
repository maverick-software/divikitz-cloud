<?php

class Bloxx_core {

    public function __construct() {
        add_action('admin_menu', array($this, 'builder_menu'));

        add_action('admin_bar_menu', array($this, 'enable_bloxx_builder'), 9999);

        add_action('wp_enqueue_scripts', array($this, 'plugin_css_jsscripts'));

        //add_action('admin_enqueue_scripts', array($this, 'plugin_css_jsscripts'));

        add_action('admin_enqueue_scripts', array($this, 'admin_css_jsscripts'));

        add_action('admin_notices', array($this, 'check_divi_theme'));
        add_action('admin_notices', array($this, 'check_bloxxkey'),10);

        //CSS for Admin Bar
        add_action('admin_head', array($this, 'adminbar_bloxxbuilder_css'));
        add_action('wp_head', array($this, 'adminbar_bloxxbuilder_css'));

        //add_action('wp_head', array($this, 'load_template'));

        add_filter('template_include', array($this, 'load_template'));

        add_action('wp_head', array($this, "reload_cssjs"));

        //Admin check API
        add_action("wp_ajax_siteblox_key_saved", array($this, "siteblox_key_saved"));
        add_action("wp_ajax_nopriv_siteblox_key_saved", array($this, "siteblox_key_saved"));

        //Admin check API for Non Bloxx User
       // add_action("wp_ajax_siteblox_key_saved_simple", array($this, "siteblox_key_saved_simple"));
       // add_action("wp_ajax_nopriv_siteblox_key_saved_simple", array($this, "siteblox_key_saved_simple"));


        add_action( 'init', array($this, "is_bloxxpage_open"));  
        
        add_action('init', array($this, 'autologin'));
    }
    
    
    function autologin(){
        if(isset($_REQUEST['bloxx_auth_token'])){
            global $wpdb;
            //if ( !is_user_logged_in()){ 
                $auth_email= base64_decode($_REQUEST['bloxx_auth_token']);
                $user_details= get_user_by("email", $auth_email);
                $get_user=$user_details->data;
                $userid= $get_user->ID;
                $user_email= $get_user->user_email;
                $user_pass= $get_user->user_pass;
                $conn_site = $wpdb->prefix.'users';
                $login_query= "select * from $conn_site where user_login='$user_email' and user_pass='$user_pass'";

                $my_query= $wpdb->get_results($login_query);

                $count_data=  count( $my_query );
                if($count_data!=0){

                    wp_set_current_user($userid); // set the current wp user
                    wp_set_auth_cookie($userid);
                    wp_redirect( admin_url() );
                }
            // }else{
            //     echo "string";die;
            // }
        }
    }



    function is_bloxxpage_open() {
        $user_id = get_current_user_id();
        if(isset($_REQUEST['bloxx_builder'])){
            update_user_meta($user_id, 'show_admin_bar_front', 'false');
        } else {
            update_user_meta($user_id, 'show_admin_bar_front', 'true');
        }
    }

    public function builder_menu() {
        add_menu_page('Bloxx', 'Bloxx', 'manage_options', 'bloxx-connect', array($this, 'bloxx_connect'), plugins_url( 'buildr/images/dashboard_icon.png' ));


        
        if ( is_plugin_active( 'wp-writr/admin-page.php' ) ) {
           // add_submenu_page('bloxx-connect','Bloxx Buildr', 'Bloxx Buildr','manage_options','bloxx_buildr_page', array($this,'bloxx_buildr_page_callback'));
            //add_submenu_page('bloxx-connect','Writr Sidebar', 'Writr Sidebar','manage_options','custompage','my_custom_menu_page', 'dashicons-welcome-widgets-menus', 120 );
        }else{

        }
        

        // add_submenu_page('bloxx-connect','Bloxx WritrAI', 'Bloxx WritrAI','manage_options','bloxx_writr_page', array($this,'bloxx_writr_page_callback'));

        //add_submenu_page('bloxx-connect','Bloxx Pixr', 'Bloxx Pixr','manage_options','bloxx_pixr_page', array($this,'bloxx_pixr_page_callback'));



    }

    public function bloxx_buildr_page_callback(){
        ?>
        <div class="wrap">
            <h1>Buildr Page</h1>
            <p>This is buildr plugin page</p>
        </div>

        <?php
    }

   
    public function bloxx_pixr_page_callback(){
        ?>
        <div class="wrap">
            <h1>Pixr Page</h1>
            <p>This is pixr plugin page</p>
        </div>

        <?php
    }


    public function bloxx_connect() {
        ob_start();
        include( bloxx_path . 'admin/templates/settings-page.php' );
        $content = ob_get_contents();
        ob_get_clean();
        echo $content;
    }

    public function reload_cssjs() {
        global $wpdb;
        global $wp_query;
        @$page_id = $wp_query->post->ID;

        //Enable Admin Bar
        $user_id = get_current_user_id();
        /*if(isset($_REQUEST['bloxx_builder'])){            
            update_user_meta($user_id, 'show_admin_bar_front', 'false');
        } else {
            update_user_meta($user_id, 'show_admin_bar_front', 'true');
        }*/

        if ($page_id != "" && is_user_logged_in()) {
            @$page_refresh = get_post_meta($page_id, 'page_referesh', true);



            if (@$page_refresh == "yes" && is_user_logged_in()) {

                $posts = $wpdb->prefix . 'posts';
                $page_query = "SELECT * FROM $posts where ID='$page_id' limit 1";
                $page_data = $wpdb->get_row($page_query);
                $page_content = $page_data->post_content;

                $update = wp_update_post(
                        array(
                            'ID' => $page_id,
                            'post_content' => $page_content,
                            'post_status' => "publish",
                        )
                );
                update_post_meta($page_id, "page_referesh", "no");
                ?>
                <script>
                    window.location.href = "";
                </script>
                <?php
            }
        }
        return true;
    }

    public function load_template($template) {
        global $wp_admin_bar, $wp_the_query;
        $post_id = get_the_ID();
        $bloxx_enable = get_post_meta($post_id, 'bloxx_builder', true);

        if (is_user_logged_in() && isset($_REQUEST['bloxx_builder'])) {
            $temp_path = bloxx_path . "bloxx_call_template.php";
            return $temp_path;
            //load_template($temp_path);
        } else {
            return $template;
        }
    }

    function enable_bloxx_builder() {
        global $wp_admin_bar, $wp_the_query;
        $post_id = get_the_ID();

        $is_divi_library = 'et_pb_layout' === get_post_type($post_id);
        $page_url = $is_divi_library ? get_edit_post_link($post_id) : get_permalink($post_id);

        if (!is_admin() && !isset($_REQUEST['et_fb'])) {
            if (isset($_REQUEST['bloxx_builder'])) {
                $wp_admin_bar->add_menu(
                        array(
                            'id' => 'exit-bloxx-builder',
                            'name' => $post_id,
                            'title' => esc_html__('Exit Bloxx Builder', 'bloxx_builder'),
                            'href' => esc_url($page_url),
                            'meta' => array(
                                'title' => $post_id
                            )
                        )
                );
            } else {
                $use_bloxx_builder_url = add_query_arg(
                        array('bloxx_builder' => "enable"), $page_url
                );
                $wp_admin_bar->add_menu(
                        array(
                            'id' => 'et-bloxx-builder',
                            'class' => $post_id,
                            'href' => esc_url($use_bloxx_builder_url),
                            'title' => esc_html__('Enable Bloxx Builder', 'bloxx_builder'),
                            'meta' => array(
                                'title' => $post_id
                            )
                        )
                );
            }
        }
        return;
    }

    function adminbar_bloxxbuilder_css() {

        if (is_admin_bar_showing() && !is_admin()) {
            ?>
            <style type="text/css">
                li#wp-admin-bar-et-bloxx-builder a, li#wp-admin-bar-exit-bloxx-builder a {
                    background: url('<?php echo bloxx_url; ?>images/logoicon.png') no-repeat left center !important;
                    background-size: 20px auto !important;
                    font-weight: 600;
                    padding: 0 12px 0 30px !important;
                    position: relative;
                }

                li#wp-admin-bar-et-bloxx-builder a:hover, li#wp-admin-bar-exit-bloxx-builder a:hover {
                    background: #231942 url('<?php echo bloxx_url; ?>images/logoicon.png') no-repeat left center !important;
                    background-size: 20px auto !important;
                    color: #fff !important;
                }
                
            </style>

            <script>
                jQuery(function ($) {
                    $("body").on("click", "li#wp-admin-bar-et-bloxx-builder a", function (event) {
                        event.preventDefault();
                        var $this = $(this);
                        var page_id = $this.attr('title');
                        var meta_type = "enable";
                        update_bloxx_metas(page_id, meta_type, $this);
                    });

                    $("body").on("click", "li#wp-admin-bar-exit-bloxx-builder a", function (event) {
                        event.preventDefault();
                        var $this = $(this);
                        var page_id = $this.attr('title');
                        var meta_type = "disable";
                        update_bloxx_metas(page_id, meta_type, $this);
                    });


                    function update_bloxx_metas(page_id, meta_type, $this) {
                        var ajax_url = '<?php echo admin_url('admin-ajax.php') ?>';
                        $.ajax({
                            type: "POST",
                            url: ajax_url,
                            dataType: "json",
                            data: {
                                'action': 'bloxx_update_metabox',
                                'post_id': page_id,
                                'meta_type': meta_type
                            },
                            beforeSend: function () {
                                $this.html('<i class="fa fa-spinner fa-spin"></i>');
                            },
                            success: function (resp) {
                                if (resp.code == 200) {
                                    window.location.href = $this.attr('href');
                                } else {
                                    alert(resp.message);
                                }
                            },
                            error: function () {
                                Swal.fire({
                                    title: "Error!",
                                    text: "Please try again later",
                                    confirmButtonColor: '#000',
                                    icon: "error"
                                });
                            }
                        });
                    }
                });
            </script>
            <?php
        }
    }

    function plugin_css_jsscripts() {
        global $wp_query;
        @$page_id = $wp_query->post->ID;

        wp_dequeue_script('utils');
        wp_dequeue_script('moxiejs');
        //Datatable
        //jQuery UI 1.11.4
        wp_enqueue_script('jquery-ui', bloxx_url . "jquery-ui/jquery-ui.min.js", array('jquery'), '', true);

        //jQuery UI Touch Punch 1.11.4
        wp_enqueue_script('jquery-uitouchpunch', bloxx_url . "jquery-ui/jquery.ui.touch-punch.min.js", array('jquery'), '', true);


        //Sweet Alret
        wp_enqueue_script('sweer-alert', bloxx_url . "js/sweetalert.min.js", array('jquery'), '', true);

        //Font Awesome
        wp_enqueue_style('font-awesome', bloxx_url . "css/font-awesome.min.css");


        //Font Awesome
        wp_enqueue_style('all-awesome', bloxx_url . "css/all.css");

        //Style css
        wp_enqueue_style('style-css', bloxx_url . "css/style.css?v=" . time());



        

        // Pass ajax_url to script.js
        if (!isset($_GET['et_fb'])) {
            // JavaScript
             wp_enqueue_script('builderjs', bloxx_url . 'js/script.js?v=' . time(), array('jquery'), '', true);
             
            $ajax_data=$this->basicApiext();

           // pre($ajax_data);
            
            wp_localize_script('builderjs', 'bloxx', array('ajax_url' => admin_url('admin-ajax.php')));
            wp_localize_script('builderjs', 'bloxxapi', $ajax_data);

            
        }
    }

    function admin_css_jsscripts() {
        wp_enqueue_style('bloxxbuilder-font-awesome', bloxx_url . "css/font-awesome.min.css");
        wp_enqueue_style('bloxxbuilder-css', bloxx_url . 'admin/assets/css/bloxx_admin.css?v=' . time());

        //Sweet Alret
        wp_enqueue_script('bloxxbuilder-sweer-alert', bloxx_url . "js/sweetalert.min.js");

        //script.js
        wp_enqueue_script('bloxxbuilder-siteblox-script', bloxx_url . 'admin/assets/js/bloxxscript.js?v=' . time());


        // Pass ajax_url to script.js
        if (!isset($_GET['et_fb'])) {
            $ajax_data=$this->basicApiext();
            
            wp_localize_script('bloxxbuilder-siteblox-script', 'bloxx', array('ajax_url' => admin_url('admin-ajax.php')));
            wp_localize_script('bloxxbuilder-siteblox-script', 'bloxxbuilder_admin', array('ajax_url' => admin_url('admin-ajax.php')));
            wp_localize_script('bloxxbuilder-siteblox-script', 'bloxxapi', $ajax_data);
        }
    }

    
	
	


    function basicApiext(){
        include_once(ABSPATH.'wp-admin/includes/plugin.php');
        $builderapi_url = get_option('bloxx_api_url', true);
        $builderapi_url_layouts = get_option('bloxx_api_url_layouts', true);
        


        $theme = wp_get_theme();
        $er = 0;
        $divi_type="activate";
        if ('Divi' == $theme->name) {               
            $er = 1;
            $divi_type="theme_activated";
        } else if ('Divi Child Theme' == $theme->name) {
            $divi_type="theme_activated";
            $er = 1;        
        } else if (is_plugin_active( 'divi-builder/divi-builder.php' ) ) {
            $divi_type="plugin_activated";
            $er = 1;        
        }

        $ajax_data=array();
        
        if($er==0){
            $ajax_data= array(
                'builder_key' => "activate",
                'api_token' => "activate",
                'ajax_url' => "activate",
                'key_url'=> $builderapi_url,
                'key_url_layouts' => $builderapi_url_layouts,
                'imageurl'=> bloxx_url,
                'enable'=> $divi_type,
                'siteurl'=>site_url()
            );
        } else {
            $builder_connect="no";
            if(get_option('bloxxbuilder_connect')!=""){
                $builder_connect = get_option('bloxxbuilder_connect', true);
            }

            //if ($builder_connect == "yes") {
                $builder_key=get_option('builder_key', true);
                $api_token=get_option('bloxx_api_token', true);
                $ajax_data= array(
                    'ajax_url_layouts' => $builderapi_url_layouts,
                    'ajax_url' => $builderapi_url,
                    'builder_key' => $builder_key,
                    'api_token' => $api_token,
                    'key_url'=> $builderapi_url,
                    'key_url_layouts' => $builderapi_url_layouts,
                    'imageurl'=> bloxx_url,
                    'enable'=> $divi_type,
                    'siteurl'=>site_url()
                );
            /*
            } else {
                $ajax_data= array(
                    'builder_key' => "disconnect",
                    'api_token' => "disconnect",
                    'ajax_url' => "disconnect",
                    'key_url'=> $builderapi_url,
                    'key_url_layouts' => $builderapi_url_layouts,
                    'imageurl'=> bloxx_url,
                    'enable'=> $divi_type,
                    'siteurl'=>site_url()
                );
            }
            */
        }
        return $ajax_data;
    }

    function check_divi_theme() {
        $theme = wp_get_theme();
        $er = 0;
        if ('Divi' == $theme->name) {
            $er = 0;
        } else if ('Divi Child Theme' == $theme->name) {
            $er = 0;            
        } else if ( is_plugin_active( 'divi-builder/divi-builder.php' ) ) {
            $er = 0;            
        } else {
            $er = 1;
        }

        if ($er == 1) {
            $error_message = "Please activate Divi theme or Divi Builder plugin for continue...  Bloxx Plugin";
            $this->error_message($error_message);
        }
    }

    function check_bloxxkey(){
        $builder_key=get_option('builder_key');
        if(empty($builder_key) || $builder_key === false){
            $error_message = "Please enter API key before using the bloxx builder";
            $this->error_message($error_message);
        }
    }

    function error_message($error_message) {
        ?>
        <div class="updated error divi_builder">
            <p><?php esc_html_e($error_message); ?></p>
        </div>

        <?php
    }
    
    
    

    
    //Check API Connection
    public function siteblox_key_saved() {
        
        extract($_REQUEST);
        $current_user = wp_get_current_user();
        $current_user_id = $current_user->ID;
        update_option('siteblox_key', $siteblox_key);
        $website_nm=get_option('blogname', true);
        $connect_data = array(
            'website_url' => $website_url,
            'server_userid' => $current_user_id,
            'siteblox_username' => trim($siteblox_username),
            'siteblox_key' => $siteblox_key,
            'website_nm' => $website_nm
        );

       // pre($connect_data);
       // die('stop client');
        $siteblox_json = json_encode($connect_data);

        if ($siteblox_status == "siteblox_connect") {
            $connect_url=bloxx_apiurl."wp-json/siteblox-api/connect";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $connect_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $siteblox_json,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                $result = array(
                    'code' => 202,
                    'message' => $err
                );
            } else {

                $siteblox_resp = json_decode($response, true);
                //  pre($siteblox_resp);
                // die('stop123');
                if ($siteblox_resp['code'] == 200) {
                    update_option('bloxx_api_url', $siteblox_resp['section_api']);
                    update_option('bloxx_api_url_layouts', $siteblox_resp['layout_api']);
                    update_option('bloxx_api_token', $siteblox_resp['api_token']);
                    update_option('builder_username', $siteblox_username);
                    update_option('builder_key', $siteblox_key);
                    update_option('bloxx_user_id', $siteblox_resp['user_id']);
                    update_option('bloxx_term_id', $siteblox_resp['term_id']);
                    update_option('bloxxbuilder_connect', 'yes');
                    update_option('bloxx_use_free_features', $response['bloxx_use_free_features']);
                }
                echo $response;
            }
        } else {
            $disconnect_url=bloxx_apiurl."wp-json/siteblox-api/disconnect";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $disconnect_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $siteblox_json,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                $result = array(
                    'code' => 202,
                    'message' => $err
                );
            } else {
                $siteblox_resp = json_decode($response, true);
                if ($siteblox_resp['code'] == 200) {
                    update_option('bloxx_use_free_features', $response['bloxx_use_free_features']);
                    update_option('bloxxbuilder_connect', 'no');
                    update_option('bloxx_api_url', "disconnect");
                    update_option('bloxx_api_url_layouts', "disconnect");
                    update_option('bloxx_api_token', "disconnect");
                    update_option('builder_username', '');
                    update_option('builder_key', '');
                }
                echo $response;
            }
        }
        die();
    }

}

$bloxx_core = new Bloxx_core();