<?php
$builder_connect="no";
if(get_option('bloxxbuilder_connect')!=""){
    $builder_connect = get_option('bloxxbuilder_connect');
}

$siteblox_username = get_option('builder_username');
$builder_key = get_option('builder_key');


$bloxx_term_id = get_option('bloxx_term_id');

?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap-grid.min.css" integrity="sha512-q0LpKnEKG/pAf1qi1SAyX0lCNnrlJDjAvsyaygu07x8OF4CEOpQhBnYiFW6YDUnOOcyAEiEYlV4S9vEc6akTEw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<div id="maincontent" class="main-content">
	<div class="page-content">
		<div class="container-fluid">
			
			<?php 
			//if($bloxx_term_id){
				?>
				<div class="row">
						<div class="col-12">
							<div class="main-title">
								<h1>Welcome to Bloxx! </h1>
								<p>If you have a premium plan then you can connect your account below here, if you do not have you can get one <a href="https://app.divibloxx.com/plans/">here</a>. Other wise you can enjoy our free services.</p>
							</div>
						</div>
					</div>


					<div class="row">
						<div class="col-sm-6 col-md-6 col-lg-3 col-3">
							<div class="bloxx_box">
								<div class="blx_logo">
									<img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/bloxx-logo-black.png" style="max-width: 175px;" />
									<h3>Access Premium Features</h3>
									<p>Each of our plugins makes the Divi experience better and faster for developers.</p>

									<form method="POST" id="siteblox_connectivity">
									    <section class="object-meta-data taxonomy-meta-data">
									        <table class="widefat fixed siteblox-table" cellspacing="0">
									            <tbody>
									               
									                <tr class="alternate">
									                    <td>
									                        <input name="website_url" type="hidden" value="<?php echo site_url(); ?>">
									                        <input name="siteblox_username" type="text"  id="siteblox_username" value="<?php
									                        if (isset($siteblox_username)) {
									                            echo $siteblox_username;
									                        }
									                        ?>" placeholder="Enter API Username">
									                        <input name="siteblox_key" id="siteblox_key" type="text" value="<?php
									                        if (isset($builder_key)) {
									                            echo $builder_key;
									                        }
									                        ?>" placeholder="Enter API Key" required>
									                        <input type="hidden" name="action" value="siteblox_key_saved">
									                    </td>
									                </tr>
									            </tbody>
									        </table>
									    </section>

									    <div class="submit-buttons">

									        <?php if ($builder_connect == "yes" &&  isset($siteblox_username) && $siteblox_username!='') { ?>
									            <input type="hidden"  id="siteblox_status" name="siteblox_status" value="siteblox_disconnect">
									            <button type="submit" id="save_connectivity" class="button button-danger">Disconnect</button>
									        <?php } else { ?>
									            <input type="hidden" id="siteblox_status" name="siteblox_status" value="siteblox_connect">
									            <button type="submit" id="save_connectivity" class="button button-pro">Connect</button>
									<?php } ?>
									    </div>
									</form>

									

								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-6 col-lg-3 col-3">
							<div class="bloxx_box">
								<div class="blx_logo">
									<div class="blx-top">
										<img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/bloxx-buildr.png" />
										<h2>Buildr.</h2>
									</div>

									<p>Buildr allows you access a vast library of premade sections inside our proprietary drop-in builder for Divi.</p>
									<?php 

										if ( is_plugin_active( 'buildr/bloxx_builder.php' ) ) {
										    echo '<a href="javascript:void(0);" class="btn btn-primary btn-lg btn-block">Installed</a>';
										}  else{
											echo '<a href="https://app.divibloxx.com/wp-content/uploads/2022/01/buildr.zip" class="btn btn-primary btn-lg btn-block">Download</a>';
										}
									?>
									
									<!-- <a href="#" class="btn btn-trans btn-block">View Demo</a> -->

								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-6 col-lg-3 col-3">
							<div class="bloxx_box">
								<div class="blx_logo">
									<div class="blx-top">
										<img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/bloxx-writr.png" />
										<h2>WritrAl.</h2>
									</div>
									<p>Writr wields the power of AI to bring you fast, quality copy for your web design project.</p>
									<?php 
										
										if ( is_plugin_active( 'wp-writr/Writr.php' ) ) {
										    echo '<a href="javascript:void(0);" class="btn btn-primary btn-lg btn-block">Installed</a>';
										}  else{
											echo '<a href="#" class="btn btn-primary btn-lg btn-block">Download</a>';
										}
									?>
									<!-- <a href="#" class="btn btn-trans btn-block">View Demo</a> -->

								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-6 col-lg-3 col-3">
							<div class="bloxx_box">
								<div class="blx_logo">
									<div class="blx-top">
										<img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/bloxx-pixr.png" />
										<h2>Pixr.</h2>
									</div>
									<p>Pixr brings free stock photos access directly into your site with our awesome cropping tool.</p>
									<?php 
										
										if ( is_plugin_active( 'pixr/free_stock_images.php' ) ) {
										    echo '<a href="javascript:void(0);" class="btn btn-primary btn-lg btn-block">Installed</a>';
										}  else{
											echo '<a href="https://app.divibloxx.com/wp-content/uploads/2022/01/pixr.zip" class="btn btn-primary btn-lg btn-block">Download</a>';
										}
									?>
									<!-- <a href="#" class="btn btn-trans btn-block">View Demo</a> -->

								</div>
							</div>
						</div>
					</div>


					<div class="height40px"></div>
					
				<?php
			//} ?>
					

		</div>
	</div>
</div>