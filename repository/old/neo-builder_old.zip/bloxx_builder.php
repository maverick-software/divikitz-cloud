<?php
 /*
 * Plugin name: Neo's Builder
 * Description: Neo's Builder helps you build Divi sites ten times faster with cloud storage and drop-in features.
 * Version: 5.10.23
 * Author: Enspyre Digital LLC
 * Author URI: https://enspyredigital.com
 * License: GPL v2
 */

/**/




define('bloxx_url', plugin_dir_url(__FILE__));
define('bloxx_path', plugin_dir_path(__FILE__));
define('bloxx_plugin', plugin_basename(__FILE__));
define('bloxx_apiurl', "https://cloud.neosbuilder.com/");


define('CURRENT_SITEURL', get_site_url());
define('BUILDR_PLUGIN_SLUG','buildr');
define('UPDATE_PLUGIN_URL','https://cloud.neosbuilder.com/repository/');
define('code_updated','yes');


require_once 'includes/bloxx_core.php';
require_once 'bloxxtemplater.php';
require_once 'templates/bloxx_dashboard_api.php';
require_once 'templates/builderapi.php';
//require_once 'update_checker.php';

// add_action('init','plugin_act');
// function plugin_act(){


// send data to bloxx that plugin is activated
register_activation_hook(__FILE__, 'bloxx_buildr_plugin_activated'); 
    
register_deactivation_hook( __FILE__, 'bloxx_buildr_plugin_deactivated' );

//}

function bloxx_buildr_plugin_activated() {
   

    update_option('bloxxbuilder_use_free_features', 1);
	$bloxx_buildr_plugin_activated = get_option('bloxx_buildr_plugin_activated');
//echo $bloxx_buildr_plugin_activated;
	if($bloxx_buildr_plugin_activated==1){

	}else{


	    update_option('bloxx_buildr_plugin_activated', 1);
        
	    update_option('bloxx_api_url', bloxx_apiurl.'retrieve-section-sidebar-api/');
	    update_option('bloxx_api_url_layouts', bloxx_apiurl.'retrieve-layout-sidebar-api/');
	   

	    // insert user with free plan 
	    $admin_email = get_option( 'admin_email' );
	    $site_name = get_option( 'blogname' );
	    $curl_url = bloxx_apiurl."wp-json/siteblox-api/insert_nonbloxxuser/";                
	    $builder_page_array_user = array(
	        'user_email' => $admin_email,
	        'site_url' => CURRENT_SITEURL,
	        'site_name' => $site_name
	    );


	    $bloxx_page_json_user = json_encode($builder_page_array_user);
	    $curl = curl_init();
	    curl_setopt_array($curl, array(
	        CURLOPT_URL => $curl_url,
	        CURLOPT_RETURNTRANSFER => true,
	        CURLOPT_ENCODING => "",
	        CURLOPT_MAXREDIRS => 10,
	        CURLOPT_TIMEOUT => 60,
	        CURLOPT_SSL_VERIFYPEER => 0,
	        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	        CURLOPT_CUSTOMREQUEST => "POST",
	        CURLOPT_POSTFIELDS => $bloxx_page_json_user,
	        CURLOPT_HTTPHEADER => array(
	            "cache-control: no-cache",
	            "content-type: application/json"
	        ),
	    ));

	    $response = curl_exec($curl);
	    $err = curl_error($curl);
	    curl_close($curl);


	   // pre($response);


	    $resp = json_decode($response);
	    //pre( $resp);


	    update_option('response_json',$response);
	    update_option('response_json_decode',$resp);
	    $current_user_id = get_current_user_id();
	   // echo 'current_user_id'.$current_user_id;
	    if($resp->code==200){
	    	// update_option('siteblox_key', $resp->siteblox_key);
	    	// update_option('builder_key', $resp->builder_key);
	    	// update_option('bloxx_api_token', $resp->bloxx_api_token);
	    	// update_option('bloxx_user_id', $resp->bloxx_user_id);
	    	// update_option('bloxx_term_id', $resp->bloxx_term_id);
	    	// update_option('bloxxbuilder_connect', $resp->bloxxbuilder_connect);
	    	
	    }else if($resp->code==201){
	        update_option('bloxxbuilder_connect', $resp->bloxxbuilder_connect);
	        update_option('bloxxbuilder_status', 'already_registered_but_api_pending');
	    }else {
	        add_option('response_json_else','else not connected');
	    }

		    // user insert end

		   //die('stop client101');
	 }



     // call function to update plugin status on host via curl api 
    bloxx_update_plugin_status_curl(get_option('bloxx_term_id'),'active',BUILDR_PLUGIN_SLUG);


}

function bloxx_buildr_plugin_deactivated() {
   
    // call function to update plugin status on host via curl api 
    bloxx_update_plugin_status_curl(get_option('bloxx_term_id'),'deactive',BUILDR_PLUGIN_SLUG);
}




function cyb_activation_redirect( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        exit( wp_redirect( admin_url( 'admin.php?page=bloxx-connect' ) ) );
    }
}
add_action( 'activated_plugin', 'cyb_activation_redirect' );


if (!function_exists('pre')) {
    function pre($arr){
        echo '<pre>';
        print_r($arr);
        echo '</pre>';
    }
}


function bloxx_update_plugin_status_curl($bloxx_term_id,$plugin_status,$plugin_name){
    // send plugin active status to server
     //echo $bloxx_term_id;
       //  die('id=>'.$bloxx_term_id);
        if(!isset($bloxx_term_id) || $bloxx_term_id=''){

        }else{
          //  echo 'id2'.$bloxx_term_id;
            $curl_url = bloxx_apiurl."wp-json/siteblox-api/bloxx_update_plugin_status/";                
            $builder_page_array_user2 = array(
                'bloxx_term_id' =>get_option('bloxx_term_id'),
                'plugin_status'=> $plugin_status,
                'plugin_name'=> $plugin_name
            );

           // pre($builder_page_array_user2);

           // die('stop');
            $bloxx_page_json_user2 = json_encode($builder_page_array_user2);
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $curl_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 60,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $bloxx_page_json_user2,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response2 = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);


           // pre($response);


            $resp2 = json_decode($response2);
           // pre($resp2);
            // echo 'current_user_id'.$current_user_id;
            // if($resp->code==200){
            //     update_option('siteblox_key', $resp->siteblox_key);
            // }else {
            //     add_option('response_json_else','else not connected');
            // }

                // user insert end

           // die('stop client101');
         }
    // end plugin status
}


add_action( 'wp_head', 'wp_head_callback' );
function wp_head_callback() {
    $bloxxbuilder_connect_type = get_option('bloxxbuilder_connect_type');
    $is_bloxxbuilder_connect = get_option('bloxxbuilder_connect');
    if($bloxxbuilder_connect_type=='simple'){
        $auth_type = 'simple';
    }else{
        $auth_type = '';
    }
    ?>
    <input type="hidden" id="auth_type" value="<?php echo $auth_type; ?>">
    <input type="hidden" id="site_url" value="<?php echo CURRENT_SITEURL; ?>">
    <input type="hidden" id="is_bloxxbuilder_connect" value="<?php echo $is_bloxxbuilder_connect; ?>">
    
    <?php

}

if (function_exists('reload_cssjs_new')) {
    function reload_cssjs_new(){
        global $wpdb;
        global $wp_query;
        $page_id= $wp_query->post->ID;


        if($page_id!="" && is_user_logged_in()){
            @$page_refresh=get_post_meta($page_id, 'page_referesh', true);

            if(@$page_refresh=="yes" && is_user_logged_in()){
                $posts = $wpdb->prefix . 'posts';
                $page_query = "SELECT * FROM $posts where ID='$page_id' limit 1";
                $page_data = $wpdb->get_row($page_query);
                $page_content=$page_data->post_content;

                $update = wp_update_post(
                    array(
                        'ID' => $page_id,
                        'post_content' => $page_content,
                        'post_status' => "publish",
                    )
                );
                update_post_meta($page_id,"page_referesh", "no");
                ?>
                <script>
                    window.location.href="";
                </script>
                <?php
            }
        }
        return true;    
    };

    add_action('wp_head', "reload_cssjs");
}



defined( 'ABSPATH' ) || exit;


if( ! class_exists( 'updateChecker' ) ) {

    class updateChecker{

        public $plugin_slug;
        public $version;
        public $cache_key;
        public $cache_allowed;
        public $gaurav;
        public function __construct() {

            $this->plugin_slug = plugin_basename( __DIR__ );
            $this->version = '5.10.23';
            $this->cache_key = 'neosbuilder';
            $this->cache_allowed = false;

            add_filter( 'plugins_api', array( $this, 'info' ), 20, 3 );
            add_filter( 'site_transient_update_plugins', array( $this, 'update' ) );
            add_action( 'upgrader_process_complete', array( $this, 'purge' ), 10, 2 );

        }

        public function request(){

            $remote = get_transient( $this->cache_key );

            if( false === $remote || ! $this->cache_allowed ) {

                $remote = wp_remote_get(
                    UPDATE_PLUGIN_URL.'buildr.json',
                    array(
                        'timeout' => 10,
                        'headers' => array(
                            'Accept' => 'application/json'
                        )
                    )
                );

                if(
                    is_wp_error( $remote )
                    || 200 !== wp_remote_retrieve_response_code( $remote )
                    || empty( wp_remote_retrieve_body( $remote ) )
                ) {
                    return false;
                }

                set_transient( $this->cache_key, $remote, DAY_IN_SECONDS );

            }

            $remote = json_decode( wp_remote_retrieve_body( $remote ) );

            return $remote;

        }


        function info( $res, $action, $args ) {

            // print_r( $action );
            // print_r( $args );

            // do nothing if you're not getting plugin information right now
            if( 'plugin_information' !== $action ) {
                return false;
            }

            // do nothing if it is not our plugin
            if( $this->plugin_slug !== $args->slug ) {
                return false;
            }

            // get updates
            $remote = $this->request();

            if( ! $remote ) {
                return false;
            }

            $res = new stdClass();

            $res->name = $remote->name;
            $res->slug = $remote->slug;
            $res->version = $remote->version;
            $res->tested = $remote->tested;
            $res->requires = $remote->requires;
            $res->author = $remote->author;
            $res->author_profile = $remote->author_profile;
            $res->download_link = $remote->download_url;
            $res->trunk = $remote->download_url;
            $res->requires_php = $remote->requires_php;
            $res->last_updated = $remote->last_updated;

            $res->sections = array(
                'description' => $remote->sections->description,
                'installation' => $remote->sections->installation,
                'changelog' => $remote->sections->changelog
            );

            if( ! empty( $remote->banners ) ) {
                $res->banners = array(
                    'low' => $remote->banners->low,
                    'high' => $remote->banners->high
                );
            }

            return $res;

        }

        public function update( $transient ) {

            if ( empty($transient->checked ) ) {
                return $transient;
            }

            $remote = $this->request();

            if(
                $remote
                && version_compare( $this->version, $remote->version, '<' )
                && version_compare( $remote->requires, get_bloginfo( 'version' ), '<' )
                && version_compare( $remote->requires_php, PHP_VERSION, '<' )
            ) {
                $res = new stdClass();
                $res->slug = $this->plugin_slug;
                $res->plugin = plugin_basename( __FILE__ ); // misha-update-plugin/misha-update-plugin.php
                $res->new_version = $remote->version;
                $res->tested = $remote->tested;
                $res->package = $remote->download_url;

                $transient->response[ $res->plugin ] = $res;

        }

            return $transient;

        }

        public function purge(){

            if (
                $this->cache_allowed
                && 'update' === $options['action']
                && 'plugin' === $options[ 'type' ]
            ) {
                // just clean the cache when new plugin version is installed
                delete_transient( $this->cache_key );
            }

        }


    }

    new updateChecker();

}

function insertValueAtPosition($arr, $insertedArray, $position) {
    $i = 0;
    $new_array=[];
    foreach ($arr as $key => $value) {
        if ($i == $position) {
            foreach ($insertedArray as $ikey => $ivalue) {
                $new_array[$ikey] = $ivalue;
            }
        }
        $new_array[$key] = $value;
        $i++;
    }
    return $new_array;
}


add_action( 'admin_init', 'main_add_edit_link_filters' );

function main_add_edit_link_filters() {
    add_filter( 'page_row_actions', 'main_add_edit_link', 10, 2 );
}

function main_add_edit_link( $actions, $post ) {

        $post_link = get_permalink( $post->ID ).'?neo_builder=enable';
        $edit_action = array(
            'divi2' => sprintf(
                '<a href="%s" aria-label="%s">%s</a>',
                esc_url( $post_link ),
                esc_attr(
                    sprintf(
                        __( 'Edit “%s” in Divi', 'et_builder' ),
                        esc_url( $post_link )
                    )
                ),
                esc_html__( 'Edit With Buildr', 'et_builder' )
            ),
        );

        $actions = array_merge( $actions, $edit_action );
        //print_r($actions);exit;
        return $actions;
}