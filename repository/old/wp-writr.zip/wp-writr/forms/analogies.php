<form id="analogies" style="display: none;">
	<table class="form-table" role="presentation">
		<tbody>
			
			<tr>
				<th>Content</th>
				<td><textarea id="content" name="content" class="google-ads field"  required></textarea></td>
			</tr>
		</tbody>
	</table>
</form>