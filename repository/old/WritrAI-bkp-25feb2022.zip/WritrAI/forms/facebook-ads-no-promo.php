<form id="facebook-ads-no-promo" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Product Name <span class="require">*</span></th>
					<td><input type="text" id="product_name" name="product_name" class="facebook-ads-no-promo field" placeholder="Product Name" required/></td>
				</tr>
				<tr>
					<th>Product Description <span class="require">*</span></th>
					<td><textarea id="product_description" name="product_description" class="facebook-ads-no-promo field" placeholder="Product Description" required></textarea></td>
				</tr>
				
			</tbody>
		</table>
	</form>