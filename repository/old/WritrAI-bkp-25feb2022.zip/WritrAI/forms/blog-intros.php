<form id="blog-intros" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Blog Title <span class="require">*</span></th>
					<td><textarea id="blog_title" name="blog_title" class="blog-intros field" required></textarea></td>
				</tr>
				
				
			</tbody>
		</table>
	</form>