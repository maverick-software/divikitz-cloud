<?php
/*
Plugin Name: WritrAI
Description: display sidebar when edit page in divi editor.  
Version: 1.0.0
*/

define('writr_url', plugin_dir_url(__FILE__));
define('writr_path', plugin_dir_path(__FILE__));
define('writr_parent_url', "https://app.projectneo.ai");

add_action( 'init', 'wpse_72564_action_init' );


include 'admin-page.php';


define('WRITR_PLUGIN_SLUG','writr');
// send data to bloxx that plugin is activated
register_activation_hook(__FILE__, 'bloxx_writr_plugin_activated'); 
    
register_deactivation_hook( __FILE__, 'bloxx_writr_plugin_deactivated' );

//}

function bloxx_writr_plugin_activated() {
  // die('stop here writr ');

     // call function to update plugin status on host via curl api 
    writr_bloxx_update_plugin_status_curl(get_option('bloxx_term_id'),'active',WRITR_PLUGIN_SLUG);


}

function bloxx_writr_plugin_deactivated() {
   
    // call function to update plugin status on host via curl api 
    writr_bloxx_update_plugin_status_curl(get_option('bloxx_term_id'),'deactive',WRITR_PLUGIN_SLUG);
}




function bloxx_writr_activation_redirect( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        exit( wp_redirect( admin_url( 'admin.php?page=bloxx-connect' ) ) );
    }
}
add_action( 'activated_plugin', 'bloxx_writr_activation_redirect' );


// function to update plugin status on activate/deactivate
function writr_bloxx_update_plugin_status_curl($bloxx_term_id,$plugin_status,$plugin_name){
    // send plugin active status to server
     //echo $bloxx_term_id;
       //  die('id=>'.$bloxx_term_id);
        if(!isset($bloxx_term_id) || $bloxx_term_id=''){

        }else{
          //  echo 'id2'.$bloxx_term_id;
            $curl_url = writr_parent_url."/wp-json/siteblox-api/bloxx_update_plugin_status/";                
            $builder_page_array_user2 = array(
                'bloxx_term_id' =>get_option('bloxx_term_id'),
                'plugin_status'=> $plugin_status,
                'plugin_name'=> $plugin_name
            );

           // pre($builder_page_array_user2);

           // die('stop');
            $bloxx_page_json_user2 = json_encode($builder_page_array_user2);
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $curl_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 60,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $bloxx_page_json_user2,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response2 = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);


           // pre($response);


            $resp2 = json_decode($response2);
           // pre($resp2);
            // echo 'current_user_id'.$current_user_id;
            // if($resp->code==200){
            //     update_option('siteblox_key', $resp->siteblox_key);
            // }else {
            //     add_option('response_json_else','else not connected');
            // }

                // user insert end

           // die('stop client101');
         }
    // end plugin status
}

function wpse_72564_action_init() 
{
    if ( !has_filter( 'show_admin_bar', '__return_true' ) && !is_user_logged_in() )
        return;

        $builder_connect = get_option('bloxxbuilder_connect', true);
        if (!empty($builder_connect) && $builder_connect === "yes") {
            //if ( isset($_GET['et_fb']) && !empty($_GET['et_fb']) ){
                add_action( 'admin_bar_menu', 'wpse_72564_admin_bar_menu', 999 );
                add_action( 'wp_head', 'wpse_72564_styles_and_scripts' );
                add_action( 'admin_head', 'wpse_72564_styles_and_scripts' );    
             //}
        }
}

function wpse_72564_admin_bar_menu() 
{
    global $wp_admin_bar, $current_blog;

    if ( !is_object( $wp_admin_bar ) )
        return;
    //if ( !isset($_GET['et_fb']) && !empty($_GET['et_fb']) )
      //  return;

    $classes = 'wpse-loading wpse-read';
    $wp_admin_bar->add_menu( array(
        'id'     => 'wpse_menu',
        'title'  => '<label class="switch_bar"><input type="checkbox" id="checkebr"><span class="slider_bar round_bar"></span></label><span class="namewi" style="vertical-align: top;padding-left: 5px;">WritrAI</span>',
       // 'meta'   => array(
           // 'html'  => '<div id="wpse-notes-panel" style="display:none"><div class="wpse-notes-panel-header"><span class="wpse-notes-header">' . __('Notifications', 'jetpack') . '</span><span class="wpse-notes-panel-link"></span></div></div>',
           // 'class' => 'menupop',
       // ),
        'parent' => 'root-default',
    ) );
}

function wpse_72564_styles_and_scripts(){?>
<style>
    div#mySidenav.expanded .rowWrap2 .flex-3 {
    max-width: 50%;
    flex: 0 0 50%;
}
.ber-sidebar_expension {
    cursor: pointer;
}
div#mySidenav.expanded .rowWrap2 {
    display: flex;
    flex-wrap: wrap;
}
div#mySidenav.expanded {
    width: 600px !important;
}
.flex-12 {
    -ms-flex: 0 0 100%;
    flex: 0 0 100%;
    max-width: 100%;
}
.cat-title h3 {
    margin-bottom: 1rem;
    color: #231942;
    font-weight: 600;
    font-size: 20px;
}
div#mySidenav.expanded .rowWrap2 .flex-3 {
    max-width: 50%;
    flex: 0 0 50%;
}
.flex-3, .flex-4, .flex-5, .flex-6, .flex-7, .flex-8, .flex-9, .flex-12 {
    position: relative;
    width: 100%;
    padding-right: 15px;
    padding-left: 15px;
}
.admin-bar div#mySidenav {top: 32px;}
.switch_bar {position: relative !important;display: inline-block;width: 30px !important;height: 18px !important;margin-top: 7px !important;}
.switch_bar input { opacity: 0!important;width: 0!important;height: 0!important;}
.slider_bar {position: absolute!important;cursor: pointer!important;top: 0!important;left: 0!important;  right: 0!important;bottom: 0!important; background-color: #ddd!important;
  -webkit-transition: .4s!important;transition: .4s!important;}
.slider_bar:before {position: absolute!important;content: "";height: 15px!important;width: 15px!important;left: 2px!important;bottom: 2px!important;background-color: white!important;-webkit-transition: .4s!important;transition: .4s!important;}
input:checked + .slider_bar {background-color: #04aa6d!important;}
input:focus + .slider_bar {box-shadow: 0 0 1px #2196F3 !important;}
input:checked + .slider_bar:before {-webkit-transform: translateX(12px);-ms-transform: translateX(12px);transform: translateX(12px);}
/* Rounded sliders */
.slider_bar.round_bar {border-radius: 34px!important;}
.slider_bar.round_bar:before {border-radius: 50%!important;}
#mySidenav{padding:0 15px;border-left: 1px solid #ccc;}
.closeda{ position: absolute;top: 6px;color: #fff;right: 15px;z-index: #333; display: inline; font-size: 32px;cursor: pointer;}
.flex-12.cat-title h3 {    text-align: center;padding-top: 10px;}
.rowWrap{padding:0 15px;}
.cat-title h3 {margin-bottom: 1rem;color: #231942;font-weight: 600; font-size: 20px;}
.flex-3 { max-width:100%;}
.mBottom {margin-bottom: 1rem;}
.sonicColumn {border: 1px solid #F4AC45;padding: 1.5rem;background: #ffffff96;border-radius: 10px; -webkit-border-radius: 10px;-moz-border-radius: 10px;-ms-border-radius: 10px;-o-border-radius: 10px; cursor: pointer;}
.sonicIcon {display: flex;flex-flow: row wrap;align-items: center;justify-content: space-between;margin-bottom: 1rem;}
.sonicColumn h3 {color: #231942;font-weight: 600;font-size: 17px;margin: 0 0 1rem;padding: 0;}
.sonicGrid p {color: #8898AA;font-size: 14px;line-height: 24px;margin: 0;}
.sidenav { height: 100%; width: 0;position: fixed;z-index: 999999;top: 0;background-color: #fff;overflow-x: hidden; 
        padding-top: 60px;transition: 0.5s;}
.sidenav {right: 0;}
.sidebar_main_single,.sidebar_main_results{display: none;}
.sonicTitle form {display: block !important;text-align: left;margin-top: 20px;}
.form-table th, .form-table td {color: #555;border: 0;border-top: 0 !important;display: block;width: 100%; padding: 0 !important;}
.form-table th p {color: #9C9EB8; font-weight: 400;font-size: 12px;}
.form-table input, .form-table select, .form-table textarea {border: 1px solid #E1E2EF;padding: 7px 15px;width: 90%;border-radius: 10px;-webkit-border-radius: 10px; -moz-border-radius: 10px; -ms-border-radius: 10px;
    -o-border-radius: 10px; margin-bottom: 1rem;display: block;font-size: 13px;}
.sonicTitle h2 {text-transform: capitalize;font-size: 24px; color: #231942; padding: 0; margin: 0 0 1rem;}
.credits { display: inline-block;background: #ffffff; border: 1px solid #E1E2EF;
    color: #9C9EB8;font-size: 11px;padding: 0px 7px;border-radius: 4px;-webkit-border-radius: 4px; -moz-border-radius: 4px;
    -ms-border-radius: 4px;-o-border-radius: 4px;}
.credits i {width: 15px;height: 15px;display: inline-block;text-align: center;line-height: 15px;background: #F4AC45;color: #fff;font-size: 10px;margin-right: 5px;border-radius: 100px;-webkit-border-radius: 100px; -moz-border-radius: 100px;-ms-border-radius: 100px; -o-border-radius: 100px;}
#errors{color: #f41313;font-size: 13px;margin-top: -10px;text-transform: capitalize;}
span.error {color: red;display: block; margin-top: -10px; margin-bottom: 5px;text-align: left;}
.top_head { background: #6c2eb9;display: block;color: #fff; padding: 12px;text-align: center;margin: -15px -15px 10px -15px}
.resColumn {box-shadow: rgba(0, 0, 0, 0.24) 0px 2px 3px 1px;padding: 15px;background: #ffffff; border-radius: 10px;-webkit-border-radius: 10px;-moz-border-radius: 10px; -ms-border-radius: 10px;-o-border-radius: 10px;cursor: pointer;margin-bottom: 10px;}
.resColumn .fa.fa-copy {font-size: 18px;clear: both;display: block; margin: -15px -10px 5px 0;text-align: right;color: #aaa; float: right;padding: 5px;}
#submit {background: #F4AC45;color: #ffffff;padding: 12px 8px;max-width: 100%;border: 0;font-size: 14px;
    cursor: pointer;border-radius: 10px;-webkit-border-radius: 10px;-moz-border-radius: 10px;-ms-border-radius: 10px;
    -o-border-radius: 10px;}
 .lefftm { position: absolute;top: 5px;z-index: #333; display: inline; font-size: 32px;cursor: pointer;color: #fff}
 .sonicTitle h2 { font-size: 20px; padding: 10px 0;text-align: center;}
@media screen and (max-height: 450px) {.sidenav {padding-top: 15px;}.sidenav a {font-size: 18px;}
}
</style>
    <?php
}

add_action("wp_footer","wpp_foot");
add_action("admin_footer","wpp_foot");

function wpp_foot(){ ?>

<!-- <div id="mySidenav" class="sidenav">
  <div><h3>Writr</h3>by bloxx</div>
</div> -->
<script type="text/javascript">
    jQuery(document).ready(function(){
          jQuery(document).on('click','#checkebr', function(){
        if(jQuery( "#checkebr" ).is(":checked")){
            if (jQuery( "#mySidenav" ).length == 0) {
                jQuery.ajax({
                    type:"POST",
                    url:"/wp-admin/admin-ajax.php",
                    data: {action:'sidenav_htmlcours'},
                    success:function(res){
                        var div = jQuery('<div/>').appendTo('body');
                        div.attr('id', 'holdy');
                        jQuery("#holdy").html('<div id="mySidenav" class="sidenav"><div class="top_head">Writr by <span> bloxx</div><button class="ber_ber-btn ber_icon ber-sidebar_expension"><span class="dashicons dashicons-editor-expand"></span></button><div class="sidenav_first"><span class="closeda dashicons dashicons-no-alt" onclick="closeNav();"></span>'+res+'</div><div class="sidebar_main_single"><span class="dashicons dashicons-arrow-left-alt lefftm" onclick="hidesinglemain();"></span><div class="sidebar_output_single"></div></div><div class="sidebar_main_results"><span class="dashicons dashicons-arrow-left-alt lefftm" onclick="hideresult();"></span><div id="result_list"></div></div></div>');
                        openNav();
                    }
                });
            }else{
                openNav();
            }
        }else{
            if (jQuery( "#mySidenav" ).length > 0) {
                closeNav();
             }
        }
    });

        jQuery(document).on('click','.ber-sidebar_expension',function(){
            if (!jQuery(this).hasClass('bertha-idea-expand')) {
                jQuery(this).addClass('bertha-idea-expand');
                jQuery("#mySidenav").addClass('expanded');
                jQuery(this).find('span').removeClass('dashicons-editor-expand').addClass('dashicons-editor-contract');
              } else {
                jQuery(this).removeClass('bertha-idea-expand');
                jQuery("#mySidenav").removeClass('expanded');
                jQuery(this).find('span').removeClass('dashicons-editor-contract').addClass('dashicons-editor-expand');
              }
        });

         jQuery(document).on('click','.copy-input',function(){
            var $temp = jQuery("<input>");
              jQuery("body").append($temp);
              $temp.val(jQuery(this).data('html')).select();
              document.execCommand("copy");
              $temp.remove();
               jQuery('.copy-input').css("background-color","#fff");
               jQuery(this).css("background-color","#eee");
        });
    });

    function openNav() {
        document.getElementById("mySidenav").style.width = "300px";
        document.getElementById("mySidenav").style.padding = "15px";
    }
    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
         document.getElementById("mySidenav").style.padding = "0";
    }
    function hidesinglemain() {
       jQuery(".sidebar_main_single").hide();
       jQuery(".sidenav_first").show();
    }

     function hideresult() {
       jQuery(".sidebar_main_results").hide();
       jQuery(".sidebar_main_single").show();
    }

    

    function gotobuycredit(){
        window.location.href = '<?php echo writr_parent_url;?>'+'?add-to-cart=75790&quantity=1';
    }
    function show_form(data,cat){
        jQuery.ajax({
            type:"POST",
            url:"/wp-admin/admin-ajax.php",
            data: {action:'sidenav_loadform','type':data,'category':cat},
            success:function(res){
                jQuery(".sidebar_output_single").html(res);
                jQuery(".sidebar_main_single").show();
                jQuery(".sidenav_first").hide();
            }
        });
    }
   

  


    function searchData(){
        jQuery(".error").remove();
        var form_id = jQuery('#select_type').val();
        var category = jQuery('#select_cat').val();
        var form_field = jQuery("."+form_id);
        var error = 0;
        form_field.each(function(index,ele){

        if(jQuery(ele).val()=="" && jQuery(ele).parent().parent().find(".require").length>0){
          jQuery(ele).parent().append("<span class='error'>This is required field</span>")
          error++;
        }

        });
        if(error>0){
        return false;
        }
        var form_data = jQuery("#"+form_id).serialize();
        responce_list(form_data,form_id,category);
    }

    function isJSON(str) {
        if( typeof( str ) !== 'string' ) { 
            return false;
        }
        try {
            JSON.parse(str);
            return true;
        } catch (e) {
            return false;
        }
    }

var writesonic_search_xhttp = new XMLHttpRequest();
function responce_list(data,type,category) {
    writesonic_search_xhttp.abort();
    writesonic_search_xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            jQuery("#submit").prop("disabled",false);
            jQuery("#submit").val("Search");
            if(!isJSON(JSON.parse(this.responseText))){
                var list = JSON.parse(this.responseText);
                if(list.success===false){
                     jQuery("#errors").html("Please check your credits or try again");
                    // window.location.reload();
                     return;
                }
                 if(list.detail=="Not Found"){
                     jQuery("#errors").html("No detail available.");
                    // window.location.reload();
                     return;
                }
                    var er = 0;
                    var html = "<ul class='print_result'>";
                    jQuery.each(list, function(k, v){
                       if( typeof v.ad_description !== 'undefined' && typeof v.ad_description !== null ) {
                        var ad_description = v.ad_description;
                          //html +="<li class='searcch-item'><b>"+title.replace("_", " ")+":</b><br/>"+ad_description+"</li>";
                          html +="<li class='resColumn'><i class='fa fa-copy copy-input' data-html= '"+ad_description+"'></i>"+ad_description+"</li>";
                       }else if(typeof v.text !== 'undefined' && typeof v.text !== null){
                            var text = v.text;
                            html +="<li class='resColumn'><i class='fa fa-copy copy-input' data-html= '"+text+"'></i>"+text+"</li>";
                        }else if(typeof v.subtitle !== 'undefined' && typeof v.subtitle !== null){
                            var text = v.subtitle;
                            html +="<li class='resColumn'><i class='fa fa-copy copy-input' data-html= '"+text+"'></i>"+text+"</li>";
                        }else if(typeof v.article_html !== 'undefined' && typeof v.article_html !== null){
                            var text = v.article_html;
                            html +="<li class='resColumn'><i class='fa fa-copy copy-input' data-html= '"+text+"'></i>"+text+"</li>";
                        }else if(typeof list.detail[0].msg !== 'undefined' && typeof list.detail[0].msg !== null){
                            er = 1;
                            var s = '';
                            list.detail.forEach(function(objects){
                              //console.log(objects.loc[1].replace("_", " ") + " " +objects.msg);
                              s += objects.loc[1].replace("_", " ") + " " +objects.msg+"<br/>"; 
                            });
                            jQuery("#errors").html(s);

                        }else if(typeof v.detail !== 'undefined' && typeof v.detail !== null){
                            var text = v.detail;
                            html +="<li class='resColumn'><i class='fa fa-copy copy-input' data-html= '"+text+"'></i>"+text+"</li>"; }});
                    html += "</ul>";
                    if(er > 0){
                    }else{
                        jQuery(".sidebar_main_single").hide();
                        jQuery("#result_list").html(html);
                        jQuery(".sidebar_main_results").show();
                        jQuery("#errors").html("");
                    }
                    
            }
        }
    };

    jQuery("#result_list").html("");
    //jQuery(".sidebar_main_results").show();
    jQuery("#submit").prop("disabled",true);
    jQuery("#submit").val("Searching...");

    var current_user_id = '<?php echo get_current_user_id();?>';
    writesonic_search_xhttp.open("POST", "/wp-admin/admin-ajax.php", true);
    writesonic_search_xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    writesonic_search_xhttp.setRequestHeader("Accept", "application/json");
    writesonic_search_xhttp.send("action=writr_search&"+data+"&type="+type+'&category='+category+'&user_id='+current_user_id+'&lang=en&engine=economy');
}
</script>
    <?php
}


add_action('wp_ajax_writr_search', 'writr_search');
add_action('wp_ajax_nopriv_writr_search', 'writr_search');

function writr_search(){
    unset($_POST['action']);
    $_POST['siteblox_key'] = get_option('siteblox_key', true);
    $connect_data = $_POST;

    $siteblox_json = json_encode($connect_data);
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => writr_parent_url."/wp-json/wpadscustomusers/v1/all",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $siteblox_json,
        CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    echo $response;
    exit;
}

add_action('wp_ajax_sidenav_htmlcours', 'sidenav_htmlcours');
add_action('wp_ajax_nopriv_sidenav_htmlcours', 'sidenav_htmlcours');

 function sidenav_htmlcours(){ 
        $response = wp_remote_get( writr_parent_url.'/wp-json/wpcustomusers/v1/all' );

        // Exit if error.
        // if ( is_wp_error( $response ) ) {
        //     return;
        // }

        // Get the body.
        $posts = json_decode( wp_remote_retrieve_body( $response ),true );
        ?>
        <div class="bgWhite">
                <div class="rowWrap2">
                    <!-- <select name="select_type" id="select_type" onchange="show_form();"> -->
                    <?php 
                        $integration = $posts['integration'];
                        $writesonic_credit = $posts['writesonic_credit'];
                        $user_credit = $posts['user_credit'];
                        $user_credit = 5;

                        // echo '<pre>';
                        // print_r($integration);
                        // exit;

                        //unset($integration['advertising']);
                        //unset($integration['emails']);
                        foreach ($integration as $key => $api) { 
						$i = 0;
                        if(!empty($api)){ ?>
							<div class="flex-12 cat-title <?php echo $key;?>">
                                <h3><?= ucfirst(str_replace('-',' ',$key)) ;?></h3>
                            </div>
						<?php }

                         ?>
                            
                
                <?php foreach ($api as $key1 => $value) { 
                     //$exclude = array("linkedin-posts","amazon-product-descriptions","amazon-product-titles","amazon-product-features","growth-ideas","startup-ideas","startup-ideas","youtube-titles","youtube-ideas","youtube-outlines","youtube-descriptions","youtube-intros","short-press-releases","ai-article-writer","ai-article-writer-v2");
                   //if(!in_array($value['slug'], $exclude)):
if($value['status']): $i = 1;?>
            
                    <div class="flex-3 mBottom" <?php if($user_credit >= $writesonic_credit[$value['slug']]):?>onclick="show_form('<?php echo $value['slug']; ?>','<?php echo $key;?>');" <?php else :?> onclick="gotobuycredit()" <?php endif;?>>
                        <div class="sonicColumn">
                            <div class="sonicIcon">
                                <img src="<?php echo $value['thumb']; ?>">
                                <span class="credits"><img style="vertical-align: middle;" src="<?php echo plugin_dir_url(__FILE__).'/BloxxCoins.png';?>"> Credits: <?= $writesonic_credit[$value['slug']];?></span></div>
                            <h3><?php echo $value['name']; ?></h3>
                           <p><?php echo $value['desc']; ?></p>
                        </div>
                    </div>
                    <?php
                        endif;

                            }?>
                        
                        <?php
                        if($i===0){
                                echo '<style type="text/css">.'.$key.'{display:none}</style>';
                            }
                        }
                    ?>
                </div>
            </div>
      <!--   echo '<pre>';
        print_r($posts);
        exit; -->
        <?php
        exit;
   }


add_action('wp_ajax_sidenav_loadform', 'sidenav_loadform');
add_action('wp_ajax_nopriv_sidenav_loadform', 'sidenav_loadform');

function sidenav_loadform(){?>
    <div class="form_div">        
        <input type="hidden" id="select_type" name="select_type" value="<?= $_POST['type'];?>">
        <input type="hidden" id="select_cat" name="select_cat" value="<?= $_POST['category'];?>">
                    
        <div class="sonicTitle">    
            <h2><?= str_replace('-',' ',$_POST['type']);?> Descriptions</h2>    
            <p><span class="credits">
            <img style="vertical-align: middle;" src="<?php echo plugin_dir_url(__FILE__).'/BloxxCoins.png';?>"> Credits: 1</span></p>
            <p>Describe your product/service below and get personalized <?= ucwords(str_replace('-',' ',$_POST['type']));?> Descriptions in a click.</p>
          
            <?php require writr_path."forms/".$_POST['type'].".php"; ?>
            <p class="submit"><input type="button" name="submit" id="submit" class="button button-primary" value="Generate <?= ucwords(str_replace('-',' ',$_POST['type']));?>" onclick="searchData();"></p>
            <p id="errors"></p>
        </div>
    </div>
    <?php
    exit;
}


add_action( 'admin_init', 'check_requirements_for_my_plugin' );

function check_requirements_for_my_plugin() {
    if (!is_plugin_active('bloxx/bloxx_builder.php')){
        add_action( 'admin_notices', 'show_requirements_notice_for_my_plugin' );
        return; // Exit your function
    }
}

function show_requirements_notice_for_my_plugin() {
    echo '<div class="notice notice-error"><p><b>Bloxx Writr:</b> Buildr is required for authentication. Please install Buildr and enter your account API key.</div></p>';
}

