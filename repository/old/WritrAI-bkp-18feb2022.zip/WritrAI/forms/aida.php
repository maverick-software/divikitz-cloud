<form id="aida" style="display: none;">
	<table class="form-table" role="presentation">
		<tbody>
			
			<tr>
				<th>Product/Service Description <span class="require">*</span><p>Results depend on your provided input. So, please spend some time perfecting your description.</p></th>
				<td><textarea id="product_description" name="product_description" class="google-ads field" placeholder="Write Product/Service Description here.." required></textarea></td>
			</tr>
			
		</tbody>
	</table>
</form>