<form id="landing-page-headlines" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Product Name <span class="require">*</span></th>
					<td><input type="text" id="product_name" name="product_name" class="landing-page-headlines field" placeholder="Product Name" required/></td>
				</tr>
				<tr>
					<th>Product Description <span class="require">*</span></th>
					<td><textarea id="product_description" name="product_description" class="landing-page-headlines field" placeholder="Product Description" required></textarea></td>
				</tr>
				
			</tbody>
		</table>
	</form>