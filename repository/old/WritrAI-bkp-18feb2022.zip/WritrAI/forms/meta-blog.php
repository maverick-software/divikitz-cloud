<form id="meta-blog" style="display: none;">
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th>Company Name <span class="require">*</span></th>
				<td><input type="text" id="company_name" name="company_name" class="google-ads field" placeholder="Name" required/></td>
			</tr>
			<tr>
				<th>Blog Description<span class="require">*</span><p>Results depend on your provided input. So, please spend some time perfecting your description.</p></th>
				<td><textarea id="blog_description" name="blog_description" class="google-ads field"  required></textarea></td>
			</tr>
			<tr>
				<th>Search Term <span class="require">*</span></th>
				<td><input type="text" id="search_term" name="search_term"  class="google-ads field" required/></td>
			</tr>
		</tbody>
	</table>
</form>