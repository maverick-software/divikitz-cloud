<form id="product-descriptions" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Product Name <span class="require">*</span></th>
					<td><input type="text" id="product_name" name="product_name" class="product-descriptions field" placeholder="Product Name" required/></td>
				</tr>
				<tr>
					<th>Product Characteristics <span class="require">*</span></th>
					<td><textarea id="product_characteristics" name="product_characteristics" class="product-descriptions field" placeholder="Product Characteristics" required></textarea></td>
				</tr>
				
			</tbody>
		</table>
		</form>