<form id="keywords" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Content <span class="require">*</span></th>
					
					<td><textarea id="content" name="content" class="keywords field" placeholder="Write something here.." required></textarea></td>
				</tr>
				
			</tbody>
		</table>
	</form>