<form id="feature-to-benefits" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Product Description <span class="require">*</span></th>
					<td><textarea id="product_description" name="product_description" class="feature-to-benefits field" placeholder="Product Description" required></textarea></td>
				</tr>
				<tr>
					<th>Feature <span class="require">*</span></th>
					<td><textarea id="feature" name="feature" class="feature-to-benefits field" placeholder="Feature" required></textarea></td>
				</tr>
				
				
			</tbody>
		</table>
	</form>