<form id="sentence-expand-model-two" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Content To expand <span class="require">*</span></th>
					<td><textarea id="content_to_expand" name="content_to_expand" class="sentence-expand-model-two field" placeholder="Content To expand" required></textarea></td>
				</tr>
				<tr>
					<th>Tone Of Voice <span class="require">*</span></th>
					<td>
						<select name="tone_of_voice" id="tone_of_voice" class="sentence-expand-model-two field">
							<option value="excited">Excited</option>
							<option value="professional">Professional</option>
							<option value="funny">Funny</option>
							<option value="encouraging">Encouraging</option>
							<option value="dramatic">Dramatic</option>
							<option value="witty">Witty</option>
							<option value="sarcastic">Sarcastic</option>
							<option value="engaging">Engaging</option>
							<option value="creative">Creative</option>
						</select>
					</td>
				</tr>
				
				
			</tbody>
		</table>
	</form>