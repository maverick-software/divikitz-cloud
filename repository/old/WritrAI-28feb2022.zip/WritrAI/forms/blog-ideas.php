<form id="blog-ideas" style="display: none;">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th>Search Topic <span class="require">*</span></th>
					<td><textarea id="topic" name="topic" class="blog-ideas field" required></textarea></td>
				</tr>
				<tr>
					<th>Search Term <span class="require">*</span></th>
					<td><textarea id="search_term" name="search_term" class="blog-ideas field" required></textarea></td>
				</tr>
				
				
			</tbody>
		</table>
	</form>