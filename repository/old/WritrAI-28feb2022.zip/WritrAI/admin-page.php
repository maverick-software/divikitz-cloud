<?php 
add_action('admin_enqueue_scripts' , 'writr_admin_css_jsscripts');
function writr_admin_css_jsscripts() {
    //wp_enqueue_style('bloxxbuilder-font-awesome', writr_url . "css/font-awesome.min.css");
    wp_enqueue_style('wrtitr-css', writr_url . 'admin/assets/css/writr_admin_style.css?v=' . time());
  
}

add_action( 'admin_menu', 'register_my_custom_menu_page' );
function register_my_custom_menu_page() {
  // add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
  


        if ( is_plugin_active( 'buildr/bloxx_builder.php' ) ) {
            //die('11');
           // add_submenu_page('bloxx-connect','Bloxx Buildr', 'Bloxx Buildr','manage_options','bloxx_buildr_page', array($this,'bloxx_buildr_page_callback'));
           // add_submenu_page('bloxx-connect','Neo', 'Neo','manage_options','bloxx_buildr_page', 'bloxx_buildr_page_callback', 'dashicons-welcome-widgets-menus', 120 );
            // add_submenu_page( 'bloxx-connect', 'WritrAI','WritrAI', 'manage_options', '?page=custompage', 'my_custom_menu_page', 'dashicons-welcome-widgets-menus', '' );
        }else{
          //  die('12');
            add_menu_page( 'WritrAI', 'WritrAI', 'manage_options', 'custompage', 'my_custom_menu_page', 'dashicons-welcome-widgets-menus', 120 );
        }
 

}



function my_custom_menu_page(){ 
    $builder_connect="no";
    $siteblox_username  = get_option('builder_username');
    $builder_key        = get_option('builder_key');
    //if(get_option('bloxxbuilder_connect')!=""){
        $builder_connect = get_option('bloxxbuilder_connect');
    //}

    $bloxx_term_id = get_option('bloxx_term_id');
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap-grid.min.css" integrity="sha512-q0LpKnEKG/pAf1qi1SAyX0lCNnrlJDjAvsyaygu07x8OF4CEOpQhBnYiFW6YDUnOOcyAEiEYlV4S9vEc6akTEw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<div class="maincontent_writr">
<div id="maincontent" class="main-content">
    <div class="page-content">
        <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="main-title">
                                <h1>Hello from Team Neo! </h1>
                                <p>If you have a premium plan then you can connect your account below here, if you do not have you can get one <a href="<?php echo writr_apiurl; ?>plans/">here</a>. Other wise you can enjoy our free services.</p>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-3 col-3">
                            <div class="bloxx_box">
                                <div class="blx_logo">
                                    <img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/Project-Neo-Logo.png" style="max-width: 175px;" />
                                    <h3>Access Premium Features</h3>
                                    <p>Each of our plugins makes the Divi experience better and faster for developers.</p>

                                    <h2>WritrAI</h2>
            <form method="POST" id="siteblox_connectivity2">
                <section class="object-meta-data taxonomy-meta-data">
                    <table class="widefat fixed siteblox-table" cellspacing="0">
                        <tbody>
                            <tr>
                                <th>Enter API KEY</th>
                            </tr>
                            <tr class="alternate">
                                <td>
                                    <input name="website_url" type="hidden" value="<?php echo site_url(); ?>">
                                    <input name="siteblox_username" type="text"  id="siteblox_username" value="<?php
                                    if (isset($siteblox_username)) {
                                        echo $siteblox_username;
                                    }
                                    ?>" placeholder="Enter API Username">
                                    <input name="siteblox_key" id="siteblox_key" type="text" value="<?php
                                    if (isset($builder_key)) {
                                        echo $builder_key;
                                    }
                                    ?>" placeholder="Enter API Key" required>
                                    <input type="hidden" name="action" value="siteblox_key_saved_simple2">
                                    <div class="submit-buttons">

                                    <?php if ($builder_connect == "yes" &&  isset($siteblox_username) && $siteblox_username!='') { ?>
                                        <input type="hidden"  id="siteblox_status2" name="siteblox_status" value="siteblox_disconnect2">
                                        <button type="submit" id="save_connectivity2" class="button button-danger">Disconnect</button>
                                    <?php } else { ?>
                                        <input type="hidden" id="siteblox_status2" name="siteblox_status" value="siteblox_connect2">
                                        <button type="submit" id="save_connectivity2" class="button button-pro">Connect</button>
                                    <?php } ?>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </section>
        </form>

                                    

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-3 col-3">
                            <div class="bloxx_box">
                                <div class="blx_logo">
                                    <div class="blx-top neo_admin_logos">
                                        <img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/Buildr-Logo.png" />
                                        <h2>Buildr.</h2>
                                    </div>

                                    <p>Buildr allows you access a vast library of premade sections inside our proprietary drop-in builder for Divi.</p>
                                    <?php 

                                        if ( is_plugin_active( 'buildr/bloxx_builder.php' ) ) {
                                            echo '<a href="javascript:void(0);" class="btn btn-primary btn-lg btn-block">Installed</a>';
                                        }  else{
                                            echo '<a href="'.UPDATE_PLUGIN_URL.'buildr.zip" class="btn btn-primary btn-lg btn-block">Download</a>';
                                        }
                                    ?>
                                    
                                    <!-- <a href="#" class="btn btn-trans btn-block">View Demo</a> -->

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-3 col-3">
                            <div class="bloxx_box">
                                <div class="blx_logo">
                                    <div class="blx-top neo_admin_logos">
                                        <img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/WritrAI-Logo.png" />
                                        <h2>WritrAl.</h2>
                                    </div>
                                    <p>Writr wields the power of AI to bring you fast, quality copy for your web design project.</p>
                                    <?php 
                                        
                                        if ( is_plugin_active( 'WritrAI/Writr.php' ) ) {
                                            echo '<a href="javascript:void(0);" class="btn btn-primary btn-lg btn-block">Installed</a>';
                                        }  else{
                                            echo '<a href="'.UPDATE_PLUGIN_URL.'WritrAI.zip" class="btn btn-primary btn-lg btn-block">Download</a>';
                                        }
                                    ?>
                                    <!-- <a href="#" class="btn btn-trans btn-block">View Demo</a> -->

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-3 col-3">
                            <div class="bloxx_box">
                                <div class="blx_logo">
                                    <div class="blx-top neo_admin_logos">
                                        <img src="<?php echo WP_PLUGIN_URL; ?>/buildr/images/Pixr-Logo.png" />
                                        <h2>Pixr.</h2>
                                    </div>
                                    <p>Pixr brings free stock photos access directly into your site with our awesome cropping tool.</p>
                                    <?php 
                                        
                                        if ( is_plugin_active( 'pixr/free_stock_images.php' ) ) {
                                            echo '<a href="javascript:void(0);" class="btn btn-primary btn-lg btn-block">Installed</a>';
                                        }  else{
                                            echo '<a href="'.UPDATE_PLUGIN_URL.'pixr.zip" class="btn btn-primary btn-lg btn-block">Download</a>';
                                        }
                                    ?>
                                    <!-- <a href="#" class="btn btn-trans btn-block">View Demo</a> -->

                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="height40px"></div>

        </div> <!-- end container fluid -->
    </div> <!-- end page content -->
</div> <!-- end main content -->
</div> <!-- end maincontent writr -->
    <?php
}

add_action( 'admin_footer', 'wpwritr_js_code' ); // For back-end
function wpwritr_js_code() {
  ?>
  <script>
       jQuery(function($){

    $("#siteblox_connectivity2").submit(function(event){
        event.preventDefault();
       // var get_ajax_url = bloxxbuilder_admin.ajax_url;
       var get_ajax_url = '<?php echo writr_apiurl; ?>wp-admin/admin-ajax.php';
       // console.log(bloxxbuilder_admin);
        var button_action= $("#siteblox_status2").val();
        var button_text= $("#siteblox_connectivity2 #save_connectivity2").html();
        $("#siteblox_connectivity2 #save_connectivity2").html('Please Wait <i class="fa fa-spinner fa-spin" style="font-size:20px"></i>');
        $.ajax({
            type : "POST",
            dataType : "json",
            url : get_ajax_url,
            data : $('#siteblox_connectivity2').serialize(),
            success: function(resp) {
                $("#siteblox_connectivity2 #save_connectivity2").html(button_text);
                if(resp.code==200){
                    Swal.fire({
                        title: "Success!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "success"
                    });

                    if(button_action=="siteblox_connect2"){
                         $("#siteblox_status2").val('siteblox_disconnect2');
                        $("#siteblox_connectivity2 #save_connectivity2").removeClass('button-pro').addClass('button-danger');
                        $("#siteblox_connectivity2 #save_connectivity2").html('Disconnect');
                    } else {
                       

                        $("#siteblox_status2").val('siteblox_connect2');
                        $("#siteblox_username").val('');
                         $("#siteblox_key").val('');
                        $("#siteblox_connectivity2 #save_connectivity2").removeClass('button-danger').addClass('button-pro');
                        $("#siteblox_connectivity2 #save_connectivity2").html('Connect');
                    }
                } else {
                    Swal.fire({
                        title: "Error!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "error"
                    });                    
                }
            }, error:function(){
               $("#siteblox_connectivity2 #save_connectivity2").html(button_text);
               Swal.fire({
                title: "Error!", 
                text: "Please try again later",
                confirmButtonColor: '#000', 
                icon: "error"
            });
           }
       });
    });
});
</script>
  <?php  
}


add_action("wp_ajax_siteblox_key_saved_simple2", "siteblox_key_saved_simple2");
add_action("wp_ajax_nopriv_siteblox_key_saved_simple2", "siteblox_key_saved_simple2");

function siteblox_key_saved_simple2() {
        //print_r($_REQUEST);exit;
        extract($_REQUEST);
       
        $current_user = wp_get_current_user();
        $current_user_id = $current_user->ID;
        update_option('siteblox_key', $siteblox_key);
        $website_nm=get_option('blogname', true);
        $connect_data = array(
            'website_url' => $website_url,
            'server_userid' => $current_user_id,
            'siteblox_username' => trim($siteblox_username),
            'siteblox_key' => $siteblox_key,
            'website_nm' => $website_nm
        );

        $siteblox_json = json_encode($connect_data);
        // pre($_REQUEST);
        // pre($siteblox_json);
        // die('stop client');
        if ($siteblox_status == "siteblox_connect2") {
            $connect_url=writr_apiurl."/wp-json/siteblox-api/connect";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $connect_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $siteblox_json,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);

           

            //pre($err);
           // pre($response);

            //die('client ');
            if ($err) {
                $result = array(
                    'code' => 202,
                    'message' => $err
                );
            } else {

                $siteblox_resp = json_decode($response, true);
                //  pre($siteblox_resp);
                // die('stop123');
                if ($siteblox_resp['code'] == 200) {    
                    update_option('bloxx_api_url', $siteblox_resp['section_api']);
                    update_option('bloxx_api_token', $siteblox_resp['api_token']);
                    update_option('builder_username', $siteblox_username);
                    update_option('builder_key', $siteblox_key);
                    update_option('bloxx_user_id', $siteblox_resp['user_id']);
                    update_option('bloxx_term_id', $siteblox_resp['term_id']);
                    update_option('bloxxbuilder_connect', 'yes');
                    
                    update_option('bloxxbuilder_connect_type', $siteblox_resp['bloxxbuilder_connect_type']);
                }
                echo $response;
            }
        } else {
            $disconnect_url=writr_apiurl."wp-json/siteblox-api/disconnect";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $disconnect_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $siteblox_json,
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                $result = array(
                    'code' => 202,
                    'message' => $err
                );
            } else {
                $siteblox_resp = json_decode($response, true);
                if ($siteblox_resp['code'] == 200) {
                    update_option('bloxxbuilder_connect_type', $siteblox_resp['bloxxbuilder_connect_type']);
                    update_option('bloxxbuilder_connect', 'no');
                    update_option('builder_key', '');
                }
                echo $response;
            }
        }
        die();
    }


