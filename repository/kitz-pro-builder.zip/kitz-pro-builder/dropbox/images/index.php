<?php
//Silence is Golden