jQuery(function($) {
    $("body").on("keyup", "#search-free-stock", function(event) {
        if (event.keyCode == 13) {
            var $this = $(this);
            var search_key = $this.val();
            var ajax_url = pixlapi.ajax_url;
            var imageurl = pixlapi.imageurl;
            var website_url = pixlapi.siteurl;
            var builder_key = pixlapi.builder_key;
            var api_token = pixlapi.api_token;
            var account_image = imageurl + "/images/account-icon.png";
            if (ajax_url == "activate") {
                var error_image = imageurl + "/images/error-frame.png";
                Swal.fire({
                    title: "<img src='" + error_image + "'/> Error!",
                    text: "Please activate Divi theme or Divi Builder plugin for continue",
                    confirmButtonColor: '#000'
                });
            } else if (ajax_url == "disconnect") {
                Swal.fire({
                    title: "<img src='" + account_image + "'/>Account Verification",
                    text: "Please enter your API key to gain access to the bloxx builder and library.",
                    input: 'text',
                    showCancelButton: false,
                    confirmButtonColor: '#9F05C5',
                    //cancelButtonColor: '#000',
                    confirmButtonText: 'Submit',
                    showCloseButton: true,
                    customClass: {
                        container: 'pixl_swal',
                    },
                    footer: '<a target="_blank" href="https://app.gobloxx.io/bloxx-account/" id="some-action">Get your API key here <i class="fas fa-angle-double-right"></i></a>',
                    inputValidator: (value) => {
                        if (!value) {
                            return 'Enter Your Bloxx API Key'
                        }
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        siteblox_key = result.value;
                        var action = "siteblox_keysaved";
                        var ajax_url = pixlapi.ajax_url;
                        var siteblox_status = "siteblox_connect";
                        key_connect(ajax_url, website_url, siteblox_key, siteblox_status, action);
                    }
                });
            } else {
                free_stock_search($this);
            }
        }
    });   



    var free_stock_query = "";
    var free_stock_page = 1;
    var is_append = false;
    var api_token="";
    var builder_key="";

    var free_stock_xhttp = new XMLHttpRequest();
    function free_stock_search(ele) {
        var ele=ele[0];
        if (ele.value.length > 2) {
            free_stock_page = 1;
            is_append = false;
            free_stock_query = ele.value;
            builder_key = pixlapi.builder_key;
            api_token = pixlapi.api_token;
            free_stock_list();
        }
    }

    function next_page(ele) {
        free_stock_page++;
        is_append = true;
        ele.innerHTML = 'Loading..';
        document.getElementById("search-free-stock").style.display = "none";
        if (free_stock_page == 26) {
            document.getElementById("free-stock-load-more").style.display = "none";
        }
        free_stock_list();
    }


    var full_url = window.location.href;
    var pathname = window.location.pathname;
    var origin   = window.location.origin;
    var my_path=origin+pathname+"?page=Pixabay_image";

    if(full_url==my_path){        
        free_stock_list_pageload();
    } 

    function free_stock_list_pageload() {        
        var ajax_url = pixlapi.ajax_url;
        var imageurl = pixlapi.imageurl;
        var website_url = pixlapi.siteurl;
        var builder_key = pixlapi.builder_key;
        var api_token = pixlapi.api_token;
        var account_image = imageurl + "/images/account-icon.png";
        if (ajax_url == "activate") {
            var error_image = imageurl + "/images/error-frame.png";
            Swal.fire({
                title: "<img src='" + error_image + "'/> Error!",
                text: "Please activate Divi theme or Divi Builder plugin for continue",
                confirmButtonColor: '#000'
            });
        } else if (ajax_url == "disconnect") {
            Swal.fire({
                title: "<img src='" + account_image + "'/>Account Verification",
                text: "Please enter your API key to gain access to the bloxx builder and library.",
                input: 'text',
                showCancelButton: false,
                confirmButtonColor: '#9F05C5',
                //cancelButtonColor: '#000',
                confirmButtonText: 'Submit',
                showCloseButton: true,
                footer: '<a target="_blank" href="https://app.gobloxx.io/bloxx-account/" id="some-action">Get your API key here <i class="fas fa-angle-double-right"></i></a>',
                inputValidator: (value) => {
                    if (!value) {
                        return 'Enter Your Bloxx API Key'
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    siteblox_key = result.value;
                    var action = "siteblox_keysaved";
                    var ajax_url = pixaby.ajax_url;
                    var siteblox_status = "siteblox_connect";
                    key_connect(ajax_url, website_url, siteblox_key, siteblox_status, action);
                }
            });
        } else {

            $.ajax({
                type: "POST",
                url: pixlapi.ajax_url,
                crossDomain: true,
                data: {
                    'action': 'pixaby_load_onload',
                    'builder_key': builder_key,
                    'api_token': api_token,                
                    'searchKey': free_stock_query,
                    'pageing': free_stock_page
                },
                beforeSend: function () {
                    //$this.html(cat_text + ' <i class="fa fa-spinner fa-spin"></i>');
                    $(".sections_lists section").removeClass("active_slide");
                    $(".sections_lists .builder_posts").hide();
                },
                success: function (resp) {
                    if ($.trim(resp) == "Data_not_found") {
                        var imageurl = pixlapi.imageurl;
                        var error_image=imageurl+"/images/error-frame.png";
                        Swal.fire({
                            title: "<img src='"+error_image+"'/> Error!",
                            text: "Oops! Looks like your current API key isn’t working! Generate a new API key or check your Bloxx plan",
                            confirmButtonColor: '#000'                                
                        });                   
                    } else {  
                        Swal.close();                     
                        $(".pixaby_lists").html($.trim(resp));   
                    }

                },
                error: function () {
                    var imageurl = pixlapi.imageurl;
                    var error_image=imageurl+"/images/error-frame.png";
                    Swal.fire({
                        title: "<img src='"+error_image+"'/> Error!",
                        text: "Please try again latter",
                        confirmButtonColor: '#000'                                
                    }); 
                }
            });
        }
        
    }

    function free_stock_list() {
        $.ajax({
            type: "POST",
            url: pixlapi.ajax_url,
            crossDomain: true,
            data: {
                'action': 'pixaby_load',
                'builder_key': builder_key,
                'api_token': api_token,                
                'searchKey': free_stock_query,
                'pageing': free_stock_page
            },
            beforeSend: function () {               
                swal.fire({
                    customClass: {
                        container: 'swal2_spinner',
                    },
                    html: '<div class="builder_spinner" id="loadingSpinner"></div>',
                    showConfirmButton: false,
                    onRender: function () {
                        $('.swal2-content').prepend(sweet_loader);
                    }
                });
            },
            success: function (resp) {
                if ($.trim(resp) == "Data_not_found") {
                    var imageurl = pixlapi.imageurl;
                    var error_image=imageurl+"/images/error-frame.png";
                    Swal.fire({
                        title: "<img src='"+error_image+"'/> Error!",
                        text: "Oops! Looks like your current API key isn’t working! Generate a new API key or check your Bloxx plan",
                        confirmButtonColor: '#000'                                
                    });                   
                } else {  
                    Swal.close();                 
                    $("#free-stock-image-list").html($.trim(resp));                    
                }

            },
            error: function () {
                var imageurl = pixlapi.imageurl;
                var error_image=imageurl+"/images/error-frame.png";
                Swal.fire({
                    title: "<img src='"+error_image+"'/> Error!",
                    text: "Please try again latter",
                    confirmButtonColor: '#000'                                
                }); 
            }
        });
    }

    //free_stock_image_list_click();
    $("body").on("click", "#free-stock-image-list .column-free-stock img",  function(event){
        event.preventDefault();
        localStorage.setItem("croped", "yes");
        var $this=$(this)[0];
        free_stock_image_list_click($this);
    });


    function free_stock_image_list_click(ele) {     	       
        var image_data = jQuery(ele).data('image');
        
        jQuery(".column-free-stock").removeClass('active');
        jQuery(ele).parent().addClass('active');
        delete image_data.id;
        delete image_data.user_id;
        delete image_data.user;
        delete image_data.userImageURL;
        delete image_data.comments;
        delete image_data.collections;
        delete image_data.downloads;
        delete image_data.views;
        delete image_data.imageSize;

        if($("body").hasClass("media_page_Pixabay_image")){            
            var html = "<a target='_blank' href='"+pixlapi.siteurl+"/download.php?file="+image_data['largeImageURL']+"' download> Download Image</a><hr>";
        } else {
            var html = "<button class='button button-primary button-large free_stock_import_button' onClick='add_url(\""+image_data['largeImageURL']+"\")' > Import Image & Crop</button><hr>";
            //var html = "<button class='button button-primary' id='import_pixr_croppe' data-id='"+image_data['largeImageURL']+"'>Import Image</button><hr>";
        }

        for (var key in image_data) {
            var obj = image_data[key];
            if(key=="pageURL" || key=="previewURL" || key=="webformatURL" || key=="largeImageURL"){
                html += "<b style='text-transform:capitalize;'>" + key + ":</b><a class='btn button-primary' href='" + obj + "'>View Link</a><hr>";
            } else {
                html += "<b style='text-transform:capitalize;'>" + key + ":</b><br/><span style='text-transform:capitalize;'>" + obj + "</span><hr>";
            }
        }
        jQuery(".list-pixbay").find(".detail").html(html);

    }



    function key_connect(ajax_url, website_url, siteblox_key, siteblox_status, action){
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                'action': action,
                'website_url': website_url,
                'siteblox_key': siteblox_key,
                'siteblox_status': siteblox_status
            },
            beforeSend: function () {               
                swal.fire({
                    customClass: {
                        container: 'swal2_spinner',
                    },
                    html: '<div class="builder_spinner" id="loadingSpinner"></div>',
                    showConfirmButton: false,
                    onRender: function () {
                        $('.swal2-content').prepend(sweet_loader);
                    }
                });
            },
            success: function (resp) {
                if(resp.code==200){
                    Swal.fire({
                        title: "Success!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "success"
                    });
                    setTimeout(function(){
                        window.location.href="";
                    }, 1500);
                } else {
                    Swal.fire({
                        title: "Error!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "error"
                    });
                }
                
            }, error:function(){
                Swal.fire({
                    title: "Error!", 
                    text: "Please try again later",
                    confirmButtonColor: '#000', 
                    icon: "error"
                });
            }
        });
    }




    $("body").on("click", ".pixaby_lists .image-list .row-free-stock .load-button", function(){
        free_stock_page= free_stock_page+1;
        free_stock_query=$(".pixaby_lists .list-pixbay #search-free-stock").val();
        var builder_key = pixlapi.builder_key;
        var api_token = pixlapi.api_token;        
        free_stock_list_load_more(free_stock_query, free_stock_page, builder_key, api_token);
    });



    function free_stock_list_load_more(free_stock_query, free_stock_page, builder_key, api_token) {
        $.ajax({
            type: "POST",
            url: pixlapi.ajax_url,
            crossDomain: true,
            data: {
                'action': 'pixaby_load',
                'builder_key': builder_key,
                'api_token': api_token,                
                'searchKey': free_stock_query,
                'pageing': free_stock_page
            },
            beforeSend: function () {               
                swal.fire({
                    customClass: {
                        container: 'swal2_spinner',
                    },
                    html: '<div class="builder_spinner" id="loadingSpinner"></div>',
                    showConfirmButton: false,
                    onRender: function () {
                        $('.swal2-content').prepend(sweet_loader);
                    }
                });
            },
            success: function (resp) {                
                if ($.trim(resp) == "Data_not_found") {
                    var imageurl = pixlapi.imageurl;
                    var error_image=imageurl+"/images/error-frame.png";
                    Swal.fire({
                        title: "<img src='"+error_image+"'/> Error!",
                        text: "Oops! Looks like your current API key isn’t working! Generate a new API key or check your Bloxx plan",
                        confirmButtonColor: '#000'                                
                    });                   
                } else {
                    Swal.close();
                    $("#free-stock-image-list .column-free-stock:last-child").after($.trim(resp));                    
                }

            },
            error: function () {
                var imageurl = pixlapi.imageurl;
                var error_image=imageurl+"/images/error-frame.png";
                Swal.fire({
                    title: "<img src='"+error_image+"'/> Error!",
                    text: "Please try again latter",
                    confirmButtonColor: '#000'                                
                }); 
            }
        });
    }


    
    

    /*$(document).on("click", "img", function(){
    	var $this=$(this);
    	var el_width=$this.parent().width();
    	var el_height=$this.parent().height();
    	createItem(el_height, el_width);
    });*/


    $(document).on("click", ".et-fb-component-settings", function(){
    	var $this=$(this); 
    	if($this.parent().hasClass('et_pb_image')){
    		var el_width=$this.parent().width();
    		var el_height=$this.parent().height();    	
    		createItem(el_height, el_width); 	    
    	}

    	if($this.parent().parent().hasClass("et_pb_with_background")){
    		var el_width=$this.parent().width();
    		var el_height=$this.parent().height();    	
    		createItem(el_height, el_width); 
    	}
    });

    /*$(document).on('contextmenu', "img", function() {
    	var $this=$(this); 	    		     
    	var el_width=$this.parent().width();
    	var el_height=$this.parent().height();    	
    	createItem(el_height, el_width); 	    
  	});*/



    function createItem(el_height, el_width) {
		localStorage.setItem('el_height', el_height);
		localStorage.setItem('el_width', el_width); 
		localStorage.setItem("croped", "yes");
	}


    /*$("body").on("click", ".attachment-info .details .edit-attachment", function(event){
        event.preventDefault();
        alert("testRock");
    });*/



    //Media Crop Button
    $(document).on("click", ".media-frame-content .attachments-wrapper ul li", function(event){        
        var media_id=$(this).attr('data-id');
        $(".attachment-info .details .edit-attachment").removeAttr("target").removeClass('edit-attachment').addClass("custom_crop").attr('data-id', media_id).attr('href', "javascript:void(0)").html("Crop");

        //Add custom popup modal on media images
        var el_height=localStorage.getItem('el_height');
        var el_width=localStorage.getItem('el_width');
        $(".media-modal-content #myModal").remove(); 
        $(".custom_modal").remove();       
        $(".media-modal-content .media-frame").after('<div id="myModal" class="custom_modal"><div class="modal-content"><span class="close">&times;</span><div class="media_form main_heading_sk"><li><div class="logo"><h1>Pixr</h1></div><ul></li><li><a class="button button-primary" id="pixel_importimg" href="javascript:void(0)">Done</a></li></ul></div><div class="body_content"><img src=""/><div class="media_form main_footer_sk"><ul><li><a class="button button-warning" id="pixel_mode" href="javascript:void(0)">Edit Mode</a></li></ul><div class="enable_edit_mode" style="display:none;"><p><label>H</label><input type="text" id="manually_height" class="" value="'+el_height+'" placeholder="Height"></p><p><label>W</label><input type="text" id="manually_width" class="" value="'+el_width+'" placeholder="Width"></p><p><button class="button button-primary" id="save_mode">View Dimension</button></p></div></div></div><div class="ftr_logo"><img src="'+pixabay_media_tab_ajax_object.pixr_url+'images/logo_Text@2x.png" alt="logo_footer"/></div></div></div>');
    });


    $(document).on("click", ".media-router #menu-item-browse", function(event){
        var get_id=$(this).attr('id');        
        setTimeout(function(){
            var media_id=$(".media-frame-content .attachments-wrapper ul li.selected").attr('data-id');            
            $(".attachment-info .details .edit-attachment").removeAttr("target").removeClass('edit-attachment').addClass("custom_crop").attr('data-id', media_id).attr('href', "javascript:void(0)").html("Crop");

            //Add custom popup modal on media images
            var el_height=localStorage.getItem('el_height');
            var el_width=localStorage.getItem('el_width');

            $(".media-modal-content #myModal").remove();
            $(".custom_modal").remove();
            $(".media-modal-content .media-frame").after('<div id="myModal" class="custom_modal"><div class="modal-content"><span class="close">&times;</span><div class="media_form main_heading_sk"><li><div class="logo"><h1>Pixr</h1></div><ul></li><li><a class="button button-primary" id="pixel_importimg" href="javascript:void(0)">Done</a></li></ul></div><div class="body_content"><img src=""/><div class="media_form main_footer_sk"><ul><li><a class="button button-warning" id="pixel_mode" href="javascript:void(0)">Edit Mode</a></li></ul><div class="enable_edit_mode" style="display:none;"><p><label>H</label><input type="text" id="manually_height" class="" value="'+el_height+'" placeholder="Height"></p><p><label>W</label><input type="text" id="manually_width" class="" value="'+el_width+'" placeholder="Width"></p><p><button class="button button-primary" id="save_mode">View Dimension</button></p></div></div></div><div class="ftr_logo"><img src="'+pixabay_media_tab_ajax_object.pixr_url+'images/logo_Text@2x.png" alt="logo_footer"/></div></div></div>');

            var cropped_clicked=localStorage.getItem("croped");
            if(cropped_clicked=="yes"){
            	setTimeout(function(){
            		localStorage.setItem("croped", "no");            		
            		$('.attachment-info .details .custom_crop').click();            
            	}, 1500);
        	}

        }, 1000);
    });





    var basic=window.Cropper;
    
    $(document).on("click", ".attachment-info .details .custom_crop", function(event){
        event.preventDefault();
        $('.supports-drag-drop[style*="none"] .custom_modal').remove();

        localStorage.setItem("croped", "no");
        var media_id=$(this).attr('data-id');
        var media_url=wp.media.attachment(media_id).get('url');

        var $this=$(this);
        var el_height=localStorage.getItem('el_height');
        var el_width=localStorage.getItem('el_width'); 

        if(el_height == null || el_width== null){
            el_height=200;
            el_width=200;
        }

        

        var get_image=$this.attr('data-id');        
        $(".media-modal-content #myModal .body_content img").attr('src', media_url);
        $(".media-modal-content #myModal").show();
        //basic.cropper.destroy();
        var image = $('.media-modal-content .custom_modal .body_content img')[0];
        
        //Using jquery.Jcrop.min.js
        
        basic= new Cropper(image, {            
            guides: false, 
            center: true,           
            highlight: true,
            cropBoxMovable: true,
            cropBoxResizable: false,
            toggleDragModeOnDblclick: false,        
            data:{
              width: el_width,
              height:  el_height,
            }
        });
    });


    $("body").on("click", "#pixel_mode", function(){
        $this=$(this);
        if($this.hasClass("active")){ 

            //Enable Pixr cropping area by default
            var el_height=localStorage.getItem('el_height');
            var el_width=localStorage.getItem('el_width'); 

            if(el_height == null || el_width== null){
                el_height=200;
                el_width=200;
            }

            if (basic) {
                basic.destroy();
            }

            var image = $('.media-modal-content .custom_modal .body_content img')[0];            
            basic= new Cropper(image, {                
                guides: false, 
                center: true,           
                highlight: true,
                cropBoxMovable: true,
                cropBoxResizable: false,
                toggleDragModeOnDblclick: false,        
                data:{
                  width: el_width,
                  height:  el_height,
                }
            });

            $this.removeClass("active").html("Edit Mode");
            $(".enable_edit_mode").hide();
        } else {
            $this.addClass("active").html("Hide Edit Mode");
            $(".enable_edit_mode").fadeIn("slow");
            setTimeout(function(){
                $("#save_mode").trigger("click");
            }, 500);
        }
    });


    $("body").on("click", "#save_mode", function(){
        $this=$(this);
        var el_height=$("#manually_height").val();
        var el_width=$("#manually_width").val();

        var media_id=$(".media-frame-content .attachments-wrapper ul li.selected").attr('data-id');
        var media_url=wp.media.attachment(media_id).get('url');

        if (basic) {
            basic.destroy();
        }

        var image = $('.media-modal-content .custom_modal .body_content img')[0];
        basic= new Cropper(image, {
            zoomable: false,
            center: true,
            data: {
              width: parseFloat(el_width),
              height: parseFloat(el_height),
            },
            crop(event) {
                $("#manually_height").val(Math.floor(parseFloat(event.detail.height)));
                $("#manually_width").val(Math.floor(parseFloat(event.detail.width)));
            },
        });
    });



    $("body").on("click", ".media-modal-content #myModal span.close", function(){
        $(".media-modal-content #myModal").hide();
    });


    $("body").on("click", "#pixel_importimg", function(){
        var $this=$(this);
        if($("#pixel_mode").hasClass("active")){
            var el_height=$("#manually_height").val();
            var el_width=$("#manually_width").val();
        } else { 
            var el_height=localStorage.getItem('el_height');
            var el_width=localStorage.getItem('el_width'); 
        }

        if(el_height == null || el_width== null){
            el_height=200;
            el_width=200;
        }

        var img_height= Math.floor(parseFloat(el_height));
        var img_width= Math.floor(parseFloat(el_width));

        let imgSrc = basic.getCroppedCanvas({width: img_width, height: img_height}).toDataURL("image/jpg");
        

        $this.html('Wait...');
        var html = "<button class='button button-primary button-large free_stock_import_button' onClick='add_url(\""+imgSrc+"\", \"enable_base_encode\")' style='visibility:hidden; position: absolute;'> Import Image</button><hr>";
        $this.after(html);          
        $(".free_stock_import_button").trigger("click");

        setTimeout(function(){
            if (basic) {
                basic.destroy();
            }
        }, 4000);
        
        /*basic.croppie('result', {
            type: 'canvas',
            size: 'viewport'
        }).then(function (resp) {
            $this.html('Wait...');
            var html = "<button class='button button-primary button-large free_stock_import_button' onClick='add_url(\""+resp+"\", \"enable_base_encode\")' style='visibility:hidden; position: absolute;'> Import Image</button><hr>";
            $this.after(html);          
            $(".free_stock_import_button").trigger("click");
        });*/
    });
});