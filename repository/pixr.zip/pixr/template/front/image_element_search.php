<div class="column-free-stock" >
    <img class="free_stock_image" onClick="free_stock_image_list_click(this)" src="<?php echo $image->webformatURL; ?>" alt="<?php echo $image->tags; ?>" data-image='<?php echo json_encode($image); ?>' >
  </div>