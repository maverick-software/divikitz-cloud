<h2>İşlem İpuçları</h2>
<p>Kullanıcı arayüzündeki işlem, işletim sisteminin standart dosya yöneticisine benzer. Ancak Sürükle ve Bırak özelliği mobil tarayıcılarda mümkün değildir. </p>
<ul>
	<li>Bağlam menüsünü göstermek için sağ tıklayın veya uzun dokunun.</li>
	<li>Öğeleri taşımak/kopyalamak için klasör ağacına veya geçerli çalışma alanına sürükleyip bırakın.</li>
	<li>Çalışma alanındaki öğe seçimi Shift veya Alt (Seçenek) tuşuyla genişletilebilir.</li>
	<li>Dosya ve klasör yüklemek için hedef klasöre veya çalışma alanına sürükleyip bırakın.</li>
	<li>Yükleme iletişim kutusu, pano verilerini veya URL listelerini yapıştırma/bırakma ve diğer tarayıcı veya dosya yöneticilerinden Sürükle ve Bırak vb.</li>
	<li>Dış tarayıcıya sürüklemek için Alt (Seçenek) tuşuna basarak sürükleyin. Google Chrome ile indirme işlemi olacak.</li>
</ul>
