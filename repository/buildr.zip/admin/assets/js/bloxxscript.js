jQuery(function($){

    $("#siteblox_connectivity").submit(function(event){
        event.preventDefault();
        var get_ajax_url = bloxxbuilder_admin.ajax_url;
       // console.log(bloxxbuilder_admin);
        var button_action= $("#siteblox_status").val();
        var button_text= $("#siteblox_connectivity #save_connectivity").html();
        $("#siteblox_connectivity #save_connectivity").html('Please Wait <i class="fa fa-spinner fa-spin" style="font-size:20px"></i>');
        $.ajax({
            type : "POST",
            dataType : "json",
            url : get_ajax_url,
            data : $('#siteblox_connectivity').serialize(),
            success: function(resp) {
                $("#siteblox_connectivity #save_connectivity").html(button_text);
                if(resp.code==200){                       
                    Swal.fire({
                        title: "Success!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "success"
                    });

                    if(button_action=="siteblox_connect"){
                        $("#siteblox_status").val('siteblox_disconnect');
                        $("#siteblox_connectivity #save_connectivity").removeClass('button-pro').addClass('button-danger');
                        $("#siteblox_connectivity #save_connectivity").html('Disconnect');
                    } else {
                        $("#siteblox_status").val('siteblox_connect');
                        $("#siteblox_key").val('');
                        $("#siteblox_connectivity #save_connectivity").removeClass('button-danger').addClass('button-pro');
                        $("#siteblox_connectivity #save_connectivity").html('Connect');
                    }
                } else {
                    Swal.fire({
                        title: "Error!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "error"
                    });                    
                }
            }, error:function(){
               $("#siteblox_connectivity #save_connectivity").html(button_text);
               Swal.fire({
                title: "Error!", 
                text: "Please try again later",
                confirmButtonColor: '#000', 
                icon: "error"
            });
           }
       });
    });




    // simple connectivity

    $("#siteblox_connectivity_simple").submit(function(event){
        event.preventDefault();
        var get_ajax_url = bloxxbuilder_admin.ajax_url;
       // console.log(bloxxbuilder_admin);
        var button_action= $("#siteblox_status_simple").val();
        var button_text= $("#siteblox_connectivity_simple #save_connectivity_simple").html();
        $("#siteblox_connectivity_simple #save_connectivity_simple").html('Please Wait <i class="fa fa-spinner fa-spin" style="font-size:20px"></i>');
        $.ajax({
            type : "POST",
            dataType : "json",
            url : get_ajax_url,
            data : $('#siteblox_connectivity_simple').serialize(),
            success: function(resp) {
                $("#siteblox_connectivity_simple #save_connectivity_simple").html(button_text);
                if(resp.code==200){                       
                    Swal.fire({
                        title: "Success!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "success"
                    });

                    if(button_action=="siteblox_connect_simple"){
                        $("#siteblox_status_simple").val('siteblox_disconnect_simple');
                        $("#siteblox_connectivity_simple #save_connectivity_simple").removeClass('button-pro').addClass('button-danger');
                        $("#siteblox_connectivity_simple #save_connectivity_simple").html('Disconnect');
                    } else {
                        $("#siteblox_status_simple").val('siteblox_connect_simple');
                        $("#siteblox_key_simple").val('');
                        $("#siteblox_connectivity_simple #save_connectivity_simple").removeClass('button-danger').addClass('button-pro');
                        $("#siteblox_connectivity_simple #save_connectivity_simple").html('Connect');
                    }
                } else {
                    Swal.fire({
                        title: "Error!", 
                        text: resp.message,
                        confirmButtonColor: '#000', 
                        icon: "error"
                    });                    
                }
            }, error:function(){
               $("#siteblox_connectivity_simple #save_connectivity_simple").html(button_text);
               Swal.fire({
                title: "Error!", 
                text: "Please try again later",
                confirmButtonColor: '#000', 
                icon: "error"
            });
           }
       });
    });


});