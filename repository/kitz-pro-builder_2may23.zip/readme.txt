=== Kitz Pro Builder ===
Contributors: Enspyre Digital LLC
Tags: kitz pro, builder, divi, divi builder, page building
Tested up to: 6.1.1
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Kitz Builder helps you build Divi sites ten times faster with cloud storage and drop-in features.


== Installation ==

### 3 Ways To Install Kitzpro Builder

1. **Automatically install our plugin via WordPress admin panel**:- Open your WordPress website admin panel and go to Plugins > Click Add New & search '**Kitzpro Builder**' at here > Here you will find our plugin > Now click on install button > After this you will see a activate button > Just activate it to use Cool Timeline inside your website.
2. *Install via Zip file**:- In this method first you need to download our plugin from the WordPress plugins directory. Go to https://wordpress.org/plugins/kitzpro-builder/ & *Download Kitzpro Builder**. After this inside your WP-admin panel, click on Plugins > Add New > Upload Button. Now choose the plugin zip file that you just downloaded from the WordPress plugins directory & activate it.
3. *Install the plugin via FTP**:- In this method, you also first need to download the plugin zip file from the WordPress plugins directory. After this open your FTP manager and Go to > wp-content/plugins folder. Here you need to upload the extracted version of *Kitzpro Builder** (please remember don't upload zip files directly here). After this, you can activate the plugin from the wp-admin panel plugins page.

